'use strict';
const { EmbedBuilder, SlashCommandBuilder } = require('discord.js');
const config = require('../../config.json');

module.exports = {
  name: 'ping',
  enabled: true,
  description: 'Kiểm tra độ trễ bot',
  category: 'Info',
  usage: '!ping',
  cooldown: 5,
  prefixSupport: true,
  data: new SlashCommandBuilder()
    .setName('ping').setDescription('Kiểm tra độ trễ của bot')
    .setDMPermission(false),

  async execute(interactionOrMessage, args, client) {
    const isSlash = !!interactionOrMessage.isChatInputCommand?.();
    const now     = Date.now();

    if (isSlash) {
      await interactionOrMessage.deferReply();
      const latency   = Date.now() - now;
      const wsLatency = client.ws.ping;
      const pingEmoji = latency < 100 ? '🟢' : latency < 200 ? '🟡' : '🔴';
      return interactionOrMessage.editReply({ embeds: [new EmbedBuilder()
        .setColor(config.colors?.success || '#00D26A').setTitle('🏓 Pong!')
        .addFields(
          { name: '📨 Bot Latency', value: `${pingEmoji} **${latency}ms**`, inline: true },
          { name: '💓 WebSocket',   value: `${pingEmoji} **${wsLatency}ms**`, inline: true }
        )
        .setFooter({ text: config.footer || 'Stela Network' }).setTimestamp()] });
    } else {
      const sent      = await interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(config.colors?.warning || '#FFA502').setDescription('📡 Đang đo ping...')] });
      const latency   = sent.createdTimestamp - interactionOrMessage.createdTimestamp;
      const wsLatency = client.ws.ping;
      const pingEmoji = latency < 100 ? '🟢' : latency < 200 ? '🟡' : '🔴';
      await sent.edit({ embeds: [new EmbedBuilder()
        .setColor(config.colors?.success || '#00D26A').setTitle('🏓 Pong!')
        .addFields(
          { name: '📨 Bot Latency', value: `${pingEmoji} **${latency}ms**`, inline: true },
          { name: '💓 WebSocket',   value: `${pingEmoji} **${wsLatency}ms**`, inline: true }
        )
        .setFooter({ text: config.footer || 'Stela Network' }).setTimestamp()] });
    }
  }
};
