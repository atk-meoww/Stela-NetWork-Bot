'use strict';
const { EmbedBuilder, SlashCommandBuilder, MessageFlags } = require('discord.js');
const https = require('https');
const config = require('../../config.json');

function httpGet(url) {
  return new Promise((res, rej) => {
    https.get(url, r => {
      let d = ''; r.on('data', c => d += c); r.on('end', () => {
        try { res(JSON.parse(d)); } catch { rej(new Error('Invalid JSON')); }
      });
    }).on('error', rej).setTimeout(8000, function() { this.destroy(); rej(new Error('Timeout')); });
  });
}

module.exports = {
  name: 'define',
  enabled: true,
  description: 'Tra từ điển tiếng Anh',
  category: 'Info',
  aliases: ['dictionary', 'dict', 'tu'],
  usage: '!define <từ>',
  cooldown: 5,
  prefixSupport: true,
  data: new SlashCommandBuilder()
    .setName('define').setDescription('Tra từ điển tiếng Anh')
    .addStringOption(o => o.setName('word').setDescription('Từ cần tra').setRequired(true))
    .setDMPermission(false),
  async execute(interactionOrMessage, args) {
    const isSlash = !!interactionOrMessage.isChatInputCommand?.();
    const word = isSlash ? interactionOrMessage.options.getString('word') : args?.[0];

    if (!word) {
      const err = '❌ Cú pháp: `!define <từ>`';
      return isSlash ? interactionOrMessage.reply({ content: err, flags: MessageFlags.Ephemeral }) : interactionOrMessage.reply(err);
    }
    if (isSlash) await interactionOrMessage.deferReply();
    else await interactionOrMessage.channel.sendTyping().catch(() => {});

    try {
      const data = await httpGet(`https://api.dictionaryapi.dev/api/v2/entries/en/${encodeURIComponent(word)}`);
      if (!data || !data[0]) throw new Error('Not found');
      const entry = data[0];
      const embed = new EmbedBuilder()
        .setColor(config.colors?.primary || '#7B2FBE')
        .setTitle(`📖 ${entry.word}${entry.phonetic ? ` — *${entry.phonetic}*` : ''}`)
        .setFooter({ text: 'Powered by Free Dictionary API • ' + (config.footer || 'Stela Network') });

      for (const meaning of entry.meanings.slice(0, 3)) {
        const defs = meaning.definitions.slice(0, 2).map((d, i) => {
          let t = `${i+1}. ${d.definition}`;
          if (d.example) t += `\n   *Ví dụ: ${d.example}*`;
          return t;
        }).join('\n');
        if (defs) embed.addFields({ name: `**${meaning.partOfSpeech}**`, value: defs.slice(0, 1024) });
      }

      return isSlash ? interactionOrMessage.editReply({ embeds: [embed] }) : interactionOrMessage.reply({ embeds: [embed] });
    } catch (e) {
      const err = `❌ Không tìm thấy định nghĩa cho **${word}**!`;
      return isSlash ? interactionOrMessage.editReply({ content: err }) : interactionOrMessage.reply(err);
    }
  }
};
