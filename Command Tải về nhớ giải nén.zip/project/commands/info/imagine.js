'use strict';
const _0x0816ad={0xaa57:0x4128,_:!0};void(0x9d);
const { EmbedBuilder, AttachmentBuilder } = require('discord.js');
const https  = require('https');
const config = require('../../config.json');

const COOLDOWNS  = new Map();
const COOLDOWN_MS = 30_000;

const STYLES = {
  anime:    'anime style, vibrant colors, detailed',
  realistic:'photorealistic, ultra detailed, 8k',
  pixel:    'pixel art, retro game style, 16bit',
  fantasy:  'fantasy art, magical, cinematic lighting',
  cute:     'cute chibi style, pastel colors, kawaii',
};

function encodePrompt(prompt) { return encodeURIComponent(prompt); }

module.exports = {
  name: 'imagine',
  enabled: true, description: 'AI tạo ảnh từ mô tả', category: 'Info',
  aliases: ['ai_art', 'draw', 've', 'genimg'], cooldown: 30,

  async execute(message, args) {
    const last = COOLDOWNS.get(message.author.id) || 0;
    if (Date.now() - last < COOLDOWN_MS) {
      const rem = Math.ceil((COOLDOWN_MS - (Date.now() - last)) / 1000);
      return message.reply({ embeds: [new EmbedBuilder().setColor(0xFF8C00)
        .setDescription(`⏳ Chờ **${rem}s** nữa để tạo ảnh tiếp!`).setFooter({ text: config.footer || 'Stela Network' })] });
    }

    if (!args.length) return message.reply({ embeds: [new EmbedBuilder().setColor(0xFF8C00)
      .setTitle('🎨 AI Tạo ảnh')
      .setDescription(
        '`!imagine <mô tả>` — Tạo ảnh từ mô tả\n' +
        '`!imagine <mô tả> --style <kiểu>` — Áp dụng style\n\n' +
        '**Styles:** `anime` · `realistic` · `pixel` · `fantasy` · `cute`\n\n' +
        '*Vd: `!imagine a cat playing guitar --style anime`*'
      ).setFooter({ text: config.footer || 'Stela Network' })] });

    // Parse style flag
    const fullText = args.join(' ');
    const styleMatch = fullText.match(/--style\s+(\w+)/i);
    const style = styleMatch ? styleMatch[1].toLowerCase() : null;
    const prompt = fullText.replace(/--style\s+\w+/i, '').trim();
    const styleModifier = STYLES[style] || '';
    const finalPrompt = styleModifier ? `${prompt}, ${styleModifier}` : prompt;

    const thinking = await message.reply({ embeds: [new EmbedBuilder()
      .setColor(0x7B2FBE).setDescription(`🎨 Đang tạo ảnh cho: **${prompt}**\n⏳ Chờ 10-15 giây...`)
      .setFooter({ text: config.footer || 'Stela Network' })] });

    COOLDOWNS.set(message.author.id, Date.now());

    const seed = Math.floor(Math.random() * 999999);
    const imgUrl = `https://image.pollinations.ai/prompt/${encodePrompt(finalPrompt)}?width=768&height=768&seed=${seed}&nologo=true`;

    // Fetch ảnh về
    const fetchImage = () => new Promise((resolve, reject) => {
      https.get(imgUrl, { timeout: 20000 }, (res) => {
        const chunks = [];
        res.on('data', c => chunks.push(c));
        res.on('end', () => resolve(Buffer.concat(chunks)));
        res.on('error', reject);
      }).on('error', reject).on('timeout', () => reject(new Error('Timeout')));
    });

    try {
      const imgBuffer = await fetchImage();
      const attachment = new AttachmentBuilder(imgBuffer, { name: 'ai_art.png' });

      await thinking.edit({ content: '',
        embeds: [new EmbedBuilder()
          .setColor(0x7B2FBE)
          .setTitle('🎨 AI Artwork')
          .setDescription(`**Prompt:** ${prompt}${style ? `\n**Style:** \`${style}\`` : ''}`)
          .setImage('attachment://ai_art.png')
          .addFields({ name: '🎲 Seed', value: `\`${seed}\``, inline: true })
          .setFooter({ text: `${config.footer} • Powered by Pollinations AI` })
          .setTimestamp()],
        files: [attachment] });
    } catch (err) {
      await thinking.edit({ embeds: [new EmbedBuilder()
        .setColor(0xFF4757)
        .setDescription('❌ Không tạo được ảnh! Thử mô tả đơn giản hơn hoặc dùng tiếng Anh.\n`' + err.message + '`')
        .setFooter({ text: config.footer || 'Stela Network' })] });
    }
  }
};
