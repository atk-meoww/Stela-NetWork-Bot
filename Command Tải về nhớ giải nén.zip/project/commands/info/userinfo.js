'use strict';
const { EmbedBuilder, SlashCommandBuilder } = require('discord.js');
const config = require('../../config.json');
const { getMember } = require('../../handlers/utils');

module.exports = {
  name: 'userinfo',
  enabled: true,
  description: 'Thông tin người dùng',
  category: 'Info',
  aliases: ['ui', 'whois'],
  usage: '!userinfo [@user]',
  cooldown: 5,
  prefixSupport: true,
  data: new SlashCommandBuilder()
    .setName('userinfo').setDescription('Xem thông tin chi tiết về một thành viên')
    .addUserOption(o => o.setName('user').setDescription('Người dùng (bỏ trống = bản thân)').setRequired(false))
    .setDMPermission(false),

  async execute(interactionOrMessage, args, client) {
    const isSlash = !!interactionOrMessage.isChatInputCommand?.();
    if (isSlash) await interactionOrMessage.deferReply();

    let member;
    if (isSlash) {
      member = interactionOrMessage.options.getMember('user') || interactionOrMessage.member;
    } else {
      member = (args[0] ? await getMember(interactionOrMessage.guild, args[0]) : null) || interactionOrMessage.member;
    }

    const user  = member.user;
    const guild = interactionOrMessage.guild;

    const roles = member.roles.cache
      .filter(r => r.id !== guild.id)
      .sort((a, b) => b.position - a.position)
      .map(r => r.toString())
      .slice(0, 10)
      .join(', ') || 'Không có';

    const statusEmoji = { online: '🟢', idle: '🌙', dnd: '🔴', offline: '⚫' };
    const status      = statusEmoji[member.presence?.status] || '⚫';

    const badgeMap = {
      Staff: '👨‍💼 Discord Staff', Partner: '🤝 Partner',
      Hypesquad: '🏠 HypeSquad', BugHunterLevel1: '🐛 Bug Hunter L1',
      BugHunterLevel2: '🐛 Bug Hunter L2', HypeSquadOnlineHouse1: '🏠 Bravery',
      HypeSquadOnlineHouse2: '🏠 Brilliance', HypeSquadOnlineHouse3: '🏠 Balance',
      PremiumEarlySupporter: '⭐ Early Supporter', VerifiedDeveloper: '👨‍💻 Verified Dev',
      ActiveDeveloper: '🔧 Active Dev', CertifiedModerator: '🛡️ Moderator',
    };
    const badges = (user.flags?.toArray() || []).map(f => badgeMap[f]).filter(Boolean).join('\n') || 'Không có';

    const embed = new EmbedBuilder()
      .setColor(member.displayHexColor || config.colors?.primary || '#7B2FBE')
      .setTitle(`👤 ${user.tag || user.username}`)
      .setThumbnail(user.displayAvatarURL({ dynamic: true, size: 256 }))
      .addFields(
        { name: '🆔 ID',              value: user.id,                                             inline: true },
        { name: `${status} Trạng thái`,value: member.presence?.status || 'offline',              inline: true },
        { name: '🤖 Bot?',            value: user.bot ? 'Có' : 'Không',                          inline: true },
        { name: '📅 Tạo tài khoản',   value: `<t:${Math.floor(user.createdTimestamp/1000)}:D>`,  inline: true },
        { name: '📥 Vào server',       value: `<t:${Math.floor(member.joinedTimestamp/1000)}:D>`, inline: true },
        { name: '🎨 Màu role',         value: member.displayHexColor || '#000000',               inline: true },
        { name: `🎭 Roles (${member.roles.cache.size - 1})`, value: roles,                        inline: false },
        { name: '🏅 Huy hiệu',         value: badges,                                            inline: false }
      )
      .setFooter({ text: config.footer || 'Stela Network' }).setTimestamp();

    if (isSlash) await interactionOrMessage.editReply({ embeds: [embed] });
    else await interactionOrMessage.reply({ embeds: [embed] });
  }
};
