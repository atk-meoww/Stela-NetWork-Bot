'use strict';
const { EmbedBuilder, SlashCommandBuilder } = require('discord.js');
const config = require('../../config.json');
const https  = require('https');

const LANGS = {
  'vi':'Tiếng Việt','en':'English','ja':'日本語','ko':'한국어',
  'zh':'中文','fr':'Français','de':'Deutsch','es':'Español',
  'th':'ภาษาไทย','ru':'Русский','it':'Italiano','pt':'Português'
};

function httpsGet(url) {
  return new Promise((res, rej) => {
    const req = https.get(url, r => {
      let raw = ''; r.setEncoding('utf8');
      r.on('data', c => raw += c);
      r.on('end', () => { try { res(JSON.parse(raw)); } catch { rej(new Error('Bad JSON')); } });
    });
    req.setTimeout(8000, () => { req.destroy(); rej(new Error('Timeout')); });
    req.on('error', rej);
  });
}

module.exports = {
  name: 'translate',
  enabled: true,
  description: 'Dịch văn bản sang ngôn ngữ khác',
  category: 'Info',
  aliases: ['dich', 'tr', 'trans'],
  usage: '!translate <mã ngôn ngữ> <văn bản>',
  cooldown: 5,
  prefixSupport: true,
  data: new SlashCommandBuilder()
    .setName('translate').setDescription('Dịch văn bản sang ngôn ngữ khác')
    .addStringOption(o => o.setName('language').setDescription('Ngôn ngữ đích').setRequired(true)
      .addChoices(
        { name: '🇻🇳 Tiếng Việt', value: 'vi' }, { name: '🇺🇸 English', value: 'en' },
        { name: '🇯🇵 日本語', value: 'ja' },       { name: '🇰🇷 한국어', value: 'ko' },
        { name: '🇨🇳 中文', value: 'zh' },          { name: '🇫🇷 Français', value: 'fr' },
        { name: '🇩🇪 Deutsch', value: 'de' },       { name: '🇪🇸 Español', value: 'es' },
        { name: '🇹🇭 ภาษาไทย', value: 'th' },       { name: '🇷🇺 Русский', value: 'ru' }
      ))
    .addStringOption(o => o.setName('text').setDescription('Văn bản cần dịch').setRequired(true).setMaxLength(500))
    .setDMPermission(false),

  async execute(interactionOrMessage, args, client) {
    const isSlash = !!interactionOrMessage.isChatInputCommand?.();

    let langCode, text;
    if (isSlash) {
      langCode = interactionOrMessage.options.getString('language');
      text     = interactionOrMessage.options.getString('text');
      await interactionOrMessage.deferReply();
    } else {
      if (args.length < 2) {
        const langList = Object.entries(LANGS).map(([k,v]) => `\`${k}\` ${v}`).join(' • ');
        return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(0xFF8C00).setTitle('📌 Cách dùng')
          .setDescription('`!translate <mã ngôn ngữ> <nội dung>`\nVí dụ: `!translate en Xin chào`\n\n**Ngôn ngữ:** ' + langList)
          .setFooter({ text: config.footer || 'Stela Network' })] });
      }
      langCode = args[0].toLowerCase();
      text     = args.slice(1).join(' ');
    }

    if (text.length > 500) {
      const err = '❌ Văn bản quá dài! Tối đa 500 ký tự.';
      return isSlash ? interactionOrMessage.editReply({ content: err }) : interactionOrMessage.reply(err);
    }

    try {
      const url  = `https://api.mymemory.translated.net/get?q=${encodeURIComponent(text)}&langpair=auto|${langCode}`;
      const data = await httpsGet(url);

      if (data.responseStatus !== 200 && data.responseStatus !== '200')
        throw new Error(data.responseDetails || 'Translation failed');

      const translated   = data.responseData?.translatedText;
      const detectedLang = data.responseData?.detectedSourceLanguage || 'auto';
      if (!translated) throw new Error('No result');

      const embed = new EmbedBuilder().setColor(0x4169E1).setTitle('🌐 Dịch văn bản')
        .addFields(
          { name: `📝 Gốc (${detectedLang})`,          value: text.slice(0, 1024),       inline: false },
          { name: `✅ ${LANGS[langCode] || langCode}`,  value: translated.slice(0, 1024), inline: false }
        )
        .setFooter({ text: `${config.footer || 'Stela Network'} • MyMemory API` }).setTimestamp();

      if (isSlash) await interactionOrMessage.editReply({ embeds: [embed] });
      else await interactionOrMessage.reply({ embeds: [embed] });
    } catch (err) {
      const msg = `❌ Dịch thất bại: ${err.message}`;
      if (isSlash) await interactionOrMessage.editReply({ content: msg });
      else await interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(0xFF4757).setDescription(msg)] });
    }
  }
};
