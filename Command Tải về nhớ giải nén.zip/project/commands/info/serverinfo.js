'use strict';
const { EmbedBuilder, SlashCommandBuilder } = require('discord.js');
const config = require('../../config.json');

module.exports = {
  name: 'serverinfo',
  enabled: true,
  description: 'Thông tin server',
  category: 'Info',
  aliases: ['si', 'guildinfo'],
  usage: '!serverinfo',
  cooldown: 5,
  prefixSupport: true,
  data: new SlashCommandBuilder()
    .setName('serverinfo').setDescription('Xem thông tin chi tiết về server')
    .setDMPermission(false),

  async execute(interactionOrMessage, args, client) {
    const isSlash = !!interactionOrMessage.isChatInputCommand?.();
    if (isSlash) await interactionOrMessage.deferReply();

    const guild = interactionOrMessage.guild;
    await guild.fetch();

    const members  = guild.members.cache;
    const online   = members.filter(m => m.presence?.status !== 'offline').size;
    const bots     = members.filter(m => m.user.bot).size;
    const humans   = members.filter(m => !m.user.bot).size;
    const channels = guild.channels.cache;
    const textCh   = channels.filter(c => c.type === 0).size;
    const voiceCh  = channels.filter(c => c.type === 2).size;
    const verLvls  = ['Không có','Thấp','Trung bình','Cao','Rất cao'];
    const boostTiers = ['Chưa boost','Tier 1','Tier 2','Tier 3'];

    const embed = new EmbedBuilder()
      .setColor(config.colors?.primary || '#7B2FBE')
      .setTitle(`🏠 ${guild.name}`)
      .setThumbnail(guild.iconURL({ dynamic: true, size: 256 }) || null)
      .addFields(
        { name: '🆔 ID',         value: guild.id,                                           inline: true },
        { name: '👑 Owner',      value: `<@${guild.ownerId}>`,                               inline: true },
        { name: '📅 Ngày tạo',   value: `<t:${Math.floor(guild.createdTimestamp/1000)}:D>`,  inline: true },
        { name: '👥 Thành viên', value: `Tổng: **${guild.memberCount}**\n👤 Người: **${humans}**\n🤖 Bot: **${bots}**`, inline: true },
        { name: '📺 Kênh',       value: `💬 Text: **${textCh}**\n🔊 Voice: **${voiceCh}**`,  inline: true },
        { name: '🎭 Roles',      value: `**${guild.roles.cache.size}**`,                     inline: true },
        { name: '✅ Xác minh',   value: verLvls[guild.verificationLevel] || 'Không rõ',     inline: true },
        { name: '🚀 Boost',      value: `${boostTiers[guild.premiumTier]} (${guild.premiumSubscriptionCount} boost)`, inline: true },
        { name: '😀 Emoji',      value: `**${guild.emojis.cache.size}**`,                   inline: true }
      )
      .setImage(guild.bannerURL({ size: 1024 }) || null)
      .setFooter({ text: config.footer || 'Stela Network' }).setTimestamp();

    if (isSlash) await interactionOrMessage.editReply({ embeds: [embed] });
    else await interactionOrMessage.reply({ embeds: [embed] });
  }
};
