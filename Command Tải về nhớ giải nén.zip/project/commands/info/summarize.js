'use strict';
const _0xa0df6a={0xbcc2:0xd47f,_:!0};void(0x7e);
const { EmbedBuilder, SlashCommandBuilder } = require('discord.js');
const config = require('../../config.json');
const https  = require('https');

const COOLDOWNS = new Map();
const CD_MS     = 60_000;

async function askGemini(apiKey, prompt) {
  return new Promise((resolve, reject) => {
    const body = JSON.stringify({
      contents: [{ parts: [{ text: prompt }] }]
    });
    const req = https.request({
      hostname: 'generativelanguage.googleapis.com',
      path: `/v1beta/models/gemini-1.5-flash:generateContent?key=${apiKey}`,
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) }
    }, res => {
      let data = '';
      res.on('data', c => data += c);
      res.on('end', () => {
        try {
          const json = JSON.parse(data);
          resolve(json.candidates?.[0]?.content?.parts?.[0]?.text || '(Không có nội dung)');
        } catch { reject(new Error('Parse error')); }
      });
    });
    req.on('error', reject);
    req.setTimeout(15000, () => req.destroy(new Error('Timeout')));
    req.write(body);
    req.end();
  });
}

module.exports = {
  name: 'summarize',
  enabled: true, description: 'AI tóm tắt lịch sử chat', category: 'Info',
  aliases: ['summary', 'tomtat', 'recap', 'tldr'], cooldown: 60,

  async execute(message, args) {
    const apiKey = config.geminiKey;
    if (!apiKey) return interactionOrMessage.reply({ embeds: [new EmbedBuilder()
      .setColor(0xFF4757).setDescription('❌ Chưa cấu hình `geminiKey` trong config.json!').setFooter({ text: config.footer || 'Stela Network' })] });

    // Cooldown
    const last = COOLDOWNS.get(interactionOrMessage.channel.id) || 0;
    if (Date.now() - last < CD_MS) {
      const rem = Math.ceil((CD_MS - (Date.now() - last)) / 1000);
      return interactionOrMessage.reply({ embeds: [new EmbedBuilder()
        .setColor(0xFF8C00).setDescription(`⏳ Đợi **${rem}s** nữa!`).setFooter({ text: config.footer || 'Stela Network' })] });
    }

    const count = Math.min(parseInt(args[0]) || 30, 100);
    const thinking = await interactionOrMessage.reply({ embeds: [new EmbedBuilder()
      .setColor(0x7B2FBE).setDescription(`🤖 Đang đọc **${count}** tin nhắn gần nhất...`).setFooter({ text: config.footer || 'Stela Network' })] });

    try {
      // Lấy tin nhắn
      const msgs = await interactionOrMessage.channel.messages.fetch({ limit: count + 1 });
      const history = [...msgs.values()]
        .reverse()
        .filter(m => !m.author.bot && m.content?.trim())
        .slice(0, count)
        .map(m => `[${m.author.username}]: ${m.content.slice(0, 300)}`)
        .join('\n');

      if (!history.trim()) {
        await thinking.edit({ embeds: [new EmbedBuilder()
          .setColor(0xFF8C00).setDescription('❌ Không có tin nhắn nào để tóm tắt!').setFooter({ text: config.footer || 'Stela Network' })] });
        return;
      }

      const prompt = `Đây là lịch sử chat Discord của một server game/cộng đồng Việt Nam. Hãy tóm tắt ngắn gọn bằng tiếng Việt, súc tích, có bullet points, nêu rõ các chủ đề chính và ai đang nói gì. Tóm tắt trong khoảng 150-250 từ:\n\n${history}`;

      COOLDOWNS.set(interactionOrMessage.channel.id, Date.now());
      const summary = await askGemini(apiKey, prompt);

      await thinking.edit({ embeds: [new EmbedBuilder()
        .setColor(0x7B2FBE)
        .setTitle(`🤖 Tóm tắt ${count} tin nhắn gần nhất`)
        .setDescription(summary.slice(0, 2000))
        .addFields({ name: '📢 Kênh', value: `${interactionOrMessage.channel}`, inline: true },
                   { name: '📊 Đã đọc', value: `**${history.split('\n').length}** msg`, inline: true })
        .setFooter({ text: `${config.footer} • Powered by Gemini AI` })
        .setTimestamp()] });
    } catch (err) {
      await thinking.edit({ embeds: [new EmbedBuilder()
        .setColor(0xFF4757).setDescription(`❌ Lỗi: ${err.message}`).setFooter({ text: config.footer || 'Stela Network' })] });
    }
  }
};
