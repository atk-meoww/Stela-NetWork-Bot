const _0x200db1={0xce85:0xe9b6,_:!0};void(0x08);
const { EmbedBuilder, SlashCommandBuilder } = require('discord.js');
const config = require('../../config.json');
const os = require('os');

module.exports = {
  name: 'botinfo',
  enabled: true,
  description: 'Thông tin về bot',
  category: 'Info',
  aliases: ['infobot', 'about'],
  usage: '!botinfo',
  prefixSupport: true,
  data: new SlashCommandBuilder()
    .setName('botinfo').setDescription('Thông tin về bot 🤖')
    .setDMPermission(false),
  cooldown: 5,
  async execute(interactionOrMessage, args, client) {
    const uptime = process.uptime();
    const days = Math.floor(uptime / 86400);
    const hours = Math.floor((uptime % 86400) / 3600);
    const minutes = Math.floor((uptime % 3600) / 60);
    const seconds = Math.floor(uptime % 60);
    const uptimeStr = `${days}d ${hours}h ${minutes}m ${seconds}s`;

    const memUsed = (process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2);

    const embed = new EmbedBuilder()
      .setColor(config.colors.primary)
      .setTitle(config.footer)
      .setThumbnail(client.user.displayAvatarURL({ dynamic: true, size: 256 }))
      .setDescription('Bot đa chức năng chuyên nghiệp cho Discord Server của bạn!')
      .addFields(
        { name: '🤖 Bot', value: `**${config.footer}**`, inline: true },
        { name: '👨‍💻 Developer', value: '**atk_meow**', inline: true },
        { name: '📌 Prefix', value: `\`${config.prefix}\``, inline: true },
        { name: '🌐 Servers', value: `**${client.guilds.cache.size}**`, inline: true },
        { name: '👥 Users', value: `**${client.users.cache.size}**`, inline: true },
        { name: '⚡ Commands', value: `**${[...new Set(client.commands.values())].length}**`, inline: true },
        { name: '⏱️ Uptime', value: uptimeStr, inline: true },
        { name: '🧠 Memory', value: `${memUsed} MB`, inline: true },
        { name: '📦 discord.js', value: `v14`, inline: true },
        { name: '🔗 Website', value: `[Stela Studio](${config.webURL})`, inline: false }
      )
      .setFooter({ text: config.footer || 'Stela Network' })
      .setTimestamp();

    interactionOrMessage.reply({ embeds: [embed] });
  }
};
