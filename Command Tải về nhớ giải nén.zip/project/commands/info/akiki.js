'use strict';
const { EmbedBuilder, AttachmentBuilder } = require('discord.js');
const { loadConfig } = require('../../handlers/utils');
const path = require('path');
const fs = require('fs');

module.exports = {
  name: 'akiki',
  enabled: true,
  description: 'Gửi mã QR chuyển khoản của Akiki',
  category: 'Info',
  aliases: ['lq', 'akiki'],
  cooldown: 10,

  async execute(message, args, client) {
    const cfg = loadConfig();
    const qrPath = path.join(__dirname, '..', '..', 'assets', 'qr2.jpg');

    if (!fs.existsSync(qrPath)) {
      return message.reply('❌ Không tìm thấy file QR!');
    }

    const attachment = new AttachmentBuilder(qrPath, { name: 'qr2.jpg' });
    const embed = new EmbedBuilder()
      .setColor('#0068FF')
      .setTitle('💳 QR Chuyển Khoản')
      .setDescription(
        `**Vui lòng sử dụng mã QR dưới đây để chuyển khoản cho Akiki.**\n\n${cfg.footer || 'Stela Network'}`
      )
      .setImage('attachment://qr2.jpg')   // ✅ Sửa lỗi typo
      .setFooter({ text: cfg.footer || 'Stela Network' })
      .setTimestamp();

    await message.reply({ embeds: [embed], files: [attachment] });
  }
};