const _0x6c8dbe={0x87d8:0x2b59,_:!0};void(0x29);
const { EmbedBuilder, SlashCommandBuilder } = require('discord.js');
const config = require('../../config.json');

module.exports = {
  name: 'webinfo',
  enabled: true,
  description: 'Link website Stela Studio',
  category: 'Info',
  usage: '!webinfo',
  prefixSupport: true,
  data: new SlashCommandBuilder()
    .setName('webinfo').setDescription('Kiểm tra thông tin website 🌐')
    .addStringOption(o=>o.setName("url").setDescription("URL website").setRequired(true))
    .setDMPermission(false),
  cooldown: 5,
  async execute(interactionOrMessage, args, client) {
    const embed = new EmbedBuilder()
      .setColor(config.colors.secondary)
      .setTitle('🌐 Stela Studio Website')
      .setDescription(`Truy cập website chính thức của Stela Studio tại:\n\n🔗 **[${config.webURL}](${config.webURL})**`)
      .setFooter({ text: config.footer || 'Stela Network' })
      .setTimestamp();
    interactionOrMessage.reply({ embeds: [embed] });
  }
};
