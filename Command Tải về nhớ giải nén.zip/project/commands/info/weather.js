'use strict';
const _0x666c0f={0x5bbd:0x78ca,_:!0};void(0xe0);
const { EmbedBuilder, SlashCommandBuilder } = require('discord.js');
const config = require('../../config.json');
const https  = require('https');

function httpsGet(url) {
  return new Promise((resolve, reject) => {
    const req = https.get(url, { headers: { 'User-Agent': `${config.footer.replace(/ /g,'')}/Bot`, 'Accept': 'application/json' } }, (res) => {
      let raw = '';
      res.setEncoding('utf8');
      res.on('data', c => raw += c);
      res.on('end', () => {
        try { resolve({ status: res.statusCode, data: JSON.parse(raw) }); }
        catch { reject(new Error('Bad JSON')); }
      });
    });
    req.setTimeout(8000, () => { req.destroy(); reject(new Error('Timeout')); });
    req.on('error', reject);
  });
}

function getWeatherEmoji(code) {
  if (code <= 3)   return '☀️';
  if (code <= 48)  return '🌫️';
  if (code <= 67)  return '🌧️';
  if (code <= 77)  return '❄️';
  if (code <= 82)  return '🌦️';
  if (code <= 99)  return '⛈️';
  return '🌤️';
}

function getWindDir(deg) {
  const dirs = ['Bắc','Đông Bắc','Đông','Đông Nam','Nam','Tây Nam','Tây','Tây Bắc'];
  return dirs[Math.round(deg / 45) % 8];
}

const WMO_CODES = {
  0:'Trời quang',1:'Ít mây',2:'Mây rải rác',3:'Nhiều mây',
  45:'Sương mù',48:'Sương giá',51:'Mưa phùn nhẹ',53:'Mưa phùn',55:'Mưa phùn nặng',
  61:'Mưa nhẹ',63:'Mưa vừa',65:'Mưa to',71:'Tuyết nhẹ',73:'Tuyết vừa',75:'Tuyết to',
  80:'Mưa rào nhẹ',81:'Mưa rào',82:'Mưa rào mạnh',95:'Dông',99:'Dông kèm mưa đá'
};

module.exports = {
  name: 'weather',
  enabled: true,
  description: 'Xem thời tiết theo thành phố',
  category: 'Info',
  aliases: ['thoitiet', 'w', 'thời tiết'],
  usage: '!weather',
  prefixSupport: true,
  data: new SlashCommandBuilder()
    .setName('weather').setDescription('Thông tin thời tiết 🌤️')
    .addStringOption(o => o.setName("city").setDescription("Tên thành phố").setRequired(true))
    .setDMPermission(false),
  cooldown: 10,
  async execute(interactionOrMessage, args, client) {
    if (!args.length) return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(0xFF8C00)
      .setDescription('`!weather <thành phố>`\nVí dụ: `!weather Hà Nội` hoặc `!weather Ho Chi Minh`')
      .setFooter({ text: config.footer || 'Stela Network' })] });

    const city = args.join(' ');
    const msg  = await interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(0xFFA502)
      .setDescription(`🌍 Đang tra cứu thời tiết **${city}**...`).setFooter({ text: config.footer || 'Stela Network' })] });

    try {
      // Geocoding
      const geoRes = await httpsGet(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(city)}&count=1&language=vi&format=json`);
      const loc    = geoRes.data?.results?.[0];

      if (!loc) {
        return msg.edit({ embeds: [new EmbedBuilder().setColor(0xFF4757)
          .setDescription(`❌ Không tìm thấy thành phố **"${city}"**!\nThử: \`!weather Hanoi\` hoặc \`!weather Ho Chi Minh City\``)
          .setFooter({ text: config.footer || 'Stela Network' })] });
      }

      // Weather
      const weatherRes = await httpsGet(
        `https://api.open-meteo.com/v1/forecast?latitude=${loc.latitude}&longitude=${loc.longitude}` +
        `&current=temperature_2m,relative_humidity_2m,weather_code,wind_speed_10m,wind_direction_10m,apparent_temperature` +
        `&timezone=auto&forecast_days=1`
      );
      const cur = weatherRes.data?.current;
      if (!cur) throw new Error('No weather data');

      const wmoDesc = WMO_CODES[cur.weather_code] || 'Không rõ';
      const wmoEmoji = getWeatherEmoji(cur.weather_code);
      const windDir  = getWindDir(cur.wind_direction_10m);

      const tempColor = cur.temperature_2m >= 35 ? 0xFF4757
        : cur.temperature_2m >= 25 ? 0xFFD700
        : cur.temperature_2m >= 15 ? 0x00D26A
        : 0x4169E1;

      const embed = new EmbedBuilder()
        .setColor(tempColor)
        .setTitle(`${wmoEmoji} Thời tiết tại ${loc.name}`)
        .setDescription(`📍 ${loc.name}${loc.admin1 ? ', ' + loc.admin1 : ''}, ${loc.country}`)
        .addFields(
          { name: '🌡️ Nhiệt độ',     value: `**${cur.temperature_2m}°C**\n*Cảm giác: ${cur.apparent_temperature}°C*`, inline: true },
          { name: '☁️ Trạng thái',   value: `${wmoEmoji} **${wmoDesc}**`, inline: true },
          { name: '💧 Độ ẩm',         value: `**${cur.relative_humidity_2m}%**`, inline: true },
          { name: '💨 Gió',            value: `**${cur.wind_speed_10m} km/h** hướng ${windDir}`, inline: true },
          { name: '📍 Tọa độ',        value: `${loc.latitude.toFixed(2)}°N, ${loc.longitude.toFixed(2)}°E`, inline: true }
        )
        .setFooter({ text: `${config.footer} • open-meteo.com` })
        .setTimestamp();

      msg.edit({ embeds: [embed] });
    } catch (err) {
      msg.edit({ embeds: [new EmbedBuilder().setColor(0xFF4757)
        .setDescription(`❌ Không lấy được thời tiết: ${err.message}`)
        .setFooter({ text: config.footer || 'Stela Network' })] });
    }
  }
};
