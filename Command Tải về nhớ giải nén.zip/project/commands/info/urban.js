'use strict';
const { EmbedBuilder, SlashCommandBuilder, MessageFlags } = require('discord.js');
const https = require('https');
const config = require('../../config.json');

function httpGet(url) {
  return new Promise((res, rej) => {
    https.get(url, r => {
      let d = ''; r.on('data', c => d += c); r.on('end', () => {
        try { res(JSON.parse(d)); } catch { rej(new Error('Invalid JSON')); }
      });
    }).on('error', rej).setTimeout(8000, function() { this.destroy(); rej(new Error('Timeout')); });
  });
}

module.exports = {
  name: 'urban',
  enabled: true,
  description: 'Tra Urban Dictionary (từ lóng tiếng Anh)',
  category: 'Info',
  aliases: ['ud', 'slang'],
  usage: '!urban <từ>',
  cooldown: 5,
  prefixSupport: true,
  data: new SlashCommandBuilder()
    .setName('urban').setDescription('Tra Urban Dictionary (từ lóng tiếng Anh)')
    .addStringOption(o => o.setName('term').setDescription('Từ cần tra').setRequired(true))
    .setDMPermission(false),
  async execute(interactionOrMessage, args) {
    const isSlash = !!interactionOrMessage.isChatInputCommand?.();
    const term = isSlash ? interactionOrMessage.options.getString('term') : args?.join(' ');

    if (!term) {
      const err = '❌ Cú pháp: `!urban <từ>`';
      return isSlash ? interactionOrMessage.reply({ content: err, flags: MessageFlags.Ephemeral }) : interactionOrMessage.reply(err);
    }
    if (isSlash) await interactionOrMessage.deferReply();
    else await interactionOrMessage.channel.sendTyping().catch(() => {});

    try {
      const data = await httpGet(`https://api.urbandictionary.com/v0/define?term=${encodeURIComponent(term)}`);
      if (!data?.list?.length) throw new Error('Not found');
      const entry = data.list[0];
      const clean = s => s.replace(/\[|\]/g, '').slice(0, 1000);
      const embed = new EmbedBuilder()
        .setColor(config.colors?.secondary || '#4169E1')
        .setTitle(`🌐 Urban Dictionary: ${entry.word}`)
        .setURL(entry.permalink)
        .addFields(
          { name: '📖 Định nghĩa', value: clean(entry.definition) || 'N/A' },
          { name: '💬 Ví dụ', value: clean(entry.example) || 'N/A' },
          { name: '👍 / 👎', value: `${entry.thumbs_up} / ${entry.thumbs_down}`, inline: true }
        )
        .setFooter({ text: `Viết bởi ${entry.author} • ${config.footer || 'Stela Network'}` });

      return isSlash ? interactionOrMessage.editReply({ embeds: [embed] }) : interactionOrMessage.reply({ embeds: [embed] });
    } catch {
      const err = `❌ Không tìm thấy **${term}** trên Urban Dictionary!`;
      return isSlash ? interactionOrMessage.editReply({ content: err }) : interactionOrMessage.reply(err);
    }
  }
};
