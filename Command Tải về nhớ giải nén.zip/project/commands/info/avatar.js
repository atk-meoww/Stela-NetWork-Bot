'use strict';
const { EmbedBuilder, SlashCommandBuilder } = require('discord.js');
const config = require('../../config.json');
const { getMember } = require('../../handlers/utils');

module.exports = {
  name: 'avatar',
  enabled: true,
  description: 'Xem avatar người dùng',
  category: 'Info',
  aliases: ['av', 'pfp'],
  usage: '!avatar [@user]',
  cooldown: 5,
  prefixSupport: true,
  data: new SlashCommandBuilder()
    .setName('avatar').setDescription('Xem avatar người dùng')
    .addUserOption(o => o.setName('user').setDescription('Người dùng (bỏ trống = bản thân)').setRequired(false))
    .setDMPermission(false),

  async execute(interactionOrMessage, args, client) {
    const isSlash = !!interactionOrMessage.isChatInputCommand?.();
    let member;
    if (isSlash) {
      member = interactionOrMessage.options.getMember('user') || interactionOrMessage.member;
      await interactionOrMessage.deferReply();
    } else {
      member = (args[0] ? await getMember(interactionOrMessage.guild, args[0]) : null) || interactionOrMessage.member;
    }

    const user      = member.user;
    const avatarURL = user.displayAvatarURL({ dynamic: true, size: 1024 });

    const embed = new EmbedBuilder()
      .setColor(config.colors?.primary || '#7B2FBE')
      .setTitle(`🖼️ Avatar của ${user.tag || user.username}`)
      .setImage(avatarURL)
      .addFields({ name: '🔗 Link', value:
        `[PNG](${user.displayAvatarURL({ extension: 'png', size: 1024 })}) | ` +
        `[JPG](${user.displayAvatarURL({ extension: 'jpg', size: 1024 })}) | ` +
        `[WEBP](${user.displayAvatarURL({ extension: 'webp', size: 1024 })})` +
        (user.avatar?.startsWith('a_') ? ` | [GIF](${user.displayAvatarURL({ extension: 'gif', size: 1024 })})` : ''), inline: false })
      .setFooter({ text: config.footer || 'Stela Network' }).setTimestamp();

    if (isSlash) await interactionOrMessage.editReply({ embeds: [embed] });
    else await interactionOrMessage.reply({ embeds: [embed] });
  }
};
