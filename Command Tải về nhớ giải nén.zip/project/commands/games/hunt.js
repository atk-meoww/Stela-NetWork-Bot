'use strict';
const _0x639cd3={0x3a30:0x3af6,_:!0};void(0xfe);
const { EmbedBuilder, SlashCommandBuilder } = require('discord.js');
const config = require('../../config.json');
const db = require('../../database');
const { formatNumber } = require('../../handlers/utils');

const MONSTERS = [
  { name: '🐀 Chuột đồng',   rarity: 'Thường',    chance: 30, min: 20,   max: 80,   xp: 10  },
  { name: '🐺 Sói xám',       rarity: 'Thường',    chance: 25, min: 60,   max: 150,  xp: 20  },
  { name: '🦁 Sư tử',         rarity: 'Hiếm',      chance: 18, min: 120,  max: 300,  xp: 40  },
  { name: '🐉 Rồng nhỏ',      rarity: 'Hiếm',      chance: 12, min: 300,  max: 700,  xp: 80  },
  { name: '👹 Quỷ đỏ',        rarity: 'Sử thi',    chance: 8,  min: 600,  max: 1200, xp: 150 },
  { name: '🧟 Zombie khổng lồ',rarity: 'Sử thi',   chance: 5,  min: 1000, max: 2000, xp: 250 },
  { name: '🐲 Rồng cổ đại',   rarity: 'Huyền thoại',chance: 2,  min: 3000, max: 6000, xp: 500 },
];

const OUTCOMES = [
  { result: 'win',   weight: 60, label: 'Chiến thắng! ⚔️' },
  { result: 'crit',  weight: 20, label: 'Chí mạng! 💥' },
  { result: 'miss',  weight: 10, label: 'Trượt đòn! 🙈' },
  { result: 'lose',  weight: 10, label: 'Thất bại! 💀' },
];

const RARITY_COLOR = { 'Thường': 0x95A5A6, 'Hiếm': 0x3498DB, 'Sử thi': 0x9B59B6, 'Huyền thoại': 0xFF0000 };
const COOLDOWN_MS = 45_000;
const huntCooldowns = new Map();
// Auto-cleanup huntCooldowns mỗi 10 phút để tránh memory leak
setInterval(() => huntCooldowns.clear(), 600000);

function roll(arr) {
  const total = arr.reduce((s, x) => s + x.weight, 0);
  let r = Math.random() * total;
  for (const x of arr) { r -= x.weight; if (r <= 0) return x; }
  return arr[0];
}

function rollMonster() {
  const r = Math.random() * 100;
  let cum = 0;
  for (const m of MONSTERS) {
    cum += m.chance;
    if (r < cum) return m;
  }
  return MONSTERS[0];
}

module.exports = {
  name: 'hunt',
  enabled: true,
  description: 'Săn quái vật kiếm tiền',
  category: 'Games',
  aliases: ['san', 'hunting', 'săn'],
  usage: '!hunt',
  prefixSupport: true,
  data: new SlashCommandBuilder()
    .setName('hunt').setDescription('Đi săn 🏹')
    .setDMPermission(false),
  cooldown: 3,
  async execute(interactionOrMessage, args, client) {
    const userId = interactionOrMessage.author.id;
    const now    = Date.now();
    const rem    = COOLDOWN_MS - (now - (huntCooldowns.get(userId) || 0));
    if (rem > 0 && huntCooldowns.has(userId)) return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(0xFF8C00)
      .setDescription(`⚔️ Chờ **${(rem/1000).toFixed(0)}s** để phục hồi sức lực!`).setFooter({ text: config.footer || 'Stela Network' })] });

    huntCooldowns.set(userId, now);
    const monster = rollMonster();
    const outcome = roll(OUTCOMES);
    const user    = db.getUser(userId);

    let earned = 0, gainedXP = 0, desc = '';

    if (outcome.result === 'win') {
      earned   = Math.floor(Math.random() * (monster.max - monster.min + 1)) + monster.min;
      gainedXP = monster.xp;
      desc = `Bạn đã đánh bại **${monster.name}** và nhận phần thưởng!`;
    } else if (outcome.result === 'crit') {
      earned   = Math.floor((Math.random() * (monster.max - monster.min + 1) + monster.min) * 2);
      gainedXP = monster.xp * 2;
      desc = `💥 CHÍ MẠNG! Bạn hạ gục **${monster.name}** trong một đòn!`;
    } else if (outcome.result === 'miss') {
      earned   = Math.floor((Math.random() * (monster.max - monster.min + 1) + monster.min) * 0.3);
      gainedXP = Math.floor(monster.xp * 0.5);
      desc = `😅 Trượt đòn nhưng vẫn gây được ít sát thương, **${monster.name}** bỏ chạy!`;
    } else {
      earned   = -Math.floor(Math.random() * 50 + 10);
      gainedXP = 5;
      desc = `💀 Bạn bị **${monster.name}** đánh bại và mất một ít tiền chữa thương!`;
    }

    user.money    = Math.max(0, (user.money||0) + earned);
    user.xp       = (user.xp||0) + gainedXP;
    user.totalXP  = (user.totalXP||0) + gainedXP;
    if (earned > 0) user.totalEarned = (user.totalEarned||0) + earned;
    db.saveUser(userId, user);

    // Quest + Weekly event hooks
    try { require('./quest').updateQuestProgress(userId, 'hunt', 1); } catch {}
    try {
      const we = require('../../events/weeklyEvent');
      if (we.isEventActive() && we.getCurrentEvent()?.type === 'hunt_x2') {
        const u2 = db.getUser(userId);
        u2.money = (u2.money||0) + Math.abs(earned);
        u2.totalEarned = (u2.totalEarned||0) + Math.abs(earned);
        db.saveUser(userId, u2);
        earned = earned > 0 ? earned * 2 : earned;
      }
    } catch {}

    const color = outcome.result === 'lose' ? 0xFF4757 : outcome.result === 'crit' ? 0xFFD700 : RARITY_COLOR[monster.rarity];

    interactionOrMessage.reply({ embeds: [new EmbedBuilder()
      .setColor(color)
      .setTitle(`⚔️ ${outcome.label}`)
      .setDescription(desc)
      .addFields(
        { name: '👹 Quái vật', value: `${monster.name}\n*${monster.rarity}*`, inline: true },
        { name: earned >= 0 ? '💰 Nhận được' : '💸 Mất đi', value: `**${formatNumber(Math.abs(earned))} 🪙**`, inline: true },
        { name: '⭐ XP', value: `**+${gainedXP} XP**`, inline: true }
      )
      .setFooter({ text: `${config.footer} • Cooldown 45s` })
      .setTimestamp()] });
  }
};
