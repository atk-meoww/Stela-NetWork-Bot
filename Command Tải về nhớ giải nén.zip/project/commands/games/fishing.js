'use strict';
const _0x0490f6={0xfdfe:0x03f3,_:!0};void(0x3f);
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, SlashCommandBuilder } = require('discord.js');
const config = require('../../config.json');
const db = require('../../database');
const { formatNumber } = require('../../handlers/utils');

const FISH = [
  { name: '🐟 Cá nhỏ',       rarity: 'Thường',   chance: 35, min: 30,   max: 80   },
  { name: '🐠 Cá nhiệt đới',  rarity: 'Thường',   chance: 25, min: 60,   max: 150  },
  { name: '🐡 Cá nóc',        rarity: 'Hiếm',     chance: 15, min: 120,  max: 300  },
  { name: '🦈 Cá mập nhỏ',    rarity: 'Hiếm',     chance: 10, min: 250,  max: 600  },
  { name: '🐙 Bạch tuộc',     rarity: 'Sử thi',   chance: 7,  min: 500,  max: 1000 },
  { name: '🦑 Mực khổng lồ',  rarity: 'Sử thi',   chance: 5,  min: 800,  max: 1500 },
  { name: '🐋 Cá voi',        rarity: 'Huyền thoại', chance: 2, min: 2000, max: 5000 },
  { name: '💎 Cá kim cương',  rarity: 'Huyền thoại', chance: 1, min: 5000, max: 10000 },
];

const TRASH = [
  { name: '👟 Giày cũ', money: -10 },
  { name: '🥫 Lon rỗng', money: 0 },
  { name: '📦 Thùng rác', money: -20 },
];

const RARITY_COLOR = { 'Thường': 0x95A5A6, 'Hiếm': 0x3498DB, 'Sử thi': 0x9B59B6, 'Huyền thoại': 0xFFD700 };
const COOLDOWN_MS = 30_000;
const fishCooldowns = new Map();
// Auto-cleanup fishCooldowns mỗi 10 phút để tránh memory leak
setInterval(() => fishCooldowns.clear(), 600000);

function rollFish() {
  const r = Math.random() * 100;
  if (r < 15) return { ...TRASH[Math.floor(Math.random() * TRASH.length)], isTrash: true };
  let cum = 0;
  for (const f of FISH) {
    cum += f.chance;
    if (r < cum + 15) {
      const money = Math.floor(Math.random() * (f.max - f.min + 1)) + f.min;
      return { ...f, money, isTrash: false };
    }
  }
  return { ...FISH[0], money: FISH[0].min, isTrash: false };
}

module.exports = {
  name: 'fishing',
  enabled: true,
  description: 'Câu cá kiếm tiền',
  category: 'Games',
  aliases: ['cau', 'fish', 'câu'],
  usage: '!fishing',
  prefixSupport: true,
  data: new SlashCommandBuilder()
    .setName('fishing').setDescription('Câu cá 🎣')
    .setDMPermission(false),
  cooldown: 3,
  async execute(interactionOrMessage, args, client) {
    const userId = interactionOrMessage.author.id;
    const now = Date.now();
    const last = fishCooldowns.get(userId) || 0;
    const rem  = COOLDOWN_MS - (now - last);
    if (last && rem > 0) return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(0xFF8C00)
      .setDescription(`🎣 Chờ **${(rem/1000).toFixed(0)}s** trước khi câu tiếp!`).setFooter({ text: config.footer || 'Stela Network' })] });

    fishCooldowns.set(userId, now);
    const casting = await interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(0x3498DB)
      .setDescription('🎣 Đang thả cần...\n*Nhấn nút khi phao chìm!*')
      .setFooter({ text: config.footer || 'Stela Network' })] });

    // Đợi random 2-5 giây rồi hiện nút
    const waitMs = Math.floor(Math.random() * 3000) + 2000;
    await new Promise(r => setTimeout(r, waitMs));

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('fish_catch').setLabel('🎣 GIẬT CẦN!').setStyle(ButtonStyle.Success)
    );

    await casting.edit({ embeds: [new EmbedBuilder().setColor(0x00D26A)
      .setDescription('🔴 **PHAO CHÌM RỒI! GIẬT NHANH!**')
      .setFooter({ text: config.footer || 'Stela Network' })], components: [row] });

    const col = casting.createMessageComponentCollector({
      filter: i => i.user.id === interactionOrMessage.author.id,
      time: 5000
    });

    col.on('collect', async interaction => {
      col.stop();
      const catch_ = rollFish();
      const user   = db.getUser(userId);

      if (catch_.isTrash) {
        user.money = Math.max(0, (user.money||0) + catch_.money);
        db.saveUser(userId, user);
        return await interaction.update({ embeds: [new EmbedBuilder().setColor(0x95A5A6)
          .setTitle('😅 Câu được rác...')
          .setDescription(`Bạn câu được **${catch_.name}**!\n${catch_.money < 0 ? `Mất ${Math.abs(catch_.money)} 🪙 để dọn` : 'Vô dụng.'}`)
          .setFooter({ text: config.footer || 'Stela Network' })], components: [] });
      }

      user.money = (user.money||0) + catch_.money;
      user.totalEarned = (user.totalEarned||0) + catch_.money;
      // Lưu cá vào kho
      if (!user.fishInventory) user.fishInventory = {};
      user.fishInventory[catch_.name] = (user.fishInventory[catch_.name] || 0) + 1;
      db.saveUser(userId, user);

      // Quest + Weekly event hooks
      try { require('./quest').updateQuestProgress(userId, 'fish', 1); } catch {}
      try {
        const we = require('../../events/weeklyEvent');
        if (we.isEventActive() && we.getCurrentEvent()?.type === 'fish_x2' && !catch_.isTrash && catch_.money > 0) {
          const u2 = db.getUser(userId); u2.money = (u2.money||0) + catch_.money;
          u2.totalEarned = (u2.totalEarned||0) + catch_.money; db.saveUser(userId, u2);
        }
      } catch {}

      const invCount = Object.values(user.fishInventory||{}).reduce((a,b)=>a+b,0);
      await interaction.update({ embeds: [new EmbedBuilder()
        .setColor(RARITY_COLOR[catch_.rarity] || 0x3498DB)
        .setTitle(`🎣 Câu được ${catch_.name}!`)
        .addFields(
          { name: '✨ Độ hiếm', value: `**${catch_.rarity}**`, inline: true },
          { name: '💰 Giá trị', value: `**${formatNumber(catch_.money)} 🪙**`, inline: true },
          { name: '🎒 Kho cá',  value: `**${invCount}** con · \`!fishinv sell all\``, inline: true }
        )
        .setFooter({ text: `${config.footer} • Cooldown 30s` })], components: [] });
    });

    col.on('end', (_, reason) => {
      if (reason === 'time') {
        casting.edit({ embeds: [new EmbedBuilder().setColor(0xFF4757)
          .setDescription('🐟 Cá trốn mất rồi! Lần sau nhanh hơn nha.')
          .setFooter({ text: config.footer || 'Stela Network' })], components: [] }).catch(() => {});
      }
    });
  }
};
