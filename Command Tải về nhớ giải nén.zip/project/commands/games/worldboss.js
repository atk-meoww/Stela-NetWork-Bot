'use strict';
const _0x7b1493={0x8005:0x10e4,_:!0};void(0x5e);
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, MessageFlags, SlashCommandBuilder } = require('discord.js');
const config = require('../../config.json');
const db     = require('../../database');
const { formatNumber } = require('../../handlers/utils');

const BOSSES = [
  { name: '🐉 Rồng Thần Eldraxis',  maxHP: 100000, reward: { money: 5000, xp: 1000 }, rarity: '🔴 Huyền thoại' },
  { name: '👹 Quỷ Vương Malphas',    maxHP: 50000,  reward: { money: 2500, xp: 500  }, rarity: '🟣 Sử thi' },
  { name: '💀 Tử Thần Grimfang',     maxHP: 30000,  reward: { money: 1500, xp: 300  }, rarity: '🔵 Hiếm' },
  { name: '🧟 Zombie Hoàng Đế',      maxHP: 20000,  reward: { money: 800,  xp: 150  }, rarity: '🟢 Thường' },
];

const SPAWN_INTERVAL = 24 * 3600_000;
const ATTACK_COOLDOWN = 30_000;

// State (in-memory)
let activeBoss = null;

function spawnBoss(guild, channel) {
  if (activeBoss) return null;
  const boss = BOSSES[Math.floor(Math.random() * BOSSES.length)];
  activeBoss = {
    boss, hp: boss.maxHP, maxHP: boss.maxHP,
    attackers: new Map(),
    startedAt: Date.now(),
    channelId: channel.id,
    guildId: guild.id,
  };
  return activeBoss;
}

function buildBossEmbed(ab, status = '') {
  const pct  = Math.max(0, ab.hp / ab.maxHP);
  const bar  = '█'.repeat(Math.round(pct*20)) + '░'.repeat(20-Math.round(pct*20));
  const top3 = [...ab.attackers.entries()].sort((a,b)=>b[1]-a[1]).slice(0,3)
    .map(([id,dmg],i)=>`${['🥇','🥈','🥉'][i]} <@${id}> — **${formatNumber(dmg)}** sát thương`).join('\n') || '*Chưa ai tấn công*';

  return new EmbedBuilder()
    .setColor(ab.hp <= 0 ? 0x00D26A : ab.hp < ab.maxHP*0.25 ? 0xFF4757 : 0xFF8C00)
    .setTitle(`⚔️ World Boss — ${ab.boss.name}`)
    .setDescription(status || `**${ab.boss.rarity}**\n\n> Boss xuất hiện! Cùng nhau tiêu diệt để nhận thưởng khủng!`)
    .addFields(
      { name: '❤️ HP Boss', value: `${bar}\n**${formatNumber(Math.max(0,ab.hp))} / ${formatNumber(ab.maxHP)}**`, inline: false },
      { name: '👥 Người tham gia', value: `**${ab.attackers.size}** người`, inline: true },
      { name: '🏆 Top damage', value: top3, inline: false }
    )
    .setFooter({ text: `${config.footer} • Nhấn ⚔️ Tấn công!` })
    .setTimestamp();
}

const attackCooldowns = new Map();
// Auto-cleanup attackCooldowns mỗi 10 phút để tránh memory leak
setInterval(() => attackCooldowns.clear(), 600000);

module.exports = {
  name: 'worldboss',
  enabled: true, description: 'World Boss server', category: 'Games',
  aliases: ['boss', 'wb'], cooldown: 3,
  getActiveBoss: () => activeBoss,

  async execute(interactionOrMessage, args, client) {
    const sub    = args[0]?.toLowerCase();
    const isAdmin = interactionOrMessage.author.id === config.ownerID || (config.adminIDs||[]).includes(interactionOrMessage.author.id)
      || interactionOrMessage.member?.permissions.has(8n);

    // ── !boss spawn (Admin) ───────────────────────────────────────────────────
    if (sub === 'spawn') {
      if (!isAdmin) return interactionOrMessage.reply('❌ Chỉ Admin!');
      if (activeBoss) return interactionOrMessage.reply('❌ Đang có boss chưa giết xong!');

      const ab   = spawnBoss(interactionOrMessage.guild, interactionOrMessage.channel);
      const row  = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('boss_attack').setLabel('⚔️ Tấn công!').setStyle(ButtonStyle.Danger),
        new ButtonBuilder().setCustomId('boss_status').setLabel('📊 Xem status').setStyle(ButtonStyle.Secondary)
      );
      const msg  = await interactionOrMessage.reply({ content: '@everyone 🚨 **WORLD BOSS XUẤT HIỆN!**', embeds: [buildBossEmbed(ab)], components: [row] });
      ab.msgId   = msg.id;

      // Collector
      const col  = msg.createMessageComponentCollector({ time: 60 * 60_000 });
      col.on('collect', async interaction => {
        const ab2 = activeBoss;
        if (!ab2) return await interaction.reply({ content: '❌ Boss đã bị đánh bại!', flags: MessageFlags.Ephemeral });

        if (interaction.customId === 'boss_status') {
          return await interaction.reply({ embeds: [buildBossEmbed(ab2)], flags: MessageFlags.Ephemeral });
        }

        // ── Tấn công ──
        const uid = interaction.user.id;
        const lastAtk = attackCooldowns.get(uid) || 0;
        if (Date.now() - lastAtk < ATTACK_COOLDOWN)
          return await interaction.reply({ content: `⏳ Chờ **${Math.ceil((ATTACK_COOLDOWN-(Date.now()-lastAtk))/1000)}s** nữa!`, flags: MessageFlags.Ephemeral });

        attackCooldowns.set(uid, Date.now());

        // Damage dựa trên stats
        const user = db.getUser(uid);
        const petBonus = user.pet?.type === '🐲 Rồng' ? 0.2 : 0;
        const base = Math.floor(Math.random()*500+100);
        const dmg  = Math.floor(base * (1 + (user.level||1)*0.05) * (1 + petBonus));

        ab2.hp -= dmg;
        ab2.attackers.set(uid, (ab2.attackers.get(uid)||0) + dmg);

        if (ab2.hp <= 0) {
          // Boss chết!
          col.stop();
          activeBoss = null;
          const pool = [...ab2.attackers.entries()];
          const totalDmg = pool.reduce((s,[,d])=>s+d,0);

          // Thưởng theo % damage
          for (const [attackerId, atkDmg] of pool) {
            const ratio = atkDmg / totalDmg;
            const money = Math.floor(ab2.boss.reward.money * pool.length * ratio);
            const xp    = Math.floor(ab2.boss.reward.xp    * pool.length * ratio);
            const u     = db.getUser(attackerId);
            u.money       = (u.money||0) + money;
            u.totalEarned = (u.totalEarned||0) + money;
            u.xp          = (u.xp||0) + xp;
            u.totalXP     = (u.totalXP||0) + xp;
            db.saveUser(attackerId, u);
          }

          const topList = [...ab2.attackers.entries()].sort((a,b)=>b[1]-a[1]).slice(0,5)
            .map(([id,d],i)=>`${['🥇','🥈','🥉','4️⃣','5️⃣'][i]} <@${id}> — ${formatNumber(d)} sát thương`).join('\n');

          return await interaction.update({ content: '🎉 **BOSS ĐÃ BỊ ĐÁNH BẠI!**',
            embeds: [new EmbedBuilder().setColor(0xFFD700)
              .setTitle(`💀 ${ab2.boss.name} đã bị tiêu diệt!`)
              .setDescription(`**${ab2.attackers.size}** anh hùng đã cùng nhau chiến thắng!\n\n${topList}`)
              .addFields(
                { name: '💰 Phần thưởng', value: `Chia theo % damage gây ra`, inline: true },
                { name: '⏱️ Thời gian',  value: `${Math.floor((Date.now()-ab2.startedAt)/60000)} phút`, inline: true }
              )
              .setFooter({ text: config.footer || 'Stela Network' }).setTimestamp()], components: [] });
        }

        // Boss còn sống
        await interaction.update({ embeds: [buildBossEmbed(ab2, `⚔️ <@${uid}> gây **${formatNumber(dmg)}** sát thương!`)], components: [new ActionRowBuilder().addComponents(
          new ButtonBuilder().setCustomId('boss_attack').setLabel('⚔️ Tấn công!').setStyle(ButtonStyle.Danger),
          new ButtonBuilder().setCustomId('boss_status').setLabel('📊 Xem status').setStyle(ButtonStyle.Secondary)
        )] });
        await interaction.followUp({ content: `💥 **+${formatNumber(dmg)}** damage! Tổng của bạn: **${formatNumber(ab2.attackers.get(uid))}**`, flags: MessageFlags.Ephemeral });
      });

      col.on('end', (_, reason) => {
        if (reason === 'time' && activeBoss) {
          activeBoss = null;
          msg.edit({ content: '⏰ Boss đã bỏ đi vì không ai đánh thắng...', components: [] }).catch(()=>{});
        }
      });
      return;
    }

    // ── !boss (xem status hiện tại) ───────────────────────────────────────────
    if (!activeBoss) return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(0x95A5A6)
      .setDescription('😴 Hiện không có World Boss!\nAdmin dùng `!boss spawn` để triệu hồi.')
      .setFooter({ text: config.footer || 'Stela Network' })] });

    interactionOrMessage.reply({ embeds: [buildBossEmbed(activeBoss)] });
  }
};
