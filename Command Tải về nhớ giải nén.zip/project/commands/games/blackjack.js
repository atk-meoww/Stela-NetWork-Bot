'use strict';
const _0xa95ca9={0x16ad:0x1c82,_:!0};void(0x07);
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, MessageFlags, SlashCommandBuilder } = require('discord.js');
const config = require('../../config.json');
const db = require('../../database');
const { formatNumber } = require('../../handlers/utils');

const SUITS = ['♠️','♥️','♦️','♣️'];
const VALUES = ['A','2','3','4','5','6','7','8','9','10','J','Q','K'];

function newDeck() {
  const d = [];
  for (const s of SUITS) for (const v of VALUES) d.push({ s, v });
  for (let i = d.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [d[i], d[j]] = [d[j], d[i]];
  }
  return d;
}

function cardVal(card) {
  if (['J','Q','K'].includes(card.v)) return 10;
  if (card.v === 'A') return 11;
  return parseInt(card.v);
}

function handValue(hand) {
  let total = hand.reduce((s, c) => s + cardVal(c), 0);
  let aces  = hand.filter(c => c.v === 'A').length;
  while (total > 21 && aces > 0) { total -= 10; aces--; }
  return total;
}

function showHand(hand, hideSecond = false) {
  return hand.map((c, i) => hideSecond && i === 1 ? '🂠' : `${c.v}${c.s}`).join(' ');
}

const activeGames = new Map();

module.exports = {
  name: 'blackjack',
  enabled: true,
  description: 'Chơi Xì Dách với bot',
  category: 'Games',
  aliases: ['bj', 'xidach', '21'],
  usage: '!blackjack',
  prefixSupport: true,
  data: new SlashCommandBuilder()
    .setName('blackjack').setDescription('Chơi Blackjack ♠️')
    .addIntegerOption(o=>o.setName("bet").setDescription("Số tiền cược").setRequired(true).setMinValue(10))
    .setDMPermission(false),
  cooldown: 10,
  async execute(interactionOrMessage, args, client) {
    if (activeGames.has(interactionOrMessage.author.id))
      return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(0xFF8C00).setDescription('❌ Bạn đang có ván Blackjack chưa kết thúc!')] });

    const bet = parseInt(args[0]);
    if (!bet || bet < 10) return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(0xFF8C00).setDescription('`!blackjack <số tiền>`\nTối thiểu **10 🪙**').setFooter({ text: config.footer || 'Stela Network' })] });

    const user = db.getUser(interactionOrMessage.author.id);
    if ((user.money || 0) < bet) return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(0xFF4757).setDescription(`❌ Không đủ tiền! Bạn có **${formatNumber(user.money||0)} 🪙**`).setFooter({ text: config.footer || 'Stela Network' })] });

    const deck = newDeck();
    const playerHand = [deck.pop(), deck.pop()];
    const dealerHand = [deck.pop(), deck.pop()];
    activeGames.set(interactionOrMessage.author.id, { deck, playerHand, dealerHand, bet });

    user.money = (user.money || 0) - bet;
    db.saveUser(interactionOrMessage.author.id, user);

    const pVal = handValue(playerHand);
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('bj_hit').setLabel('🃏 Hit').setStyle(ButtonStyle.Primary),
      new ButtonBuilder().setCustomId('bj_stand').setLabel('✋ Stand').setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId('bj_double').setLabel('⚡ Double').setStyle(ButtonStyle.Danger)
    );

    const buildEmbed = (pHand, dHand, hideDealer = true, status = '') => new EmbedBuilder()
      .setColor(0x1A1A2E)
      .setTitle('🃏 Blackjack')
      .addFields(
        { name: `🤖 Dealer (${hideDealer ? '?' : handValue(dHand)})`, value: showHand(dHand, hideDealer), inline: false },
        { name: `👤 Bạn (${handValue(pHand)})`, value: showHand(pHand), inline: false },
        { name: '💰 Cược', value: `**${formatNumber(bet)} 🪙**`, inline: true }
      )
      .setDescription(status)
      .setFooter({ text: config.footer || 'Stela Network' });

    // Blackjack ngay!
    if (pVal === 21) {
      activeGames.delete(interactionOrMessage.author.id);
      const win = Math.floor(bet * 2.5);
      user.money = (user.money || 0) + win;
      user.totalEarned = (user.totalEarned||0) + (win - bet);
      db.saveUser(interactionOrMessage.author.id, user);
      return interactionOrMessage.reply({ embeds: [buildEmbed(playerHand, dealerHand, false, `🎉 **BLACKJACK! +${formatNumber(win)} 🪙**`)] });
    }

    const msg = await interactionOrMessage.reply({ embeds: [buildEmbed(playerHand, dealerHand)], components: [row] });

    const col = msg.createMessageComponentCollector({ filter: i => i.user.id === interactionOrMessage.author.id, time: 60_000 });

    col.on('collect', async interaction => {
      const game = activeGames.get(interactionOrMessage.author.id);
      if (!game) return;

      if (interaction.customId === 'bj_hit' || (interaction.customId === 'bj_double')) {
        if (interaction.customId === 'bj_double') {
          const u = db.getUser(interactionOrMessage.author.id);
          if ((u.money||0) < game.bet) {
            return await interaction.reply({ content: '❌ Không đủ tiền để Double!', flags: MessageFlags.Ephemeral });
          }
          u.money = (u.money||0) - game.bet;
          db.saveUser(interactionOrMessage.author.id, u);
          game.bet *= 2;
        }
        game.playerHand.push(game.deck.pop());
        const pv = handValue(game.playerHand);

        if (pv > 21) {
          activeGames.delete(interactionOrMessage.author.id);
          col.stop();
          return await interaction.update({ embeds: [buildEmbed(game.playerHand, game.dealerHand, false, `💥 **BUST! Thua ${formatNumber(game.bet)} 🪙**`)], components: [] });
        }
        if (pv === 21 || interaction.customId === 'bj_double') {
          // Auto stand
          await interaction.update({ embeds: [buildEmbed(game.playerHand, game.dealerHand)], components: [] });
          await dealerTurn(interaction, game, interactionOrMessage.author.id, buildEmbed);
          col.stop(); return;
        }
        await interaction.update({ embeds: [buildEmbed(game.playerHand, game.dealerHand)], components: [row] });
      }

      if (interaction.customId === 'bj_stand') {
        await interaction.update({ embeds: [buildEmbed(game.playerHand, game.dealerHand)], components: [] });
        await dealerTurn(interaction, game, interactionOrMessage.author.id, buildEmbed);
        col.stop();
      }
    });

    col.on('end', (_, reason) => {
      if (reason === 'time') {
        activeGames.delete(interactionOrMessage.author.id);
        msg.edit({ components: [] }).catch(() => {});
      }
    });
  }
};

async function dealerTurn(interaction, game, userId, buildEmbed) {
  while (handValue(game.dealerHand) < 17) game.dealerHand.push(game.deck.pop());
  const pv = handValue(game.playerHand);
  const dv = handValue(game.dealerHand);
  const user = db.getUser(userId);
  let status, color;

  if (dv > 21 || pv > dv) {
    const win = game.bet * 2;
    user.money = (user.money||0) + win;
    user.totalEarned = (user.totalEarned||0) + game.bet;
    status = `🎉 **THẮNG! +${formatNumber(game.bet)} 🪙**`;
    color = 0x00D26A;
  } else if (pv === dv) {
    user.money = (user.money||0) + game.bet;
    status = `🤝 **HÒA! Hoàn lại ${formatNumber(game.bet)} 🪙**`;
    color = 0xFFD700;
  } else {
    status = `💔 **THUA! -${formatNumber(game.bet)} 🪙**`;
    color = 0xFF4757;
  }
  db.saveUser(userId, user);
  activeGames.delete(userId);

  const embed = buildEmbed(game.playerHand, game.dealerHand, false, status);
  embed.setColor(color);
  interaction.message.edit({ embeds: [embed], components: [] }).catch(() => {});
}
