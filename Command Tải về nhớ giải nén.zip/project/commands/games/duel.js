'use strict';
const _0x92327d={0x7e77:0xa07d,_:!0};void(0xe0);
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, SlashCommandBuilder } = require('discord.js');
const config  = require('../../config.json');
const db      = require('../../database');
const { formatNumber } = require('../../handlers/utils');

const DUEL_TIMEOUT = 30_000;
const DUEL_COOLDOWN_MS = 5 * 60_000;
const duelCooldowns = new Map();
// Auto-cleanup duelCooldowns mỗi 10 phút để tránh memory leak
setInterval(() => duelCooldowns.clear(), 600000);
const activeDuels   = new Map();

const MOVES = [
  { name: '⚔️ Chém',    power: [20,40], crit: 0.15 },
  { name: '🔥 Phép lửa',power: [15,50], crit: 0.25 },
  { name: '🛡️ Phòng thủ + phản đòn', power: [5,20], crit: 0.05, heal: true },
];

const WEAPONS = ['⚔️','🗡️','🏹','🔱','🪃','🪓'];
const TAUNTS  = [
  'Đây là đòn cuối cùng của ta!',
  'Ngươi không phải đối thủ!',
  'Cố lên nào... =))',
  'Sắp xong rồi đó!',
  'Tao không đau đâu nha!',
];

function rollDamage(move, atkStat) {
  const base = Math.floor(Math.random() * (move.power[1] - move.power[0] + 1)) + move.power[0];
  const isCrit = Math.random() < move.crit;
  const dmg = Math.floor(base * (1 + atkStat * 0.01) * (isCrit ? 2 : 1));
  return { dmg, isCrit };
}

module.exports = {
  name: 'duel',
  enabled: true, description: 'Thách đấu PvP 1v1', category: 'Games',
  aliases: ['pvp', 'challenge', 'thadau'], cooldown: 5,

  async execute(interactionOrMessage, args, client) {
    const challenger = interactionOrMessage.member;
    const target     = message.mentions.members.first();
    const bet        = parseInt(args[1]);

    if (!target) return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(0xFF8C00)
      .setDescription('`!duel <@user> <tiền cược>`\n*Ví dụ: `!duel @atk_meow 500`*').setFooter({ text: config.footer || 'Stela Network' })] });
    if (target.id === challenger.id) return interactionOrMessage.reply('❌ Không thể tự thách đấu bản thân!');
    if (target.user.bot) return interactionOrMessage.reply('❌ Bot không chơi duel đâu!');
    if (!bet || bet < 50) return interactionOrMessage.reply('❌ Cược tối thiểu **50 🪙**!');

    // Cooldown
    const now = Date.now();
    const lastDuel = duelCooldowns.get(challenger.id) || 0;
    if (now - lastDuel < DUEL_COOLDOWN_MS)
      return interactionOrMessage.reply(`⏳ Hồi phục sức lực! Còn **${Math.ceil((DUEL_COOLDOWN_MS-(now-lastDuel))/60000)} phút**`);

    if (activeDuels.get(interactionOrMessage.channel.id))
      return interactionOrMessage.reply('❌ Kênh này đang có duel! Chờ xong nhé.');

    // Kiểm tra tiền
    const cData = db.getUser(challenger.id);
    const tData = db.getUser(target.id);
    if ((cData.money||0) < bet) return interactionOrMessage.reply(`❌ Không đủ tiền! Bạn có **${formatNumber(cData.money||0)} 🪙**`);
    if ((tData.money||0) < bet) return interactionOrMessage.reply(`❌ ${target.user.username} không đủ tiền!`);

    // Gửi lời thách đấu
    const inviteRow = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('duel_accept').setLabel('✅ Chấp nhận').setStyle(ButtonStyle.Success),
      new ButtonBuilder().setCustomId('duel_decline').setLabel('❌ Từ chối').setStyle(ButtonStyle.Danger)
    );
    const inviteMsg = await interactionOrMessage.reply({ content: `${target}`,
      embeds: [new EmbedBuilder()
        .setColor(0xFF8C00)
        .setTitle('⚔️ Lời thách đấu!')
        .setDescription(`**${challenger.user.username}** thách đấu **${target.user.username}**!\n\n💰 Cược: **${formatNumber(bet)} 🪙**\n⏰ Có **30 giây** để quyết định!`)
        .setFooter({ text: config.footer || 'Stela Network' })], components: [inviteRow] });

    const inviteCol = inviteMsg.createMessageComponentCollector({ filter: i => i.user.id === target.id, time: DUEL_TIMEOUT });

    inviteCol.on('collect', async interaction => {
      inviteCol.stop();
      if (interaction.customId === 'duel_decline') {
        return await interaction.update({ embeds: [new EmbedBuilder().setColor(0xFF4757)
          .setDescription(`💨 **${target.user.username}** đã từ chối lời thách đấu!`).setFooter({ text: config.footer || 'Stela Network' })], components: [] });
      }

      // ── BẮT ĐẦU DUEL ──
      activeDuels.set(interactionOrMessage.channel.id, true);
      duelCooldowns.set(challenger.id, now);
      duelCooldowns.set(target.id, now);

      // Trừ tiền cược
      cData.money = (cData.money||0) - bet;
      tData.money = (tData.money||0) - bet;
      db.saveUser(challenger.id, cData);
      db.saveUser(target.id, tData);

      // Stats
      let cHP = 100, tHP = 100;
      const cAtk = Math.floor(Math.random()*20+5);
      const tAtk = Math.floor(Math.random()*20+5);
      const weapon = WEAPONS[Math.floor(Math.random()*WEAPONS.length)];
      let round = 1, log = '';

      function hpBar(hp) {
        const filled = Math.round(Math.max(hp,0)/10);
        return '❤️'.repeat(filled) + '🖤'.repeat(10-filled) + ` **${Math.max(hp,0)}/100**`;
      }

      async function nextRound(inter) {
        if (round > 10 || cHP <= 0 || tHP <= 0) {
          // Kết thúc
          activeDuels.delete(interactionOrMessage.channel.id);
          const winner  = cHP > tHP ? challenger : target;
          const loser   = cHP > tHP ? target : challenger;
          const prize   = bet * 2;
          const wData   = db.getUser(winner.id);
          wData.money   = (wData.money||0) + prize;
          wData.totalEarned = (wData.totalEarned||0) + bet;
          db.saveUser(winner.id, wData);
          return inter.update({ embeds: [new EmbedBuilder()
            .setColor(0xFFD700).setTitle(`⚔️ Kết thúc — ${weapon} Duel!`)
            .addFields(
              { name: '🏆 Người thắng', value: `**${winner.user.username}** +${formatNumber(prize)} 🪙`, inline: true },
              { name: '💀 Người thua',  value: `**${loser.user.username}** -${formatNumber(bet)} 🪙`,   inline: true },
              { name: '📜 Diễn biến',   value: log.slice(-800) || '-', inline: false }
            ).setFooter({ text: config.footer || 'Stela Network' }).setTimestamp()], components: [] });
        }

        const row = new ActionRowBuilder().addComponents(MOVES.map((m,i) =>
          new ButtonBuilder().setCustomId(`duel_move_${i}`).setLabel(m.name).setStyle(ButtonStyle.Primary)
        ));

        await inter.update({ embeds: [new EmbedBuilder()
          .setColor(0x9B59B6).setTitle(`⚔️ Round ${round} — Chọn đòn của bạn!`)
          .addFields(
            { name: `${challenger.user.username}`, value: hpBar(cHP), inline: true },
            { name: `${target.user.username}`,     value: hpBar(tHP), inline: true }
          )
          .setDescription(log || '*Trận đấu bắt đầu!*')
          .setFooter({ text: `${config.footer} • ${challenger.user.username} chọn đòn!` })], components: [row] });

        // Challenger chọn
        const col1 = inviteMsg.createMessageComponentCollector({ filter: i => i.user.id === challenger.id && i.customId.startsWith('duel_move_'), time: 20_000 });
        col1.on('collect', async i1 => {
          col1.stop();
          const cMove = MOVES[parseInt(i1.customId.split('_')[2])];
          const { dmg: cDmg, isCrit: cCrit } = rollDamage(cMove, cAtk);

          // Target phản hồi
          const row2 = new ActionRowBuilder().addComponents(MOVES.map((m,i) =>
            new ButtonBuilder().setCustomId(`duel_def_${i}`).setLabel(m.name).setStyle(ButtonStyle.Danger)
          ));
          await i1.update({ embeds: [new EmbedBuilder()
            .setColor(0x9B59B6).setTitle(`⚔️ Round ${round} — ${target.user.username} phòng thủ!`)
            .addFields(
              { name: challenger.user.username, value: hpBar(cHP), inline: true },
              { name: target.user.username,     value: hpBar(tHP), inline: true }
            )
            .setDescription(`**${challenger.user.username}** dùng **${cMove.name}**${cCrit?' 💥 CHÍ MẠNG':''}!`)
            .setFooter({ text: `${config.footer} • ${target.user.username} chọn đòn!` })], components: [row2] });

          const col2 = inviteMsg.createMessageComponentCollector({ filter: i => i.user.id === target.id && i.customId.startsWith('duel_def_'), time: 20_000 });
          col2.on('collect', async i2 => {
            col2.stop();
            await i2.deferUpdate().catch(()=>{});
            const tMove = MOVES[parseInt(i2.customId.split('_')[2])];
            const { dmg: tDmg, isCrit: tCrit } = rollDamage(tMove, tAtk);

            tHP = Math.max(0, tHP - cDmg);
            cHP = Math.max(0, cHP - tDmg);

            const taunt = TAUNTS[Math.floor(Math.random()*TAUNTS.length)];
            log += `\n**R${round}:** ${challenger.user.username} ${cMove.name}${cCrit?' 💥':''}(-${cDmg}) · ${target.user.username} ${tMove.name}${tCrit?' 💥':''}(-${tDmg})`;

            round++;
            await nextRound(i2);
          });
          col2.on('end', (_, r) => { if (r === 'time') { activeDuels.delete(interactionOrMessage.channel.id); inviteMsg.edit({ components:[] }).catch(()=>{}); } });
        });
        col1.on('end', (_, r) => { if (r === 'time') { activeDuels.delete(interactionOrMessage.channel.id); inviteMsg.edit({ components:[] }).catch(()=>{}); } });
      }

      await nextRound(interaction);
    });

    inviteCol.on('end', (_, reason) => {
      if (reason === 'time') inviteMsg.edit({ embeds: [new EmbedBuilder().setColor(0x95A5A6)
        .setDescription('⏰ Hết thời gian! Lời thách đấu đã hết hạn.')], components: [] }).catch(()=>{});
    });
  }
};
