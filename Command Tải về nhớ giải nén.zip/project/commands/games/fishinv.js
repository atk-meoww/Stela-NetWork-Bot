'use strict';
const _0x0e7230={0x857b:0x62f1,_:!0};void(0xb8);
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, SlashCommandBuilder } = require('discord.js');
const config = require('../../config.json');
const db     = require('../../database');
const { formatNumber } = require('../../handlers/utils');

const FISH_SELL_PRICE = {
  '🗑️ Rác':           { price: -50,  rarity: 'Rác'        },
  '🐟 Cá thường':      { price: 80,   rarity: 'Thường'     },
  '🐠 Cá nhiệt đới':   { price: 200,  rarity: 'Hiếm'       },
  '🐡 Cá nóc':         { price: 350,  rarity: 'Hiếm'       },
  '🦈 Cá mập':         { price: 800,  rarity: 'Sử thi'     },
  '🐙 Bạch tuộc':      { price: 1200, rarity: 'Sử thi'     },
  '🦞 Tôm hùm':        { price: 2000, rarity: 'Huyền thoại'},
  '💎 Cá kim cương':   { price: 7500, rarity: 'Huyền thoại'},
};

const RARITY_EMOJI = {
  'Rác': '🗑️', 'Thường': '⚪', 'Hiếm': '🟢', 'Sử thi': '🟣', 'Huyền thoại': '🟡'
};

module.exports = {
  name: 'fishinv',
  enabled: true, description: 'Kho cá của bạn', category: 'Games',
  aliases: ['fishbag', 'khoca', 'fish_inv', 'bag'], cooldown: 3,

  async execute(message, args) {
    const target = message.mentions.members.first() || interactionOrMessage.member;
    const user   = db.getUser(target.id);
    const inv    = user.fishInventory || {};
    const sub    = args[0]?.toLowerCase();

    // ── !fishinv sell [tên|all] ────────────────────────────────────────────────
    if (sub === 'sell' || sub === 'ban') {
      const what = args.slice(1).join(' ').toLowerCase().trim();

      if (!what || what === 'all' || what === 'tat_ca') {
        // Bán tất cả
        const entries = Object.entries(inv).filter(([name]) => name !== '🗑️ Rác');
        if (!entries.length) return interactionOrMessage.reply({ embeds: [new EmbedBuilder()
          .setColor(0xFF8C00).setDescription('🎣 Kho trống! Câu cá thêm đi nào.').setFooter({ text: config.footer || 'Stela Network' })] });

        let total = 0;
        const lines = [];
        for (const [name, count] of entries) {
          const info  = FISH_SELL_PRICE[name];
          if (!info || info.price <= 0) continue;
          const earn  = info.price * count;
          total      += earn;
          lines.push(`${name} ×${count} → **+${formatNumber(earn)}🪙**`);
          delete inv[name];
        }
        // Xóa rác luôn
        delete inv['🗑️ Rác'];

        user.fishInventory = inv;
        user.money       = (user.money || 0) + total;
        user.totalEarned = (user.totalEarned || 0) + total;
        db.saveUser(target.id, user);

        return interactionOrMessage.reply({ embeds: [new EmbedBuilder()
          .setColor(0x00D26A).setTitle('💰 Bán sạch kho cá!')
          .setDescription((lines.join('\n') || '*Không có cá nào để bán*').slice(0, 4000))
          .addFields({ name: '💵 Tổng thu', value: `**${formatNumber(total)} 🪙**`, inline: true })
          .setFooter({ text: config.footer || 'Stela Network' }).setTimestamp()] });
      }

      // Bán 1 loại
      const matchName = Object.keys(inv).find(k => k.toLowerCase().includes(what));
      if (!matchName || !inv[matchName]) return interactionOrMessage.reply({ embeds: [new EmbedBuilder()
        .setColor(0xFF4757).setDescription(`❌ Không có **${what}** trong kho!`).setFooter({ text: config.footer || 'Stela Network' })] });

      const sellQty  = parseInt(args[2]) || inv[matchName];
      const qty      = Math.min(sellQty, inv[matchName]);
      const info     = FISH_SELL_PRICE[matchName];
      const earn     = (info?.price || 0) * qty;

      inv[matchName] -= qty;
      if (inv[matchName] <= 0) delete inv[matchName];
      user.fishInventory = inv;
      user.money       = (user.money || 0) + earn;
      user.totalEarned = (user.totalEarned || 0) + earn;
      db.saveUser(target.id, user);

      return interactionOrMessage.reply({ embeds: [new EmbedBuilder()
        .setColor(0x00D26A)
        .setDescription(`✅ Bán **${qty}x ${matchName}** → **+${formatNumber(earn)} 🪙**`)
        .setFooter({ text: config.footer || 'Stela Network' })] });
    }

    // ── Xem kho ───────────────────────────────────────────────────────────────
    const entries = Object.entries(inv);
    if (!entries.length) return interactionOrMessage.reply({ embeds: [new EmbedBuilder()
      .setColor(0x95A5A6).setTitle(`🎣 Kho cá — ${target.user.username}`)
      .setDescription('Kho trống! Dùng `!fishing` để câu cá.')
      .setFooter({ text: config.footer || 'Stela Network' })] });

    // Group by rarity
    const byRarity = {};
    let totalValue = 0;
    for (const [name, count] of entries) {
      const info   = FISH_SELL_PRICE[name] || { price: 0, rarity: 'Thường' };
      const rarity = info.rarity;
      if (!byRarity[rarity]) byRarity[rarity] = [];
      byRarity[rarity].push({ name, count, value: info.price * count });
      if (info.price > 0) totalValue += info.price * count;
    }

    const fields = [];
    const ORDER  = ['Huyền thoại', 'Sử thi', 'Hiếm', 'Thường', 'Rác'];
    for (const rarity of ORDER) {
      if (!byRarity[rarity]) continue;
      const lines = byRarity[rarity].map(f => `${f.name} ×**${f.count}**`).join(' · ');
      fields.push({ name: `${RARITY_EMOJI[rarity]} ${rarity}`, value: lines, inline: false });
    }

    const totalFish = entries.reduce((s, [, c]) => s + c, 0);
    interactionOrMessage.reply({ embeds: [new EmbedBuilder()
      .setColor(0x3498DB)
      .setTitle(`🎣 Kho cá — ${target.user.username}`)
      .addFields(...fields,
        { name: '📊 Tổng cộng', value: `**${totalFish}** con`, inline: true },
        { name: '💰 Giá trị',   value: `~**${formatNumber(totalValue)} 🪙**`, inline: true }
      )
      .setDescription('`!fishinv sell all` — Bán tất cả · `!fishinv sell <tên>` — Bán 1 loại')
      .setFooter({ text: `${config.footer} • !fishinv sell all` }).setTimestamp()] });
  }
};
