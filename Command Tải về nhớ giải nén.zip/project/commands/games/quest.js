'use strict';
const _0x0c6b61={0xc672:0x40af,_:!0};void(0x58);
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, SlashCommandBuilder } = require('discord.js');
const config = require('../../config.json');
const db = require('../../database');
const { formatNumber } = require('../../handlers/utils');

const QUEST_POOL = [
  { id: 'chat10',   name: '💬 Chém gió',       desc: 'Gửi 10 tin nhắn',           type: 'chat',   target: 10,  reward: { money: 200,  xp: 50  } },
  { id: 'chat30',   name: '💬 Nhà thơ',         desc: 'Gửi 30 tin nhắn',           type: 'chat',   target: 30,  reward: { money: 500,  xp: 100 } },
  { id: 'fish3',    name: '🎣 Cần thủ',          desc: 'Câu 3 con cá',              type: 'fish',   target: 3,   reward: { money: 400,  xp: 80  } },
  { id: 'fish10',   name: '🎣 Ngư dân',          desc: 'Câu 10 con cá',             type: 'fish',   target: 10,  reward: { money: 1000, xp: 200 } },
  { id: 'hunt5',    name: '⚔️ Thợ săn',          desc: 'Săn 5 quái vật',            type: 'hunt',   target: 5,   reward: { money: 600,  xp: 120 } },
  { id: 'hunt15',   name: '⚔️ Chiến binh',       desc: 'Săn 15 quái vật',           type: 'hunt',   target: 15,  reward: { money: 1500, xp: 300 } },
  { id: 'work3',    name: '💼 Chăm chỉ',         desc: 'Làm việc 3 lần',            type: 'work',   target: 3,   reward: { money: 800,  xp: 150 } },
  { id: 'daily1',   name: '📅 Điểm danh',        desc: 'Nhận daily reward',          type: 'daily',  target: 1,   reward: { money: 300,  xp: 60  } },
  { id: 'bj_win3',  name: '🃏 Tay bài đỏ',       desc: 'Thắng 3 ván Blackjack',     type: 'bj_win', target: 3,   reward: { money: 1200, xp: 250 } },
  { id: 'earn2000', name: '💰 Nhà giàu tập sự',  desc: 'Kiếm 2000🪙 trong ngày',    type: 'earn',   target: 2000,reward: { money: 500,  xp: 100 } },
];

function getTodayKey() {
  const d = new Date();
  return `${d.getFullYear()}-${d.getMonth()+1}-${d.getDate()}`;
}

function pickQuests(userId) {
  // Seed theo userId + ngày → cùng người cùng quest mỗi ngày
  const seed = parseInt(userId.slice(-4)) + parseInt(getTodayKey().replace(/-/g,''));
  const rng  = (n) => { const x = Math.sin(seed + n) * 10000; return x - Math.floor(x); };
  const pool = [...QUEST_POOL].sort((a, b) => rng(QUEST_POOL.indexOf(a)) - rng(QUEST_POOL.indexOf(b)));
  return pool.slice(0, 3);
}

function getQuestData(userId) {
  const user = db.getUser(userId);
  const today = getTodayKey();
  if (!user.quests || user.quests.date !== today) {
    user.quests = { date: today, progress: {}, claimed: [] };
    db.saveUser(userId, user);
  }
  return user;
}

// Hàm gọi từ các lệnh khác để cập nhật tiến độ
function updateQuestProgress(userId, type, amount = 1) {
  const user    = getQuestData(userId);
  const quests  = pickQuests(userId);
  let updated   = false;
  for (const q of quests) {
    if (q.type !== type) continue;
    if (user.quests.claimed.includes(q.id)) continue;
    user.quests.progress[q.id] = Math.min(
      (user.quests.progress[q.id] || 0) + amount, q.target
    );
    updated = true;
  }
  // Cũng cập nhật AI quests nếu có
  if (user.aiQuests && user.aiQuests.date === getTodayKey()) {
    const aiQs = user.aiQuests.quests || [];
    for (let i = 0; i < aiQs.length; i++) {
      if (aiQs[i].type !== type) continue;
      if ((user.aiQuests.claimed || []).includes(i)) continue;
      if (!user.aiQuests.progress) user.aiQuests.progress = {};
      user.aiQuests.progress[i] = Math.min(
        (user.aiQuests.progress[i] || 0) + amount, aiQs[i].target
      );
      updated = true;
    }
  }
  if (updated) db.saveUser(userId, user);
}
module.exports.updateQuestProgress = updateQuestProgress;

module.exports = {
  name: 'quest',
  enabled: true, description: 'Nhiệm vụ hàng ngày', category: 'Games',
  aliases: ['quests', 'nhvụ', 'daily_quest'], cooldown: 5,
  updateQuestProgress,

  async execute(interactionOrMessage, args, client) {
    const userId = interactionOrMessage.author.id;
    const user   = getQuestData(userId);
    const quests = pickQuests(userId);

    // !quest ai — tạo nhiệm vụ bằng Gemini AI
    if (args[0] === 'ai' || args[0] === 'aiquests') {
      if (!config.geminiKey) return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(0xFF4757)
        .setDescription('❌ Cần `geminiKey` trong `config.json` để dùng AI Quest!').setFooter({ text: config.footer || 'Stela Network' })] });

      const loading = await interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(0x7B2FBE)
        .setDescription('🔮 Gemini AI đang tạo nhiệm vụ đặc biệt cho bạn...')
        .setFooter({ text: config.footer || 'Stela Network' })] });

      try {
        const aiQuests = await module.exports.getAIQuests(userId, user);

        // Lưu AI quests vào user data để tracking progress
        if (!user.aiQuests || user.aiQuests.date !== getTodayKey()) {
          user.aiQuests = { date: getTodayKey(), quests: aiQuests, progress: {}, claimed: [] };
          db.saveUser(userId, user);
        }

        const fields = aiQuests.map((q, i) => {
          const prog    = user.aiQuests?.progress?.[i] || 0;
          const done    = prog >= q.target;
          const claimed = user.aiQuests?.claimed?.includes(i);
          const bar     = buildBar(prog, q.target);
          return {
            name:  `${claimed?'✅':done?'🎁':'🔮'} AI Quest ${i+1}: ${q.name}`,
            value: `*"${q.hint}"*\n${q.desc}\n${bar} **${prog}/${q.target}**\n💰 +${formatNumber(q.reward.money)}🪙 · ⭐+${q.reward.xp}XP${done && !claimed ? `\n> \`!quest aiclaim ${i+1}\`` : ''}`,
            inline: false
          };
        });

        return loading.edit({ embeds: [new EmbedBuilder()
          .setColor(0x9B59B6).setTitle('🔮 AI Quest — Hôm nay')
          .setDescription('Gemini đã tạo riêng cho bạn 3 nhiệm vụ đặc biệt! Tiến độ tự cập nhật theo hành động.')
          .addFields(fields)
          .setFooter({ text: `${config.footer} • !quest aiclaim <1/2/3> để nhận thưởng` }).setTimestamp()] });
      } catch (err) {
        return loading.edit({ embeds: [new EmbedBuilder().setColor(0xFF4757)
          .setDescription(`❌ AI không tạo được quest: ${err.message}`).setFooter({ text: config.footer || 'Stela Network' })] });
      }
    }

    // !quest aiclaim <số>
    if (args[0] === 'aiclaim') {
      const idx = parseInt(args[1]) - 1;
      if (isNaN(idx) || idx < 0 || idx > 2) return interactionOrMessage.reply('`!quest aiclaim <1/2/3>`');
      if (!user.aiQuests || user.aiQuests.date !== getTodayKey()) return interactionOrMessage.reply({ embeds: [new EmbedBuilder()
        .setColor(0xFF8C00).setDescription('❌ Chưa có AI Quest hôm nay! Dùng `!quest ai` trước.').setFooter({ text: config.footer || 'Stela Network' })] });

      const q       = user.aiQuests.quests[idx];
      const prog    = user.aiQuests.progress?.[idx] || 0;
      const claimed = user.aiQuests.claimed?.includes(idx);
      if (claimed) return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(0xFF8C00).setDescription('✅ Đã nhận thưởng quest này rồi!').setFooter({ text: config.footer || 'Stela Network' })] });
      if (prog < q.target) return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(0xFF8C00).setDescription(`❌ Chưa xong! **${prog}/${q.target}**`).setFooter({ text: config.footer || 'Stela Network' })] });

      user.money       = (user.money||0) + q.reward.money;
      user.xp          = (user.xp||0) + q.reward.xp;
      user.totalXP     = (user.totalXP||0) + q.reward.xp;
      user.totalEarned = (user.totalEarned||0) + q.reward.money;
      if (!user.aiQuests.claimed) user.aiQuests.claimed = [];
      user.aiQuests.claimed.push(idx);
      db.saveUser(userId, user);

      return interactionOrMessage.reply({ embeds: [new EmbedBuilder()
        .setColor(0x00D26A).setTitle('🎉 Nhận thưởng AI Quest!')
        .setDescription(`**${q.name}**\n*"${q.hint}"*\n\n+**${formatNumber(q.reward.money)} 🪙** · +**${q.reward.xp} XP**`)
        .setFooter({ text: config.footer || 'Stela Network' }).setTimestamp()] });
    }

    // !quest claim <số>
    if (args[0] === 'claim') {
      const idx = parseInt(args[1]) - 1;
      if (isNaN(idx) || idx < 0 || idx > 2) return interactionOrMessage.reply('`!quest claim <1/2/3>`');
      const q = quests[idx];
      if (user.quests.claimed.includes(q.id)) return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(0xFF8C00).setDescription('✅ Đã nhận thưởng nhiệm vụ này rồi!').setFooter({ text: config.footer || 'Stela Network' })] });
      const prog = user.quests.progress[q.id] || 0;
      if (prog < q.target) return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(0xFF8C00).setDescription(`❌ Chưa hoàn thành! **${prog}/${q.target}**`).setFooter({ text: config.footer || 'Stela Network' })] });

      user.money       = (user.money||0) + q.reward.money;
      user.xp          = (user.xp||0) + q.reward.xp;
      user.totalXP     = (user.totalXP||0) + q.reward.xp;
      user.totalEarned = (user.totalEarned||0) + q.reward.money;
      user.quests.claimed.push(q.id);
      db.saveUser(userId, user);

      return interactionOrMessage.reply({ embeds: [new EmbedBuilder()
        .setColor(0x00D26A).setTitle('🎉 Nhận thưởng nhiệm vụ!')
        .setDescription(`**${q.name}** — ${q.desc}\n\n+**${formatNumber(q.reward.money)} 🪙** · +**${q.reward.xp} XP**`)
        .setFooter({ text: config.footer || 'Stela Network' }).setTimestamp()] });
    }

    // Hiển thị quests
    const fields = quests.map((q, i) => {
      const prog    = user.quests.progress[q.id] || 0;
      const done    = prog >= q.target;
      const claimed = user.quests.claimed.includes(q.id);
      const bar     = buildBar(prog, q.target);
      const status  = claimed ? '✅ Đã nhận' : done ? '🎁 Nhận ngay!' : `${prog}/${q.target}`;
      return {
        name: `${claimed?'✅':done?'🎁':'🔹'} Nhiệm vụ ${i+1}: ${q.name}`,
        value: `${q.desc}\n${bar} ${status}\n💰 +${formatNumber(q.reward.money)}🪙 · ⭐+${q.reward.xp}XP${done && !claimed ? `\n> \`!quest claim ${i+1}\`` : ''}`,
        inline: false
      };
    });

    const allDone = quests.every(q => user.quests.claimed.includes(q.id));
    const now = new Date(); const reset = new Date(now); reset.setHours(24,0,0,0);
    const diff = reset - now; const hrs = Math.floor(diff/3600000); const mins = Math.floor((diff%3600000)/60000);

    interactionOrMessage.reply({ embeds: [new EmbedBuilder()
      .setColor(allDone ? 0xFFD700 : 0x7B2FBE)
      .setTitle(allDone ? '🏆 Hoàn thành tất cả nhiệm vụ hôm nay!' : '📋 Nhiệm vụ hàng ngày')
      .addFields(fields)
      .setDescription(allDone ? '*Reset lúc 0:00 ngày mai!*' : null)
      .setFooter({ text: `${config.footer} • Reset sau ${hrs}h${mins}m` })
      .setTimestamp()] });
  }
};

function buildBar(cur, max) {
  const pct   = Math.min(cur / max, 1);
  const filled = Math.round(pct * 10);
  return '█'.repeat(filled) + '░'.repeat(10 - filled);
}

// ═══════════════════════════════════════════════════════════════════════════════
//  AI Quest Generator — !quest ai
//  Dùng Gemini để tạo nhiệm vụ sáng tạo thay thế
// ═══════════════════════════════════════════════════════════════════════════════
const https = require('https');

// Cache AI quests theo userId+ngày (không gọi lại Gemini 2 lần/ngày)
const aiQuestCache = new Map();

function geminiAIQuest(userInfo) {
  return new Promise((resolve, reject) => {
    const key = require('../../config.json').geminiKey;
    if (!key) return reject(new Error('Chưa có geminiKey'));

    const prompt = `Tạo 3 nhiệm vụ hàng ngày thú vị cho game Discord RPG tiếng Việt.
Người chơi: Level ${userInfo.level}, Tiền: ${userInfo.money}🪙, Username: ${userInfo.name}

Trả về JSON hợp lệ (không có markdown, không backtick):
[
  {"name":"tên nhiệm vụ (emoji + tên ngắn)","desc":"mô tả hành động","hint":"gợi ý vui hoặc lore","reward_money":500,"reward_xp":100,"type":"chat|fish|hunt|work|daily|bj_win|earn","target":5},
  {"name":"...","desc":"...","hint":"...","reward_money":800,"reward_xp":150,"type":"...","target":3},
  {"name":"...","desc":"...","hint":"...","reward_money":1200,"reward_xp":200,"type":"...","target":10}
]

Yêu cầu:
- Tên nhiệm vụ sáng tạo, thú vị, phù hợp fantasy/RPG
- Hint là câu nói nhân vật phong cách RPG, hài hước
- reward_money từ 300-2000, reward_xp từ 60-400
- type chỉ dùng: chat, fish, hunt, work, daily, bj_win, earn
- target phải hợp lý (chat: 5-50, fish/hunt: 1-20, work: 1-5, daily: 1, bj_win: 1-5, earn: 500-5000)`;

    const body = JSON.stringify({
      contents: [{ parts: [{ text: prompt }] }],
      generationConfig: { maxOutputTokens: 600, temperature: 0.9 }
    });

    const req = https.request({
      hostname: 'generativelanguage.googleapis.com',
      path:     `/v1beta/models/gemini-1.5-flash:generateContent?key=${key}`,
      method:   'POST',
      headers:  { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) }
    }, (res) => {
      let data = '';
      res.on('data', c => data += c);
      res.on('end', () => {
        try {
          const json  = JSON.parse(data);
          const text  = json.candidates?.[0]?.content?.parts?.[0]?.text || '';
          const clean = text.replace(/```json|```/g, '').trim();
          const quests = JSON.parse(clean);
          if (!Array.isArray(quests) || quests.length < 3) throw new Error('Invalid response');
          resolve(quests.slice(0, 3).map((q, i) => ({
            id:     `ai_${i}_${Date.now()}`,
            name:   q.name   || `🎯 Nhiệm vụ AI ${i+1}`,
            desc:   q.desc   || 'Hoàn thành nhiệm vụ',
            hint:   q.hint   || '',
            type:   ['chat','fish','hunt','work','daily','bj_win','earn'].includes(q.type) ? q.type : 'chat',
            target: Math.max(1, parseInt(q.target) || 5),
            reward: { money: Math.min(5000, Math.max(100, parseInt(q.reward_money)||500)), xp: Math.min(500, Math.max(30, parseInt(q.reward_xp)||100)) },
            isAI:   true,
          })));
        } catch (e) { reject(new Error('AI trả về dữ liệu không hợp lệ: ' + e.message)); }
      });
    });
    req.on('error', reject);
    req.setTimeout(20000, () => { req.destroy(); reject(new Error('AI timeout')); });
    req.write(body);
    req.end();
  });
}

module.exports.getAIQuests = async function(userId, user) {
  const today = getTodayKey();
  const cached = aiQuestCache.get(userId);
  if (cached && cached.date === today) return cached.quests;

  const quests = await geminiAIQuest({
    level: user.level || 1,
    money: user.money || 0,
    name:  user.username || 'Unknown'
  });

  aiQuestCache.set(userId, { date: today, quests });
  return quests;
};
