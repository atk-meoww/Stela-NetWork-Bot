'use strict';
const _0xb701a0={0x2dac:0xee16,_:!0};void(0x0b);
const { EmbedBuilder, SlashCommandBuilder } = require('discord.js');
const config = require('../../config.json');
const db     = require('../../database');
const { formatNumber } = require('../../handlers/utils');

const PET_TYPES = {
  '🐱 Mèo':    { base: 500,  bonus: { fish: 0.10 }, desc: '+10% tiền câu cá' },
  '🐶 Chó':    { base: 500,  bonus: { hunt: 0.10 }, desc: '+10% tiền săn quái' },
  '🐲 Rồng':   { base: 5000, bonus: { all:  0.20 }, desc: '+20% tất cả hoạt động' },
  '🦊 Cáo':    { base: 1000, bonus: { work: 0.15 }, desc: '+15% tiền làm việc' },
  '🐼 Gấu trúc':{ base: 800, bonus: { xp:   0.15 }, desc: '+15% XP mọi lúc' },
  '🦄 Kỳ lân': { base: 3000, bonus: { daily:0.20 }, desc: '+20% daily reward' },
};

const FEED_COST = 50;
const FEED_XP   = 20;
const MAX_HUNGER = 100;
const MAX_PET_LEVEL = 30;

function getPetXPForLevel(lvl) { return lvl * lvl * 50; }

function getPet(userId) {
  const user = db.getUser(userId);
  return user.pet || null;
}

function getFoodStatus(hunger) {
  if (hunger >= 80) return '😊 No';
  if (hunger >= 50) return '😐 Hơi đói';
  if (hunger >= 20) return '😟 Đói';
  return '😵 Rất đói!';
}

function getMoodStatus(mood) {
  if (mood >= 80) return '😄 Vui vẻ';
  if (mood >= 50) return '😊 Bình thường';
  if (mood >= 20) return '😔 Buồn';
  return '😭 Tệ lắm!';
}

// Decay hunger/mood theo thời gian
function applyDecay(pet) {
  if (!pet.lastFed) pet.lastFed = Date.now();
  const hrs = (Date.now() - pet.lastFed) / 3_600_000;
  pet.hunger = Math.max(0, (pet.hunger||MAX_HUNGER) - Math.floor(hrs * 5));
  pet.mood   = Math.max(0, (pet.mood  ||100)        - Math.floor(hrs * 3));
  return pet;
}

module.exports = {
  name: 'pet',
  enabled: true, description: 'Hệ thống thú cưng', category: 'Games',
  aliases: ['thucung', 'companion'], cooldown: 3,

  async execute(interactionOrMessage, args, client) {
    const userId = interactionOrMessage.author.id;
    const sub    = args[0]?.toLowerCase();

    // ── !pet adopt ──────────────────────────────────────────────────────────
    if (sub === 'adopt' || sub === 'nhan') {
      if (getPet(userId)) return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(0xFF8C00)
        .setDescription('❌ Bạn đã có thú cưng rồi! Dùng `!pet` để xem.').setFooter({ text: config.footer || 'Stela Network' })] });

      const types = Object.keys(PET_TYPES);
      const typeStr = types.map((t, i) => `**${i+1}.** ${t} — ${PET_TYPES[t].desc} *(${formatNumber(PET_TYPES[t].base)} 🪙)*`).join('\n');

      const embed = new EmbedBuilder().setColor(0x7B2FBE)
        .setTitle('🐾 Chọn thú cưng')
        .setDescription(typeStr + '\n\n> `!pet adopt <số>` để nhận nuôi')
        .setFooter({ text: config.footer || 'Stela Network' });

      if (!args[1]) return interactionOrMessage.reply({ embeds: [embed] });

      const idx  = parseInt(args[1]) - 1;
      const type = types[idx];
      if (!type) return interactionOrMessage.reply('❌ Chọn số từ 1-' + types.length);

      const user = db.getUser(userId);
      const cost = PET_TYPES[type].base;
      if ((user.money||0) < cost) return interactionOrMessage.reply(`❌ Cần **${formatNumber(cost)} 🪙** để nhận nuôi!`);

      const petName = args.slice(2).join(' ') || type.split(' ')[1];
      user.money   -= cost;
      user.pet      = { type, name: petName, level: 1, xp: 0, hunger: 100, mood: 100, lastFed: Date.now(), adoptedAt: Date.now() };
      db.saveUser(userId, user);

      return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(0x00D26A)
        .setTitle(`🎉 Đã nhận nuôi ${type}!`)
        .setDescription(`Tên: **${petName}** · Chi phí: **${formatNumber(cost)} 🪙**\n\nNhớ cho ăn mỗi ngày nhé! \`!pet feed\`\n${PET_TYPES[type].desc}`)
        .setFooter({ text: config.footer || 'Stela Network' }).setTimestamp()] });
    }

    // ── Cần có pet ──────────────────────────────────────────────────────────
    const user = db.getUser(userId);
    if (!user.pet) return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(0xFF8C00)
      .setDescription('🐾 Bạn chưa có thú cưng!\nDùng `!pet adopt` để nhận nuôi.').setFooter({ text: config.footer || 'Stela Network' })] });

    let pet = applyDecay(user.pet);

    // ── !pet feed ────────────────────────────────────────────────────────────
    if (sub === 'feed' || sub === 'cho_an') {
      if ((user.money||0) < FEED_COST) return interactionOrMessage.reply(`❌ Cần **${FEED_COST} 🪙** để mua đồ ăn!`);
      if (pet.hunger >= MAX_HUNGER) return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(0xFF8C00)
        .setDescription(`😊 **${pet.name}** vẫn no! Chờ thêm chút.`).setFooter({ text: config.footer || 'Stela Network' })] });

      user.money   -= FEED_COST;
      pet.hunger    = Math.min(MAX_HUNGER, pet.hunger + 40);
      pet.mood      = Math.min(100, pet.mood + 10);
      pet.xp        = (pet.xp||0) + FEED_XP;
      pet.lastFed   = Date.now();

      // Level up
      while (pet.xp >= getPetXPForLevel(pet.level) && pet.level < MAX_PET_LEVEL) {
        pet.xp     -= getPetXPForLevel(pet.level);
        pet.level++;
      }

      user.pet = pet;
      db.saveUser(userId, user);

      return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(0x00D26A)
        .setTitle(`🍖 Đã cho ${pet.name} ăn!`)
        .addFields(
          { name: '🍽️ Độ no',   value: `**${pet.hunger}/100**`, inline: true },
          { name: '😄 Tâm trạng', value: `**${pet.mood}/100**`,  inline: true },
          { name: '⭐ Pet XP',   value: `+${FEED_XP} XP`,         inline: true }
        )
        .setFooter({ text: `${config.footer} • -${FEED_COST}🪙` })] });
    }

    // ── !pet play ────────────────────────────────────────────────────────────
    if (sub === 'play' || sub === 'choi') {
      const lastPlay = pet.lastPlay || 0;
      if (Date.now() - lastPlay < 2 * 3600_000) return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(0xFF8C00)
        .setDescription(`😴 **${pet.name}** đang mệt! Chờ **${Math.ceil((2*3600_000-(Date.now()-lastPlay))/3600_000)}h** nữa.`).setFooter({ text: config.footer || 'Stela Network' })] });

      pet.mood     = Math.min(100, pet.mood + 25);
      pet.xp       = (pet.xp||0) + 30;
      pet.lastPlay = Date.now();
      while (pet.xp >= getPetXPForLevel(pet.level) && pet.level < MAX_PET_LEVEL) {
        pet.xp -= getPetXPForLevel(pet.level); pet.level++;
      }
      user.pet = pet;
      db.saveUser(userId, user);

      const plays = ['chạy vòng vòng 🏃', 'bắt bóng ⚽', 'nhảy lên đùi bạn 🥰', 'đuổi theo đuôi mình 🌀'];
      return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(0xFFD700)
        .setTitle(`🎾 Chơi với ${pet.name}!`)
        .setDescription(`**${pet.name}** ${plays[Math.floor(Math.random()*plays.length)]}!\n\n😄 Tâm trạng: **${pet.mood}/100** · ⭐+30 XP`)
        .setFooter({ text: config.footer || 'Stela Network' })] });
    }

    // ── !pet rename ──────────────────────────────────────────────────────────
    if (sub === 'rename') {
      const newName = args.slice(1).join(' ').trim();
      if (!newName || newName.length > 20) return interactionOrMessage.reply('❌ Tên 1-20 ký tự!');
      const old = pet.name;
      pet.name = newName; user.pet = pet;
      db.saveUser(userId, user);
      return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(0x00D26A)
        .setDescription(`✅ Đổi tên từ **${old}** → **${newName}**!`).setFooter({ text: config.footer || 'Stela Network' })] });
    }

    // ── !pet release ─────────────────────────────────────────────────────────
    if (sub === 'release') {
      if (args[1] !== 'confirm') return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(0xFF8C00)
        .setDescription(`⚠️ Bạn sắp thả **${pet.name}** đi!\nGõ \`!pet release confirm\` để xác nhận.`).setFooter({ text: config.footer || 'Stela Network' })] });
      delete user.pet;
      db.saveUser(userId, user);
      return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(0xFF4757)
        .setDescription(`👋 Đã thả **${pet.name}** đi. Tạm biệt!`).setFooter({ text: config.footer || 'Stela Network' })] });
    }

    // ── !pet (xem info) ──────────────────────────────────────────────────────
    user.pet = pet; db.saveUser(userId, user);
    const info = PET_TYPES[pet.type] || {};
    const xpNeeded = getPetXPForLevel(pet.level);
    const xpBar = buildBar(pet.xp, xpNeeded);

    interactionOrMessage.reply({ embeds: [new EmbedBuilder()
      .setColor(0x7B2FBE)
      .setTitle(`🐾 ${pet.name} — ${pet.type}`)
      .setDescription(`*${info.desc || ''}*`)
      .addFields(
        { name: '⭐ Level',      value: `**${pet.level}** / ${MAX_PET_LEVEL}\n${xpBar} ${pet.xp}/${xpNeeded}XP`, inline: false },
        { name: '🍽️ Độ no',     value: `${buildBar(pet.hunger,100)} ${getFoodStatus(pet.hunger)}`,              inline: false },
        { name: '😄 Tâm trạng', value: `${buildBar(pet.mood,100)} ${getMoodStatus(pet.mood)}`,                  inline: false },
        { name: '📅 Nhận nuôi', value: `<t:${Math.floor((pet.adoptedAt||Date.now())/1000)}:D>`,                 inline: true  }
      )
      .setFooter({ text: `${config.footer} • !pet feed | !pet play | !pet rename` })
      .setTimestamp()] });
  }
};

function buildBar(cur, max) {
  const f = Math.round(Math.min(cur/max,1)*10);
  return '█'.repeat(f)+'░'.repeat(10-f);
}
