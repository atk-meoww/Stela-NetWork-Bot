'use strict';
const { EmbedBuilder, SlashCommandBuilder } = require('discord.js');
const config = require('../../config.json');
const db = require('../../database');
const { getMember, formatNumber } = require('../../handlers/utils');

const COOLDOWN_MS  = 30 * 60 * 1000;
const SUCCESS_RATE = 0.45;
const MIN_STEAL    = 50;
const FINE_RATE    = 0.3;

module.exports = {
  name: 'rob',
  enabled: true,
  description: 'Cướp tiền người khác (có rủi ro 45/55)',
  category: 'Economy',
  aliases: ['cuop', 'steal', 'heist'],
  usage: '!rob <@user>',
  cooldown: 5,
  prefixSupport: true,
  data: new SlashCommandBuilder()
    .setName('rob').setDescription('Cướp tiền người khác (45% thành công, 55% bị phạt)')
    .addUserOption(o => o.setName('target').setDescription('Nạn nhân').setRequired(true))
    .setDMPermission(false),

  async execute(interactionOrMessage, args, client) {
    const isSlash  = !!interactionOrMessage.isChatInputCommand?.();
    const authorId = isSlash ? interactionOrMessage.user.id : interactionOrMessage.author.id;
    const guild    = interactionOrMessage.guild;

    const reply = (payload) => {
      if (typeof payload === 'string') payload = { content: payload };
      return isSlash ? interactionOrMessage.editReply(payload) : interactionOrMessage.reply(payload);
    };

    if (isSlash) await interactionOrMessage.deferReply();

    let target;
    if (isSlash) {
      target = interactionOrMessage.options.getMember('target');
    } else {
      if (!args[0]) return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(0xFF8C00).setDescription('`!rob <@user>`').setFooter({ text: config.footer || 'Stela Network' })] });
      target = await getMember(guild, args[0]);
    }
    if (!target) return reply({ embeds: [new EmbedBuilder().setColor(0xFF4757).setDescription('❌ Không tìm thấy thành viên!')] });
    if (target.id === authorId) return reply({ embeds: [new EmbedBuilder().setColor(0xFF4757).setDescription('❌ Không thể cướp chính mình!')] });
    if (target.user.bot) return reply({ embeds: [new EmbedBuilder().setColor(0xFF4757).setDescription('❌ Bot không có tiền!')] });

    const robber    = db.getUser(authorId);
    const now       = Date.now();
    const remaining = COOLDOWN_MS - (now - (robber.lastRob || 0));

    if (robber.lastRob && remaining > 0) {
      const m = Math.floor(remaining / 60000);
      const s = Math.floor((remaining % 60000) / 1000);
      return reply({ embeds: [new EmbedBuilder().setColor(0xFF8C00).setTitle('⏳ Hãy ẩn náu thêm!')
        .setDescription(`Cảnh sát đang truy đuổi, chờ thêm **${m}m ${s}s**!`).setFooter({ text: config.footer || 'Stela Network' })] });
    }

    const victim      = db.getUser(target.id);
    const victimMoney = victim.money || 0;

    if (victimMoney < MIN_STEAL) {
      return reply({ embeds: [new EmbedBuilder().setColor(0xFF4757).setTitle('😅 Mục tiêu quá nghèo')
        .setDescription(`**${target.user.username}** chỉ có **${formatNumber(victimMoney)} 🪙** — không đáng cướp!`)
        .setFooter({ text: config.footer || 'Stela Network' })] });
    }

    robber.lastRob = now;
    const success  = Math.random() < SUCCESS_RATE;

    if (success) {
      const maxSteal = Math.floor(victimMoney * 0.3);
      const stolen   = Math.floor(Math.random() * (maxSteal - MIN_STEAL + 1)) + MIN_STEAL;

      robber.money       = (robber.money || 0) + stolen;
      robber.totalEarned = (robber.totalEarned || 0) + stolen;
      victim.money       = victimMoney - stolen;
      victim.totalSpent  = (victim.totalSpent || 0) + stolen;

      db.saveUser(authorId, robber);
      db.saveUser(target.id, victim);

      return reply({ embeds: [new EmbedBuilder()
        .setColor(0x00D26A).setTitle('🦹 Cướp thành công!')
        .setDescription(`Bạn đã cướp được **${target.user.username}**!`)
        .addFields(
          { name: '💰 Số tiền cướp được', value: `**+${formatNumber(stolen)} 🪙**`,    inline: true },
          { name: '💳 Số dư của bạn',     value: `**${formatNumber(robber.money)} 🪙**`,inline: true },
          { name: '😭 Số dư nạn nhân',    value: `**${formatNumber(victim.money)} 🪙**`,inline: true }
        )
        .setFooter({ text: `${config.footer || 'Stela Network'} • 45% tỷ lệ thành công` }).setTimestamp()] });
    } else {
      const fine = Math.floor((robber.money || 0) * FINE_RATE);
      robber.money      = Math.max(0, (robber.money || 0) - fine);
      robber.totalSpent = (robber.totalSpent || 0) + fine;
      db.saveUser(authorId, robber);

      const scenarios = [
        `Bạn vấp phải một hòn đá và bị **${target.user.username}** bắt gặp!`,
        `Chó nhà **${target.user.username}** sủa inh tai, cảnh sát ập đến!`,
        `Bạn chạy nhầm đường và rơi vào tay cảnh sát!`,
        `**${target.user.username}** thì ra là võ sĩ, bạn tẩu thoát trong thảm bại!`,
        `Cảnh sát đang mai phục chờ bạn từ trước!`
      ];

      return reply({ embeds: [new EmbedBuilder()
        .setColor(0xFF4757).setTitle('🚔 Cướp thất bại!')
        .setDescription(scenarios[Math.floor(Math.random() * scenarios.length)])
        .addFields(
          { name: '💸 Tiền phạt',  value: `**-${formatNumber(fine)} 🪙**`,        inline: true },
          { name: '💳 Số dư còn',  value: `**${formatNumber(robber.money)} 🪙**`, inline: true }
        )
        .setFooter({ text: `${config.footer || 'Stela Network'} • 55% tỷ lệ thất bại` }).setTimestamp()] });
    }
  }
};
