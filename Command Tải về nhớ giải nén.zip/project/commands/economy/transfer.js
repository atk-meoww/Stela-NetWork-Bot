'use strict';
const { EmbedBuilder, SlashCommandBuilder } = require('discord.js');
const config = require('../../config.json');
const db = require('../../database');
const { getMember, formatNumber } = require('../../handlers/utils');

const TAX_RATE = 0.05;

module.exports = {
  name: 'transfer',
  enabled: true,
  description: 'Chuyển tiền cho người khác (phí 5%)',
  category: 'Economy',
  aliases: ['pay', 'give', 'chuyentien'],
  usage: '!transfer <@user> <số tiền>',
  cooldown: 10,
  prefixSupport: true,
  data: new SlashCommandBuilder()
    .setName('transfer').setDescription('Chuyển tiền cho người khác (phí 5%)')
    .addUserOption(o => o.setName('user').setDescription('Người nhận').setRequired(true))
    .addIntegerOption(o => o.setName('amount').setDescription('Số tiền cần chuyển').setRequired(true).setMinValue(10))
    .setDMPermission(false),

  async execute(interactionOrMessage, args, client) {
    const isSlash  = !!interactionOrMessage.isChatInputCommand?.();
    const authorId = isSlash ? interactionOrMessage.user.id : interactionOrMessage.author.id;
    const guild    = interactionOrMessage.guild;

    if (isSlash) await interactionOrMessage.deferReply();

    let target, amount;
    if (isSlash) {
      target = interactionOrMessage.options.getMember('user');
      amount = interactionOrMessage.options.getInteger('amount');
    } else {
      if (args.length < 2) return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(0xFF8C00).setTitle('📌 Cách dùng')
        .setDescription('`!transfer <@user> <số tiền>`\n*Phí chuyển: 5%*').setFooter({ text: config.footer || 'Stela Network' })] });
      target = await getMember(guild, args[0]);
      amount = parseInt(args[1]);
    }

    const reply = (payload) => {
      if (typeof payload === 'string') payload = { content: payload };
      return isSlash ? interactionOrMessage.editReply(payload) : interactionOrMessage.reply(payload);
    };

    if (!target) return reply({ embeds: [new EmbedBuilder().setColor(0xFF4757).setDescription('❌ Không tìm thấy thành viên!')] });
    if (target.id === authorId) return reply({ embeds: [new EmbedBuilder().setColor(0xFF4757).setDescription('❌ Không chuyển cho chính mình!')] });
    if (target.user.bot) return reply({ embeds: [new EmbedBuilder().setColor(0xFF4757).setDescription('❌ Không chuyển cho bot!')] });
    if (isNaN(amount) || amount < 10) return reply({ embeds: [new EmbedBuilder().setColor(0xFF4757).setDescription('❌ Số tiền tối thiểu **10 🪙**!')] });

    const sender = db.getUser(authorId);
    if ((sender.money || 0) < amount) return reply({ embeds: [new EmbedBuilder().setColor(0xFF4757).setTitle('❌ Không đủ tiền')
      .setDescription(`Bạn có **${formatNumber(sender.money||0)} 🪙**, cần **${formatNumber(amount)} 🪙**`).setFooter({ text: config.footer || 'Stela Network' })] });

    const tax     = Math.ceil(amount * TAX_RATE);
    const receive = amount - tax;

    sender.money      = (sender.money || 0) - amount;
    sender.totalSpent = (sender.totalSpent || 0) + amount;
    db.saveUser(authorId, sender);

    const recv       = db.getUser(target.id);
    recv.money       = (recv.money || 0) + receive;
    recv.totalEarned = (recv.totalEarned || 0) + receive;
    db.saveUser(target.id, recv);

    return reply({ embeds: [new EmbedBuilder().setColor(0x00D26A).setTitle('✅ Chuyển tiền thành công!')
      .addFields(
        { name: '💸 Người gửi',    value: `<@${authorId}>\n-**${formatNumber(amount)} 🪙**`,     inline: true },
        { name: '📬 Người nhận',   value: `${target.user.username}\n+**${formatNumber(receive)} 🪙**`, inline: true },
        { name: '🏦 Phí (5%)',     value: `**${formatNumber(tax)} 🪙**`,                          inline: true },
        { name: '💳 Số dư còn',    value: `**${formatNumber(sender.money)} 🪙**`,                 inline: false }
      )
      .setFooter({ text: config.footer || 'Stela Network' }).setTimestamp()] });
  }
};
