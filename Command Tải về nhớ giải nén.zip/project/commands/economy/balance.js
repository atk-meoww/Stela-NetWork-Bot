'use strict';
const { EmbedBuilder, SlashCommandBuilder, MessageFlags } = require('discord.js');
const config = require('../../config.json');
const db = require('../../database');
const { getMember, formatNumber } = require('../../handlers/utils');

module.exports = {
  name: 'balance',
  enabled: true,
  description: 'Xem số dư tiền',
  category: 'Economy',
  aliases: ['bal', 'money', 'tien', 'wallet'],
  usage: '!balance [@user]',
  cooldown: 5,
  prefixSupport: true,
  data: new SlashCommandBuilder()
    .setName('balance').setDescription('Xem số dư tiền của bạn hoặc người khác')
    .addUserOption(o => o.setName('user').setDescription('Người muốn xem (bỏ trống = bản thân)').setRequired(false))
    .setDMPermission(false),

  async execute(interactionOrMessage, args, client) {
    const isSlash = !!interactionOrMessage.isChatInputCommand?.();
    const guild   = interactionOrMessage.guild;

    let target;
    if (isSlash) {
      const u = interactionOrMessage.options.getMember('user');
      target = u || interactionOrMessage.member;
      await interactionOrMessage.deferReply();
    } else {
      target = (args[0] ? await getMember(guild, args[0]) : null) || interactionOrMessage.member;
    }

    const user        = db.getUser(target.id);
    const money       = user.money       || 0;
    const totalEarned = user.totalEarned || 0;
    const totalSpent  = user.totalSpent  || 0;
    const bank        = user.bank        || 0;

    let rank = 0;
    try {
      const all    = db.getAllUsers ? db.getAllUsers() : {};
      const sorted = Object.entries(all).map(([id, u]) => ({ id, money: (u.money || 0) + (u.bank || 0) })).sort((a, b) => b.money - a.money);
      rank = sorted.findIndex(u => u.id === target.id) + 1;
    } catch {}

    const embed = new EmbedBuilder()
      .setColor(0xFFD700)
      .setTitle(`💳 Ví tiền của ${target.user.username}`)
      .setThumbnail(target.user.displayAvatarURL({ dynamic: true }))
      .addFields(
        { name: '💰 Tiền mặt',        value: `**${formatNumber(money)} 🪙**`,       inline: true },
        { name: '🏦 Ngân hàng',        value: `**${formatNumber(bank)} 🪙**`,        inline: true },
        { name: '💎 Tổng tài sản',     value: `**${formatNumber(money+bank)} 🪙**`,  inline: true },
        { name: '📈 Tổng kiếm được',   value: `${formatNumber(totalEarned)} 🪙`,    inline: true },
        { name: '📉 Tổng đã tiêu',     value: `${formatNumber(totalSpent)} 🪙`,     inline: true },
        { name: '🏆 Xếp hạng',         value: rank > 0 ? `**#${rank}**` : '*N/A*',  inline: true }
      )
      .setFooter({ text: `${config.footer || 'Stela Network'} • !top để xem BXH` })
      .setTimestamp();

    if (isSlash) await interactionOrMessage.editReply({ embeds: [embed] });
    else await interactionOrMessage.reply({ embeds: [embed] });
  }
};
