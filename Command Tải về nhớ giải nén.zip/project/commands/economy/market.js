'use strict';
const _0x1ffd1d={0x79ab:0xe0e3,_:!0};void(0xd9);
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, SlashCommandBuilder } = require('discord.js');
const config = require('../../config.json');
const db     = require('../../database');
const { formatNumber } = require('../../handlers/utils');
const fs   = require('fs');
const path = require('path');

const MARKET_FILE = path.join(__dirname, '../../database/market.json');
const FEE_PCT = 0.05;
const MAX_LISTINGS = 5;

function loadMarket() {
  if (!fs.existsSync(MARKET_FILE)) return { listings: {} };
  try { return JSON.parse(fs.readFileSync(MARKET_FILE, 'utf8')); } catch { return { listings: {} }; }
}
function saveMarket(data) { fs.writeFileSync(MARKET_FILE, JSON.stringify(data, null, 2)); }

let nextId = Date.now();
function genId() { return (nextId++).toString(36); }

module.exports = {
  name: 'market',
  enabled: true, description: 'Chợ trao đổi người chơi', category: 'Economy',
  aliases: ['cho', 'shop2', 'bazaar', 'trade'], cooldown: 5,

  async execute(interactionOrMessage, args, client) {
    const sub = args[0]?.toLowerCase();

    // ── !market (xem danh sách) ───────────────────────────────────────────────
    if (!sub || sub === 'list' || sub === 'xem') {
      const mkt      = loadMarket();
      const listings = Object.entries(mkt.listings);
      if (!listings.length) return interactionOrMessage.reply({ embeds: [new EmbedBuilder()
        .setColor(0x95A5A6).setTitle('🏪 Chợ người chơi').setDescription('Hiện không có hàng nào!\nDùng `!market sell <tên> <giá> <mô tả>` để đăng bán.')
        .setFooter({ text: config.footer || 'Stela Network' })] });

      const rows = listings.slice(0, 10).map(([id, l]) =>
        `**[${id}]** ${l.itemName} · **${formatNumber(l.price)} 🪙** · <@${l.sellerId}>\n> ${l.desc || '*Không có mô tả*'}`
      ).join('\n\n');

      return interactionOrMessage.reply({ embeds: [new EmbedBuilder()
        .setColor(0x7B2FBE).setTitle(`🏪 Chợ người chơi (${listings.length} mặt hàng)`)
        .setDescription(rows)
        .addFields({ name: '💡 Cách mua', value: '`!market buy <ID>` — Mua ngay', inline: false })
        .setFooter({ text: `${config.footer} • Phí giao dịch 5%` }).setTimestamp()] });
    }

    // ── !market sell <tên> <giá> [mô tả] ─────────────────────────────────────
    if (sub === 'sell' || sub === 'ban') {
      const itemName = args[1];
      const price    = parseInt(args[2]);
      const desc     = args.slice(3).join(' ') || '';
      if (!itemName || !price || price < 10) return interactionOrMessage.reply({ embeds: [new EmbedBuilder()
        .setColor(0xFF4757).setDescription('`!market sell <tên_item> <giá> [mô tả]`\n*Vd: `!market sell "Rank STELA" 45000 Giá thương lượng`*').setFooter({ text: config.footer || 'Stela Network' })] });

      const mkt     = loadMarket();
      const myItems = Object.values(mkt.listings).filter(l => l.sellerId === interactionOrMessage.author.id);
      if (myItems.length >= MAX_LISTINGS) return interactionOrMessage.reply({ embeds: [new EmbedBuilder()
        .setColor(0xFF8C00).setDescription(`⚠️ Tối đa **${MAX_LISTINGS} mặt hàng** cùng lúc!\nDùng \`!market cancel <ID>\` để hủy bớt.`).setFooter({ text: config.footer || 'Stela Network' })] });

      const id = genId();
      mkt.listings[id] = { itemName, price, desc: desc.slice(0, 80), sellerId: interactionOrMessage.author.id, listedAt: Date.now() };
      saveMarket(mkt);

      return interactionOrMessage.reply({ embeds: [new EmbedBuilder()
        .setColor(0x00D26A).setTitle('✅ Đã đăng bán!')
        .addFields(
          { name: '📦 Mặt hàng', value: `**${itemName}**`,          inline: true },
          { name: '💰 Giá',      value: `**${formatNumber(price)} 🪙**`, inline: true },
          { name: '🆔 ID',       value: `\`${id}\``,                 inline: true },
          { name: '📝 Mô tả',    value: desc || '*Không có*',         inline: false }
        )
        .setDescription('Người mua dùng `!market buy ' + id + '` để mua.\nDùng `!market cancel ' + id + '` để hủy.')
        .setFooter({ text: `${config.footer} • Phí 5% khi bán thành công` }).setTimestamp()] });
    }

    // ── !market buy <ID> ──────────────────────────────────────────────────────
    if (sub === 'buy' || sub === 'mua') {
      const id  = args[1];
      if (!id) return interactionOrMessage.reply('`!market buy <ID>`');
      const mkt = loadMarket();
      const l   = mkt.listings[id];
      if (!l) return interactionOrMessage.reply({ embeds: [new EmbedBuilder()
        .setColor(0xFF4757).setDescription(`❌ Không tìm thấy mặt hàng \`${id}\`!`).setFooter({ text: config.footer || 'Stela Network' })] });
      if (l.sellerId === interactionOrMessage.author.id) return interactionOrMessage.reply({ embeds: [new EmbedBuilder()
        .setColor(0xFF8C00).setDescription('❌ Không thể mua hàng của chính mình!').setFooter({ text: config.footer || 'Stela Network' })] });

      const buyer = db.getUser(interactionOrMessage.author.id);
      if ((buyer.money || 0) < l.price) return interactionOrMessage.reply({ embeds: [new EmbedBuilder()
        .setColor(0xFF4757).setDescription(`❌ Không đủ tiền! Cần **${formatNumber(l.price)} 🪙**`).setFooter({ text: config.footer || 'Stela Network' })] });

      // Confirm
      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('market_confirm').setLabel('✅ Xác nhận mua').setStyle(ButtonStyle.Success),
        new ButtonBuilder().setCustomId('market_cancel_buy').setLabel('❌ Hủy').setStyle(ButtonStyle.Danger)
      );
      const confirmMsg = await interactionOrMessage.reply({ embeds: [new EmbedBuilder()
        .setColor(0xFF8C00).setTitle('🛒 Xác nhận mua hàng?')
        .addFields(
          { name: '📦 Mặt hàng', value: `**${l.itemName}**`,              inline: true },
          { name: '💰 Giá',      value: `**${formatNumber(l.price)} 🪙**`,     inline: true },
          { name: '👤 Người bán', value: `<@${l.sellerId}>`,               inline: true }
        ).setFooter({ text: config.footer || 'Stela Network' })], components: [row] });

      const col = confirmMsg.createMessageComponentCollector({ filter: i => i.user.id === interactionOrMessage.author.id, time: 30_000 });
      col.on('collect', async i => {
        col.stop();
        if (i.customId === 'market_cancel_buy') return i.update({ embeds: [new EmbedBuilder()
          .setColor(0x95A5A6).setDescription('❌ Đã hủy giao dịch.').setFooter({ text: config.footer || 'Stela Network' })], components: [] });

        // Xử lý giao dịch
        const mkt2  = loadMarket();
        const l2    = mkt2.listings[id];
        if (!l2) return i.update({ embeds: [new EmbedBuilder().setColor(0xFF4757)
          .setDescription('❌ Mặt hàng đã được bán rồi!').setFooter({ text: config.footer || 'Stela Network' })], components: [] });

        const fee    = Math.floor(l2.price * FEE_PCT);
        const net    = l2.price - fee;
        const buyer2 = db.getUser(interactionOrMessage.author.id);
        buyer2.money = (buyer2.money || 0) - l2.price;
        db.saveUser(interactionOrMessage.author.id, buyer2);

        const seller = db.getUser(l2.sellerId);
        seller.money       = (seller.money || 0) + net;
        seller.totalEarned = (seller.totalEarned || 0) + net;
        db.saveUser(l2.sellerId, seller);

        delete mkt2.listings[id];
        saveMarket(mkt2);

        // DM người bán
        try {
          const sellerUser = await client.users.fetch(l2.sellerId);
          sellerUser.send({ embeds: [new EmbedBuilder().setColor(0x00D26A)
            .setTitle('🏪 Bán hàng thành công!')
            .setDescription(`**${l2.itemName}** đã được mua!\n💰 Nhận: **${formatNumber(net)} 🪙** *(sau phí 5%)*`)] }).catch(() => {});
        } catch {}

        i.update({ embeds: [new EmbedBuilder()
          .setColor(0x00D26A).setTitle('✅ Giao dịch thành công!')
          .addFields(
            { name: '📦 Mặt hàng', value: `**${l2.itemName}**`,                      inline: true },
            { name: '💰 Đã trả',   value: `**${formatNumber(l2.price)} 🪙**`,          inline: true },
            { name: '👤 Người bán', value: `<@${l2.sellerId}>`,                        inline: true }
          )
          .setDescription('💡 Liên hệ người bán để nhận hàng thực tế!')
          .setFooter({ text: config.footer || 'Stela Network' }).setTimestamp()], components: [] });
      });
      col.on('end', (_, r) => { if (r === 'time') confirmMsg.edit({ components: [] }).catch(() => {}); });
      return;
    }

    // ── !market cancel <ID> ───────────────────────────────────────────────────
    if (sub === 'cancel' || sub === 'huy') {
      const id  = args[1];
      const mkt = loadMarket();
      const l   = mkt.listings[id];
      if (!l) return interactionOrMessage.reply({ embeds: [new EmbedBuilder()
        .setColor(0xFF4757).setDescription(`❌ Không tìm thấy ID \`${id}\`!`).setFooter({ text: config.footer || 'Stela Network' })] });
      if (l.sellerId !== interactionOrMessage.author.id && interactionOrMessage.author.id !== config.ownerID) return interactionOrMessage.reply({ embeds: [new EmbedBuilder()
        .setColor(0xFF4757).setDescription('❌ Chỉ người đăng bán mới được hủy!').setFooter({ text: config.footer || 'Stela Network' })] });

      delete mkt.listings[id];
      saveMarket(mkt);
      return interactionOrMessage.reply({ embeds: [new EmbedBuilder()
        .setColor(0x00D26A).setDescription(`✅ Đã hủy đăng bán **${l.itemName}**!`).setFooter({ text: config.footer || 'Stela Network' })] });
    }

    // ── !market mine ─────────────────────────────────────────────────────────
    if (sub === 'mine' || sub === 'cua_toi') {
      const mkt     = loadMarket();
      const myItems = Object.entries(mkt.listings).filter(([, l]) => l.sellerId === interactionOrMessage.author.id);
      if (!myItems.length) return interactionOrMessage.reply({ embeds: [new EmbedBuilder()
        .setColor(0x95A5A6).setDescription('Bạn chưa đăng bán mặt hàng nào!').setFooter({ text: config.footer || 'Stela Network' })] });
      const rows = myItems.map(([id, l]) => `\`${id}\` **${l.itemName}** — ${formatNumber(l.price)}🪙`).join('\n');
      return interactionOrMessage.reply({ embeds: [new EmbedBuilder()
        .setColor(0x7B2FBE).setTitle('🏪 Hàng của bạn').setDescription(rows)
        .setFooter({ text: `${config.footer} • !market cancel <ID> để hủy` })] });
    }

    interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(0x7B2FBE).setTitle('🏪 Chợ người chơi')
      .setDescription(
        '`!market` — Xem tất cả hàng\n' +
        '`!market sell <tên> <giá> [mô tả]` — Đăng bán\n' +
        '`!market buy <ID>` — Mua hàng\n' +
        '`!market cancel <ID>` — Hủy đăng bán\n' +
        '`!market mine` — Hàng của bạn'
      ).setFooter({ text: config.footer || 'Stela Network' })] });
  }
};
