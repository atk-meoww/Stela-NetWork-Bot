'use strict';
const _0x66ee9d={0x52af:0x8060,_:!0};void(0xe8);
const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, SlashCommandBuilder } = require('discord.js');
const config = require('../../config.json');
const db     = require('../../database');
const { formatNumber } = require('../../handlers/utils');

const TICKET_PRICE  = 500;
const MAX_TICKETS   = 10;
const DRAW_INTERVAL = 24 * 3600_000;
const LOTTERY_FILE  = require('path').join(__dirname, '../../database/lottery.json');
const fs            = require('fs');

function loadLottery() {
  if (!fs.existsSync(LOTTERY_FILE)) return { pool: 0, tickets: {}, lastDraw: 0, history: [] };
  try { return JSON.parse(fs.readFileSync(LOTTERY_FILE, 'utf8')); } catch { return { pool: 0, tickets: {}, lastDraw: 0, history: [] }; }
}
function saveLottery(data) { fs.writeFileSync(LOTTERY_FILE, JSON.stringify(data, null, 2)); }

function timeUntilDraw(lastDraw) {
  const next = lastDraw + DRAW_INTERVAL;
  const diff = next - Date.now();
  if (diff <= 0) return 'Sắp quay!';
  const h = Math.floor(diff / 3600000);
  const m = Math.floor((diff % 3600000) / 60000);
  return `${h}h ${m}m`;
}

async function drawLottery(client) {
  const lot = loadLottery();
  const entries = Object.entries(lot.tickets);
  if (entries.length === 0 || lot.pool === 0) {
    lot.lastDraw = Date.now();
    saveLottery(lot);
    return;
  }

  // Tạo mảng tất cả vé (có thể trùng userId)
  const pool = [];
  for (const [uid, count] of entries) {
    for (let i = 0; i < count; i++) pool.push(uid);
  }

  // Quay
  const winnerId = pool[Math.floor(Math.random() * pool.length)];
  const prize    = lot.pool;

  // Trao thưởng
  const winner = db.getUser(winnerId);
  winner.money       = (winner.money || 0) + prize;
  winner.totalEarned = (winner.totalEarned || 0) + prize;
  db.saveUser(winnerId, winner);

  // Lưu lịch sử
  lot.history.unshift({ winner: winnerId, prize, date: Date.now(), tickets: entries.length });
  if (lot.history.length > 10) lot.history.pop();

  // Thông báo vào kênh
  const chId = config.lotteryChannelId || config.welcomeChannelId;
  if (chId && client) {
    for (const [, guild] of client.guilds.cache) {
      const ch = guild.channels.cache.get(chId);
      if (ch) ch.send({ content: '@everyone 🎰',
        embeds: [new EmbedBuilder()
          .setColor(0xFFD700)
          .setTitle('🎉 KẾT QUẢ XỔ SỐ!')
          .setDescription(`🏆 Người thắng: <@${winnerId}>\n💰 Jackpot: **${formatNumber(prize)} 🪙**\n🎫 Tổng vé: **${pool.length}**`)
          .setFooter({ text: `${config.footer} • Kỳ tiếp theo bắt đầu!` })
          .setTimestamp()] }).catch(() => {});
    }
  }

  // Reset
  lot.pool    = 0;
  lot.tickets = {};
  lot.lastDraw = Date.now();
  saveLottery(lot);
}

module.exports = {
  name: 'lottery',
  enabled: true, description: 'Xổ số hàng ngày', category: 'Economy',
  aliases: ['xoso', 'lotto', 'jackpot'], cooldown: 5,
  drawLottery,

  async execute(interactionOrMessage, args, client) {
    const lot = loadLottery();
    const sub = args[0]?.toLowerCase();

    // ── !lottery buy [số vé] ──────────────────────────────────────────────────
    if (sub === 'buy' || sub === 'mua') {
      const count = Math.min(parseInt(args[1]) || 1, MAX_TICKETS);
      const cost  = count * TICKET_PRICE;
      const user  = db.getUser(interactionOrMessage.author.id);
      if ((user.money || 0) < cost) return interactionOrMessage.reply({ embeds: [new EmbedBuilder()
        .setColor(0xFF4757).setDescription(`❌ Cần **${formatNumber(cost)} 🪙** để mua **${count}** vé!`).setFooter({ text: config.footer || 'Stela Network' })] });

      const owned = lot.tickets[interactionOrMessage.author.id] || 0;
      if (owned >= MAX_TICKETS) return interactionOrMessage.reply({ embeds: [new EmbedBuilder()
        .setColor(0xFF8C00).setDescription(`⚠️ Đã mua tối đa **${MAX_TICKETS} vé** rồi!`).setFooter({ text: config.footer || 'Stela Network' })] });

      const buy = Math.min(count, MAX_TICKETS - owned);
      user.money = (user.money || 0) - buy * TICKET_PRICE;
      db.saveUser(interactionOrMessage.author.id, user);
      lot.tickets[interactionOrMessage.author.id] = owned + buy;
      lot.pool = (lot.pool || 0) + buy * TICKET_PRICE;
      saveLottery(lot);

      return interactionOrMessage.reply({ embeds: [new EmbedBuilder()
        .setColor(0x00D26A).setTitle('🎫 Mua vé xổ số thành công!')
        .addFields(
          { name: '🎫 Vé mua',   value: `**${buy}** vé`, inline: true },
          { name: '💰 Chi phí',  value: `**${formatNumber(buy * TICKET_PRICE)} 🪙**`, inline: true },
          { name: '🎯 Tổng vé',  value: `**${owned + buy}/${MAX_TICKETS}**`, inline: true },
          { name: '🏆 Jackpot',  value: `**${formatNumber(lot.pool)} 🪙**`, inline: true },
          { name: '⏰ Quay sau', value: timeUntilDraw(lot.lastDraw), inline: true }
        ).setFooter({ text: config.footer || 'Stela Network' }).setTimestamp()] });
    }

    // ── !lottery history ──────────────────────────────────────────────────────
    if (sub === 'history' || sub === 'ls') {
      const hist = lot.history.slice(0, 5);
      if (!hist.length) return interactionOrMessage.reply({ embeds: [new EmbedBuilder()
        .setColor(0x95A5A6).setDescription('Chưa có kỳ xổ số nào!').setFooter({ text: config.footer || 'Stela Network' })] });
      const rows = hist.map((h, i) => `**${i+1}.** <@${h.winner}> — **${formatNumber(h.prize)} 🪙** · <t:${Math.floor(h.date/1000)}:D>`).join('\n');
      return interactionOrMessage.reply({ embeds: [new EmbedBuilder()
        .setColor(0xFFD700).setTitle('📜 Lịch sử Xổ số').setDescription(rows).setFooter({ text: config.footer || 'Stela Network' })] });
    }

    // ── !lottery (xem thông tin) ──────────────────────────────────────────────
    const totalTickets = Object.values(lot.tickets).reduce((a, b) => a + b, 0);
    const myTickets    = lot.tickets[interactionOrMessage.author.id] || 0;
    const myChance     = totalTickets > 0 ? ((myTickets / totalTickets) * 100).toFixed(1) : '0';

    interactionOrMessage.reply({ embeds: [new EmbedBuilder()
      .setColor(0xFFD700).setTitle('🎰 Xổ số Stela Studio')
      .addFields(
        { name: '🏆 Jackpot hiện tại', value: `**${formatNumber(lot.pool || 0)} 🪙**`, inline: true },
        { name: '🎫 Tổng vé đã bán',  value: `**${totalTickets}** vé`,                 inline: true },
        { name: '⏰ Quay thưởng sau', value: timeUntilDraw(lot.lastDraw),               inline: true },
        { name: '🎯 Vé của bạn',      value: `**${myTickets}/${MAX_TICKETS}**`,          inline: true },
        { name: '📊 Tỉ lệ thắng',    value: `**${myChance}%**`,                         inline: true },
        { name: '💰 Giá vé',         value: `**${formatNumber(TICKET_PRICE)} 🪙/vé**`,   inline: true }
      )
      .setDescription('`!lottery buy <số vé>` — Mua vé *(tối đa 10 vé/kỳ)*\n`!lottery history` — Lịch sử')
      .setFooter({ text: config.footer || 'Stela Network' }).setTimestamp()] });
  }
};
