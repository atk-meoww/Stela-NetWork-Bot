'use strict';
const { EmbedBuilder, SlashCommandBuilder } = require('discord.js');
const config = require('../../config.json');
const db = require('../../database');
const { formatNumber } = require('../../handlers/utils');

const COOLDOWN_MS = 60 * 60 * 1000; // 1 giờ

const JOBS = [
  { job: 'thợ mỏ ⛏️',          min: 80,  max: 250, story: 'Bạn đào được đống quặng sắt và bán cho thương nhân' },
  { job: 'nông dân 🌾',          min: 60,  max: 180, story: 'Bạn thu hoạch mùa vụ và bán tại chợ làng' },
  { job: 'lính đánh thuê ⚔️',   min: 100, max: 350, story: 'Bạn hoàn thành nhiệm vụ tiêu diệt quái vật' },
  { job: 'thương nhân 💼',       min: 120, max: 400, story: 'Bạn buôn bán vật phẩm hiếm giữa các thành phố' },
  { job: 'pháp sư 🔮',           min: 90,  max: 300, story: 'Bạn bán các loại bùa phép cho khách hàng' },
  { job: 'ngư dân 🎣',           min: 50,  max: 200, story: 'Bạn câu được nhiều cá hiếm và bán ở cảng' },
  { job: 'đầu bếp 🍳',           min: 70,  max: 220, story: 'Bạn nấu tiệc cho quý tộc và nhận thù lao' },
  { job: 'thám tử 🕵️',          min: 150, max: 500, story: 'Bạn phá một vụ án lớn và nhận tiền thưởng' },
  { job: 'kiến trúc sư 🏗️',     min: 200, max: 600, story: 'Bạn thiết kế tòa nhà mới cho lãnh chúa' },
  { job: 'streamer 🎮',          min: 50,  max: 800, story: 'Stream của bạn đột nhiên viral, donation bay vào!' },
  { job: 'ca sĩ 🎤',             min: 100, max: 450, story: 'Bạn biểu diễn live và khán giả tip nhiều' },
  { job: 'bác sĩ 🏥',            min: 250, max: 700, story: 'Bạn hoàn thành ca phẫu thuật khó và nhận thưởng' },
];

function fmtTime(ms) {
  const s = Math.floor(ms / 1000);
  const m = Math.floor(s / 60);
  const h = Math.floor(m / 60);
  return h > 0 ? `${h}h ${m % 60}m` : `${m}m ${s % 60}s`;
}

module.exports = {
  name: 'work',
  enabled: true,
  description: 'Làm việc kiếm tiền (cooldown 1 giờ)',
  category: 'Economy',
  aliases: ['lam', 'lamviec', 'job'],
  usage: '!work',
  cooldown: 3,
  prefixSupport: true,
  data: new SlashCommandBuilder()
    .setName('work').setDescription('Làm việc kiếm tiền (cooldown 1 giờ)')
    .setDMPermission(false),

  async execute(interactionOrMessage, args, client) {
    const isSlash = !!interactionOrMessage.isChatInputCommand?.();
    const userId  = isSlash ? interactionOrMessage.user.id : interactionOrMessage.author.id;
    const user    = db.getUser(userId);
    const now     = Date.now();
    const last    = user.lastWork || 0;
    const remaining = COOLDOWN_MS - (now - last);

    if (last !== 0 && remaining > 0) {
      const embed = new EmbedBuilder().setColor(0xFF8C00).setTitle('⏳ Bạn đang mệt!')
        .setDescription(`Hãy nghỉ ngơi thêm **${fmtTime(remaining)}** trước khi làm việc tiếp!`)
        .setFooter({ text: config.footer || 'Stela Network' });
      return isSlash ? interactionOrMessage.reply({ embeds: [embed] }) : interactionOrMessage.reply({ embeds: [embed] });
    }

    const job    = JOBS[Math.floor(Math.random() * JOBS.length)];
    const earned = Math.floor(Math.random() * (job.max - job.min + 1)) + job.min;

    user.money       = (user.money       || 0) + earned;
    user.totalEarned = (user.totalEarned || 0) + earned;
    user.lastWork    = now;

    // Season money tracking
    try {
      const fs = require('fs'), path = require('path');
      const sf = path.join(__dirname, '../../database/seasons.json');
      if (fs.existsSync(sf)) {
        const sd = JSON.parse(fs.readFileSync(sf, 'utf8'));
        if (sd.current) user.seasonMoney = (user.seasonMoney || 0) + earned;
      }
    } catch {}

    db.saveUser(userId, user);

    const embed = new EmbedBuilder().setColor(0x00D26A).setTitle(`💼 Làm việc: ${job.job}`)
      .setDescription(`*${job.story}*`)
      .addFields(
        { name: '💰 Kiếm được',       value: `**+${formatNumber(earned)} 🪙**`,    inline: true },
        { name: '💳 Số dư mới',        value: `**${formatNumber(user.money)} 🪙**`, inline: true },
        { name: '⏰ Làm việc lại sau', value: '**1 giờ**',                           inline: true }
      )
      .setFooter({ text: `${config.footer || 'Stela Network'} • !work mỗi giờ để kiếm tiền` })
      .setTimestamp();

    if (isSlash) await interactionOrMessage.reply({ embeds: [embed] });
    else await interactionOrMessage.reply({ embeds: [embed] });
  }
};
