'use strict';
const { EmbedBuilder, SlashCommandBuilder } = require('discord.js');
const config = require('../../config.json');
const db = require('../../database');
const { formatNumber } = require('../../handlers/utils');

const MEDALS = ['🥇', '🥈', '🥉'];

module.exports = {
  name: 'leaderboard',
  enabled: true,
  description: 'Bảng xếp hạng tiền hoặc XP',
  category: 'Economy',
  aliases: ['top', 'lb', 'ranking', 'xephang'],
  usage: '!top [xp|money]',
  cooldown: 10,
  prefixSupport: true,
  data: new SlashCommandBuilder()
    .setName('leaderboard').setDescription('Bảng xếp hạng tiền hoặc XP')
    .addStringOption(o => o.setName('type').setDescription('Loại xếp hạng').setRequired(false)
      .addChoices({ name: '💰 Tiền', value: 'money' }, { name: '⭐ XP', value: 'xp' }))
    .setDMPermission(false),

  async execute(interactionOrMessage, args, client) {
    const isSlash  = !!interactionOrMessage.isChatInputCommand?.();
    const authorId = isSlash ? interactionOrMessage.user.id : interactionOrMessage.author.id;
    const guild    = interactionOrMessage.guild;

    const mode  = isSlash ? (interactionOrMessage.options.getString('type') || 'money') : (args[0]?.toLowerCase() === 'xp' ? 'xp' : 'money');
    const label = mode === 'xp' ? 'XP' : 'Tiền 🪙';
    const emoji = mode === 'xp' ? '⭐' : '💰';

    if (isSlash) await interactionOrMessage.deferReply();

    const allUsersObj = db.getAllUsers ? db.getAllUsers() : {};
    const allUsers    = Object.entries(allUsersObj).map(([id, u]) => ({ ...u, id }));

    if (!allUsers.length) {
      const e = new EmbedBuilder().setColor(0xFF8C00).setDescription('📭 Chưa có dữ liệu!').setFooter({ text: config.footer || 'Stela Network' });
      return isSlash ? interactionOrMessage.editReply({ embeds: [e] }) : interactionOrMessage.reply({ embeds: [e] });
    }

    const sorted = [...allUsers]
      .sort((a, b) => ((mode === 'xp' ? b.totalXP : b.money) || 0) - ((mode === 'xp' ? a.totalXP : a.money) || 0))
      .slice(0, 10);

    const rows = await Promise.all(sorted.map(async (u, i) => {
      let name = `User ${u.id}`;
      try {
        const member = await guild.members.fetch(u.id).catch(() => null);
        if (member) name = member.user.username;
      } catch {}
      const val   = mode === 'xp' ? (u.totalXP || 0) : (u.money || 0);
      const medal = MEDALS[i] || `**${i+1}.**`;
      const isMe  = u.id === authorId ? ' ← *bạn*' : '';
      return `${medal} **${name}**${isMe} — \`${formatNumber(val)} ${mode === 'xp' ? 'XP' : '🪙'}\``;
    }));

    const allSorted = [...allUsers].sort((a, b) => ((mode === 'xp' ? b.totalXP : b.money) || 0) - ((mode === 'xp' ? a.totalXP : a.money) || 0));
    const myRank = allSorted.findIndex(u => u.id === authorId) + 1;
    const myData = allUsers.find(u => u.id === authorId);
    const myVal  = myData ? (mode === 'xp' ? myData.totalXP : myData.money) || 0 : 0;

    const embed = new EmbedBuilder()
      .setColor(0xFFD700)
      .setTitle(`${emoji} Bảng Xếp Hạng — ${label}`)
      .setDescription(rows.join('\n').slice(0, 4000))
      .setThumbnail(guild.iconURL({ dynamic: true }) || null)
      .setFooter({ text: myRank > 0 ? `Bạn đang ở hạng #${myRank} với ${formatNumber(myVal)} ${mode === 'xp' ? 'XP' : '🪙'}` : `${config.footer || 'Stela Network'} • !top xp để xem BXH XP` })
      .setTimestamp();

    if (isSlash) await interactionOrMessage.editReply({ embeds: [embed] });
    else await interactionOrMessage.reply({ embeds: [embed] });
  }
};
