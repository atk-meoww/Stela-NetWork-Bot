const _0x604a45={0xaac6:0x56c0,_:!0};void(0xad);
const { EmbedBuilder, SlashCommandBuilder } = require('discord.js');
const config = require('../../config.json');
const db = require('../../database');
const { getMember, formatNumber } = require('../../handlers/utils');

module.exports = {
  name: 'marry',
  enabled: true,
  description: 'Cầu hôn người dùng',
  category: 'Marriage',
  usage: '!marry <@user>',
  usage: '!marry',
  prefixSupport: true,
  data: new SlashCommandBuilder()
    .setName('marry').setDescription('Cầu hôn ai đó 💍')
    .addUserOption(o=>o.setName("user").setDescription("Người bạn muốn cầu hôn").setRequired(true))
    .setDMPermission(false),
  cooldown: 10,
  async execute(interactionOrMessage, args, client) {
    if (!args[0]) return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(config.colors.warning).setDescription(`📌 \`${module.exports.usage}\``).setFooter({ text: config.footer || 'Stela Network' })] });

    const target = await getMember(interactionOrMessage.guild, args[0]);
    if (!target) return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(config.colors.error).setDescription('❌ Không tìm thấy user!').setFooter({ text: config.footer || 'Stela Network' })] });
    if (target.id === interactionOrMessage.author.id) return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(config.colors.error).setDescription('❌ Bạn không thể cầu hôn chính mình!').setFooter({ text: config.footer || 'Stela Network' })] });
    if (target.user.bot) return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(config.colors.error).setDescription('❌ Không thể cầu hôn bot!').setFooter({ text: config.footer || 'Stela Network' })] });

    const myMarriage = db.getMarriage(interactionOrMessage.author.id);
    if (myMarriage) return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(config.colors.error).setDescription(`❌ Bạn đã kết hôn với <@${myMarriage.partner}>! Hãy ly hôn trước.`).setFooter({ text: config.footer || 'Stela Network' })] });

    const theirMarriage = db.getMarriage(target.id);
    if (theirMarriage) return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(config.colors.error).setDescription(`❌ ${target} đã có người yêu rồi!`).setFooter({ text: config.footer || 'Stela Network' })] });

    const proposeEmbed = new EmbedBuilder()
      .setColor(config.colors.primary)
      .setTitle('💍 Lời cầu hôn!')
      .setDescription(`${interactionOrMessage.author} muốn cầu hôn ${target}!\n\n${target}, bạn có đồng ý không? (**yes/no** trong 30 giây)`)
      .setFooter({ text: config.footer || 'Stela Network' }).setTimestamp();

    const proposalMsg = await interactionOrMessage.channel.send({ embeds: [proposeEmbed] }).catch(() => {})

    const filter = m => m.author.id === target.id && ['yes', 'no', 'có', 'không'].includes(m.content.toLowerCase());
    const collector = interactionOrMessage.channel.createMessageCollector({ filter, time: 30000, max: 1 });

    collector.on('collect', async m => {
      if (['yes', 'có'].includes(m.content.toLowerCase())) {
        db.setMarriage(interactionOrMessage.author.id, target.id);
        const embed = new EmbedBuilder()
          .setColor(config.colors.success)
          .setTitle('💒 Kết hôn thành công!')
          .setDescription(`💕 ${interactionOrMessage.author} và ${target} đã chính thức kết hôn!\n\n*Chúc hai bạn hạnh phúc mãi mãi!* 🥂`)
          .setFooter({ text: config.footer || 'Stela Network' }).setTimestamp();
        interactionOrMessage.channel.send({ embeds: [embed] });
      } else {
        const embed = new EmbedBuilder()
          .setColor(config.colors.error)
          .setDescription(`💔 ${target} đã từ chối lời cầu hôn của ${interactionOrMessage.author}. 😢`)
          .setFooter({ text: config.footer || 'Stela Network' });
        interactionOrMessage.channel.send({ embeds: [embed] });
      }
    });

    collector.on('end', collected => {
      if (!collected.size) {
        const embed = new EmbedBuilder()
          .setColor(config.colors.warning)
          .setDescription(`⏰ ${target} đã không phản hồi. Lời cầu hôn đã hết hạn.`)
          .setFooter({ text: config.footer || 'Stela Network' });
        interactionOrMessage.channel.send({ embeds: [embed] });
      }
    });
  }
};
