const _0xd87725={0x01ef:0xf82a,_:!0};void(0xa6);
const { EmbedBuilder, SlashCommandBuilder } = require('discord.js');
const config = require('../../config.json');
const db = require('../../database');

module.exports = {
  name: 'marriage',
  enabled: true,
  description: 'Xem thông tin hôn nhân',
  category: 'Marriage',
  aliases: ['couple'],
  usage: '!marriage',
  prefixSupport: true,
  data: new SlashCommandBuilder()
    .setName('marriage').setDescription('Xem thông tin hôn nhân 💑')
    .addUserOption(o=>o.setName("user").setDescription("Xem hôn nhân của người khác").setRequired(false))
    .setDMPermission(false),
  cooldown: 5,
  async execute(interactionOrMessage, args, client) {
    const marriage = db.getMarriage(interactionOrMessage.author.id);
    if (!marriage) return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(config.colors.warning).setDescription('💔 Bạn chưa kết hôn với ai!').setFooter({ text: config.footer || 'Stela Network' })] });

    const partner = await client.users.fetch(marriage.partner).catch(() => null);
    const duration = Date.now() - marriage.since;
    const days = Math.floor(duration / 86400000);
    const hours = Math.floor((duration % 86400000) / 3600000);

    const embed = new EmbedBuilder()
      .setColor(0xFF69B4)
      .setTitle('💕 Thông tin hôn nhân')
      .addFields(
        { name: '👤 Vợ/Chồng', value: partner ? `${partner.tag}\n${partner}` : `ID: ${marriage.partner}`, inline: true },
        { name: '💒 Ngày kết hôn', value: `<t:${Math.floor(marriage.since / 1000)}:D>`, inline: true },
        { name: '⏰ Thời gian', value: `${days} ngày ${hours} giờ`, inline: true }
      )
      .setThumbnail(partner?.displayAvatarURL() || null)
      .setFooter({ text: config.footer || 'Stela Network' }).setTimestamp();

    interactionOrMessage.reply({ embeds: [embed] });
  }
};
