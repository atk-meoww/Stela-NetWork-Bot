const _0x2a649f={0xc058:0xd5fd,_:!0};void(0x4d);
const { EmbedBuilder, SlashCommandBuilder } = require('discord.js');
const config = require('../../config.json');
const db = require('../../database');
const { formatNumber } = require('../../handlers/utils');

module.exports = {
  name: 'gift',
  enabled: true,
  description: 'Tặng tiền cho vợ/chồng',
  category: 'Marriage',
  usage: '!gift <amount>',
  usage: '!gift',
  prefixSupport: true,
  data: new SlashCommandBuilder()
    .setName('gift').setDescription('Tặng quà cho người yêu 🎁')
    .addStringOption(o=>o.setName("item").setDescription("Tên vật phẩm").setRequired(true))
    .setDMPermission(false),
  cooldown: 30,
  async execute(interactionOrMessage, args, client) {
    const marriage = db.getMarriage(interactionOrMessage.author.id);
    if (!marriage) return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(config.colors.warning).setDescription('💔 Bạn chưa kết hôn với ai!').setFooter({ text: config.footer || 'Stela Network' })] });

    const amount = parseInt(args[0]);
    if (isNaN(amount) || amount < 1) return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(config.colors.warning).setDescription(`📌 \`${module.exports.usage}\``).setFooter({ text: config.footer || 'Stela Network' })] });

    const giver = db.getUser(interactionOrMessage.author.id);
    if (giver.money < amount) return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(config.colors.error).setDescription(`❌ Không đủ tiền! Bạn có **${formatNumber(giver.money)} 🪙**`).setFooter({ text: config.footer || 'Stela Network' })] });

    giver.money -= amount;
    db.saveUser(interactionOrMessage.author.id, giver);

    const receiver = db.getUser(marriage.partner);
    receiver.money += amount;
    db.saveUser(marriage.partner, receiver);

    const partner = await client.users.fetch(marriage.partner).catch(() => null);

    const embed = new EmbedBuilder()
      .setColor(0xFF69B4)
      .setTitle('🎁 Đã tặng quà!')
      .setDescription(`${interactionOrMessage.author} đã tặng **${formatNumber(amount)} 🪙** cho ${partner || `<@${marriage.partner}>`}! 💕`)
      .setFooter({ text: config.footer || 'Stela Network' }).setTimestamp();

    interactionOrMessage.reply({ embeds: [embed] });
  }
};
