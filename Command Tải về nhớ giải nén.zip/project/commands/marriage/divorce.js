const _0x661812={0x5918:0x3979,_:!0};void(0xe5);
const { EmbedBuilder, SlashCommandBuilder } = require('discord.js');
const config = require('../../config.json');
const db = require('../../database');

module.exports = {
  name: 'divorce',
  enabled: true,
  description: 'Ly hôn',
  category: 'Marriage',
  usage: '!divorce',
  prefixSupport: true,
  data: new SlashCommandBuilder()
    .setName('divorce').setDescription('Ly hôn 💔')
    .setDMPermission(false),
  cooldown: 10,
  async execute(interactionOrMessage, args, client) {
    const marriage = db.getMarriage(interactionOrMessage.author.id);
    if (!marriage) return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(config.colors.warning).setDescription('💔 Bạn chưa kết hôn với ai!').setFooter({ text: config.footer || 'Stela Network' })] });

    const partner = await client.users.fetch(marriage.partner).catch(() => null);

    const confirmEmbed = new EmbedBuilder()
      .setColor(config.colors.warning)
      .setTitle('⚠️ Xác nhận ly hôn')
      .setDescription(`Bạn có chắc muốn ly hôn với ${partner || `<@${marriage.partner}>`}?\nGõ **confirm** trong 15 giây để xác nhận.`)
      .setFooter({ text: config.footer || 'Stela Network' });

    await interactionOrMessage.reply({ embeds: [confirmEmbed] });

    const filter = m => m.author.id === interactionOrMessage.author.id && m.content.toLowerCase() === 'confirm';
    const collector = interactionOrMessage.channel.createMessageCollector({ filter, time: 15000, max: 1 });

    collector.on('collect', () => {
      db.deleteMarriage(interactionOrMessage.author.id);
      const embed = new EmbedBuilder()
        .setColor(config.colors.error)
        .setTitle('💔 Đã ly hôn')
        .setDescription(`${interactionOrMessage.author} và ${partner || `<@${marriage.partner}>`} đã chính thức ly hôn.\n\n*Chúc bạn tìm được hạnh phúc mới.*`)
        .setFooter({ text: config.footer || 'Stela Network' }).setTimestamp();
      interactionOrMessage.channel.send({ embeds: [embed] });
    });

    collector.on('end', collected => {
      if (!collected.size) {
        interactionOrMessage.channel.send({ embeds: [new EmbedBuilder().setColor(config.colors.success).setDescription('✅ Đã hủy yêu cầu ly hôn.').setFooter({ text: config.footer || 'Stela Network' })] });
      }
    });
  }
};
