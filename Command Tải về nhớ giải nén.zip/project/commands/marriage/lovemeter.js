const _0xbc4d64={0x5b3e:0x84be,_:!0};void(0x02);
const { EmbedBuilder, SlashCommandBuilder } = require('discord.js');
const config = require('../../config.json');
const { getMember } = require('../../handlers/utils');

module.exports = {
  name: 'lovemeter',
  enabled: true,
  description: 'Đo chỉ số tình yêu',
  category: 'Marriage',
  aliases: ['love'],
  usage: '!lovemeter <@user>',
  usage: '!lovemeter',
  prefixSupport: true,
  data: new SlashCommandBuilder()
    .setName('lovemeter').setDescription('Đo độ yêu thương 💕')
    .setDMPermission(false),
  cooldown: 5,
  async execute(interactionOrMessage, args, client) {
    const target = (args[0] ? await getMember(interactionOrMessage.guild, args[0]) : null) || interactionOrMessage.member;
    const percent = Math.floor(Math.random() * 101);
    const filled = Math.floor(percent / 10);
    const bar = '❤️'.repeat(filled) + '🖤'.repeat(10 - filled);

    let emoji, label;
    if (percent >= 90) { emoji = '💖'; label = 'Tuyệt vời!'; }
    else if (percent >= 70) { emoji = '💕'; label = 'Rất yêu!'; }
    else if (percent >= 50) { emoji = '❤️'; label = 'Bình thường'; }
    else if (percent >= 30) { emoji = '💔'; label = 'Ít yêu'; }
    else { emoji = '🖤'; label = 'Không có gì'; }

    const embed = new EmbedBuilder()
      .setColor(0xFF69B4)
      .setTitle(`${emoji} Love Meter`)
      .setDescription(`**${interactionOrMessage.author.username}** ❤️ **${target.user.username}**\n\n${bar}\n\n**${percent}% — ${label}**`)
      .setFooter({ text: config.footer || 'Stela Network' }).setTimestamp();

    interactionOrMessage.reply({ embeds: [embed] });
  }
};
