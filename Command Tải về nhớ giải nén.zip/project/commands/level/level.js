const _0x0b375e={0x8596:0x7cf6,_:!0};void(0xfa);
const { EmbedBuilder, SlashCommandBuilder } = require('discord.js');
const config = require('../../config.json');
const db = require('../../database');
const { formatNumber, getMember } = require('../../handlers/utils');

function calcXPForLevel(level) {
  return level * 100 + (level - 1) * 50;
}

function getProgressBar(current, max) {
  const percent = Math.min(current / max, 1);
  const filled = Math.floor(percent * 15);
  return '🟪'.repeat(filled) + '⬛'.repeat(15 - filled) + ` ${Math.floor(percent * 100)}%`;
}

module.exports = {
  name: 'level',
  enabled: true,
  description: 'Xem level của bạn',
  category: 'Level',
  aliases: ['lvl', 'lv'],
  usage: '!level',
  prefixSupport: true,
  data: new SlashCommandBuilder()
    .setName('level').setDescription('Xem cấp độ và XP')
    .addUserOption(o => o.setName("user").setDescription("Người dùng (bỏ trống = bản thân)").setRequired(false))
    .setDMPermission(false),
  cooldown: 5,
  async execute(interactionOrMessage, args, client) {
    const target = (args[0] ? await getMember(interactionOrMessage.guild, args[0]) : null) || interactionOrMessage.member;
    const user = db.getUser(target.id);
    const xpNeeded = calcXPForLevel(user.level);

    // Rank by level in server
    const allUsers = db.getAllUsers();
    const sorted = Object.entries(allUsers).sort(([, a], [, b]) => (b.level - a.level) || ((b.totalXP || 0) - (a.totalXP || 0)));
    const rank = sorted.findIndex(([id]) => id === target.id) + 1;

    const embed = new EmbedBuilder()
      .setColor(config.colors.primary)
      .setTitle(`📊 Level Card — ${target.user.username}`)
      .setThumbnail(target.user.displayAvatarURL({ dynamic: true, size: 256 }))
      .addFields(
        { name: '🎯 Level', value: `**${user.level}**`, inline: true },
        { name: '🏆 Xếp hạng', value: `**#${rank}**`, inline: true },
        { name: '💰 Tiền', value: `**${formatNumber(user.money)} 🪙**`, inline: true },
        { name: '⭐ XP hiện tại', value: `**${formatNumber(user.xp)} / ${formatNumber(xpNeeded)}**`, inline: false },
        { name: '📈 Tiến độ', value: getProgressBar(user.xp, xpNeeded), inline: false },
        { name: '🌟 Total XP', value: `**${formatNumber(user.totalXP || 0)}**`, inline: true }
      )
      .setFooter({ text: config.footer || 'Stela Network' })
      .setTimestamp();

    interactionOrMessage.reply({ embeds: [embed] });
  }
};
