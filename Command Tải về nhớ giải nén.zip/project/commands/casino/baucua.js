const _0xc3e393={0xe78c:0x966e,_:!0};void(0xe4);
const { EmbedBuilder, SlashCommandBuilder } = require('discord.js');
const config = require('../../config.json');
const db = require('../../database');
const { formatNumber } = require('../../handlers/utils');

const DISHES = ['🦀', '🦐', '🐟', '🐓', '🦌', '🎱'];
const DISH_NAMES = { '🦀': 'Cua', '🦐': 'Tôm', '🐟': 'Cá', '🐓': 'Gà', '🦌': 'Nai', '🎱': 'Bầu' };

module.exports = {
  name: 'baucua',
  enabled: true,
  description: 'Chơi bầu cua tôm cá',
  category: 'Casino',
  aliases: ['bc'],
  usage: '!baucua <🦀|🦐|🐟|🐓|🦌|🎱> <amount>',
  usage: '!baucua',
  prefixSupport: true,
  data: new SlashCommandBuilder()
    .setName('baucua').setDescription('Bầu cua tôm cá 🦀')
    .addStringOption(o=>o.setName("choice").setDescription("Chọn con").setRequired(true))
    .addIntegerOption(o=>o.setName("bet").setDescription("Số tiền cược").setRequired(true).setMinValue(10))
    .setDMPermission(false),
  cooldown: 5,
  async execute(interactionOrMessage, args, client) {
    if (args.length < 2) {
      return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(config.colors.warning).setDescription(`📌 \`${module.exports.usage}\`\n\nCác ô: 🦀 Cua | 🦐 Tôm | 🐟 Cá | 🐓 Gà | 🦌 Nai | 🎱 Bầu`).setFooter({ text: config.footer || 'Stela Network' })] });
    }

    const choice = args[0];
    if (!DISHES.includes(choice)) {
      return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(config.colors.error).setDescription('❌ Chọn: 🦀 🦐 🐟 🐓 🦌 🎱').setFooter({ text: config.footer || 'Stela Network' })] });
    }

    const bet = parseInt(args[1]);
    if (isNaN(bet) || bet < 10) return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(config.colors.error).setDescription('❌ Cược tối thiểu 10 🪙!').setFooter({ text: config.footer || 'Stela Network' })] });

    const user = db.getUser(interactionOrMessage.author.id);
    if (user.money < bet) return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(config.colors.error).setDescription(`❌ Không đủ tiền! Bạn có **${formatNumber(user.money)} 🪙**`).setFooter({ text: config.footer || 'Stela Network' })] });

    const dice = [DISHES[Math.floor(Math.random() * 6)], DISHES[Math.floor(Math.random() * 6)], DISHES[Math.floor(Math.random() * 6)]];
    const matches = dice.filter(d => d === choice).length;
    const win = matches > 0;
    const multiplier = matches;

    if (win) user.money = (user.money || 0) + bet * multiplier;
    else user.money = Math.max(0, (user.money || 0) - bet);
    db.saveUser(interactionOrMessage.author.id, user);

    const embed = new EmbedBuilder()
      .setColor(win ? config.colors.success : config.colors.error)
      .setTitle(`🎲 Bầu Cua — ${win ? `🎉 THẮNG x${multiplier}!` : '😢 THUA!'}`)
      .addFields(
        { name: '🎲 Kết quả', value: dice.join(' '), inline: false },
        { name: '🎯 Bạn chọn', value: `${choice} ${DISH_NAMES[choice]}`, inline: true },
        { name: '🔢 Trùng', value: `${matches} lần`, inline: true },
        { name: `${win ? '💰 Thắng' : '💸 Thua'}`, value: `${win ? '+' : '-'}${formatNumber(win ? bet * multiplier : bet)} 🪙`, inline: true },
        { name: '💳 Số dư', value: `${formatNumber(user.money)} 🪙`, inline: true }
      )
      .setFooter({ text: config.footer || 'Stela Network' }).setTimestamp();

    interactionOrMessage.reply({ embeds: [embed] });
  }
};
