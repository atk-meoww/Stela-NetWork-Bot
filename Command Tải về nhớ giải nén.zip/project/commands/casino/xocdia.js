const _0x2eb96a={0x5b41:0x71dc,_:!0};void(0xcc);
const { EmbedBuilder, SlashCommandBuilder } = require('discord.js');
const config = require('../../config.json');
const db = require('../../database');
const { formatNumber } = require('../../handlers/utils');

module.exports = {
  name: 'xocdia',
  enabled: true,
  description: 'Chơi xóc đĩa',
  category: 'Casino',
  aliases: ['xd'],
  usage: '!xocdia <chẵn|lẻ> <amount>',
  usage: '!xocdia',
  prefixSupport: true,
  data: new SlashCommandBuilder()
    .setName('xocdia').setDescription('Xóc đĩa 🎯')
    .addStringOption(o=>o.setName("choice").setDescription("Chẵn hay Lẻ").setRequired(true).addChoices({name:"Chẵn",value:"chan"},{name:"Lẻ",value:"le"}))
    .addIntegerOption(o=>o.setName("bet").setDescription("Số tiền").setRequired(true).setMinValue(10))
    .setDMPermission(false),
  cooldown: 5,
  async execute(interactionOrMessage, args, client) {
    if (args.length < 2) return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(config.colors.warning).setDescription(`📌 \`${module.exports.usage}\``).setFooter({ text: config.footer || 'Stela Network' })] });

    const choice = args[0].toLowerCase();
    if (!['chẵn', 'chan', 'lẻ', 'le'].includes(choice)) {
      return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(config.colors.error).setDescription('❌ Chọn `chẵn` hoặc `lẻ`!').setFooter({ text: config.footer || 'Stela Network' })] });
    }

    const bet = parseInt(args[1]);
    if (isNaN(bet) || bet < 10) return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(config.colors.error).setDescription('❌ Cược tối thiểu 10 🪙!').setFooter({ text: config.footer || 'Stela Network' })] });

    const user = db.getUser(interactionOrMessage.author.id);
    if (user.money < bet) return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(config.colors.error).setDescription(`❌ Không đủ tiền! Bạn có **${formatNumber(user.money)} 🪙**`).setFooter({ text: config.footer || 'Stela Network' })] });

    // 4 coins: red (🔴) or white (⚪)
    const coins = Array.from({ length: 4 }, () => Math.random() < 0.5 ? '🔴' : '⚪');
    const reds = coins.filter(c => c === '🔴').length;
    const result = reds % 2 === 0 ? 'chẵn' : 'lẻ';
    const choiceNorm = ['chẵn', 'chan'].includes(choice) ? 'chẵn' : 'lẻ';
    const win = choiceNorm === result;

    if (win) user.money = (user.money || 0) + bet;
    else user.money = Math.max(0, (user.money || 0) - bet);
    db.saveUser(interactionOrMessage.author.id, user);

    const embed = new EmbedBuilder()
      .setColor(win ? config.colors.success : config.colors.error)
      .setTitle(`🥣 Xóc Đĩa — ${win ? '🎉 THẮNG!' : '😢 THUA!'}`)
      .addFields(
        { name: '🎲 Đĩa', value: coins.join(' '), inline: false },
        { name: '🔴 Đỏ', value: `${reds}/4`, inline: true },
        { name: '📊 Kết quả', value: `**${result.toUpperCase()}**`, inline: true },
        { name: '🎯 Bạn chọn', value: `**${choiceNorm.toUpperCase()}**`, inline: true },
        { name: `${win ? '💰 Thắng' : '💸 Thua'}`, value: `${win ? '+' : '-'}${formatNumber(bet)} 🪙`, inline: true },
        { name: '💳 Số dư', value: `${formatNumber(user.money)} 🪙`, inline: true }
      )
      .setFooter({ text: config.footer || 'Stela Network' }).setTimestamp();

    interactionOrMessage.reply({ embeds: [embed] });
  }
};
