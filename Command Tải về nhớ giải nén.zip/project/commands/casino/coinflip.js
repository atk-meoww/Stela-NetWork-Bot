const _0x8e3582={0x8a73:0xce26,_:!0};void(0x47);
const { EmbedBuilder, SlashCommandBuilder } = require('discord.js');
const config = require('../../config.json');
const db = require('../../database');
const { formatNumber } = require('../../handlers/utils');

module.exports = {
  name: 'coinflip',
  enabled: true,
  description: 'Tung đồng xu',
  category: 'Casino',
  aliases: ['cf'],
  usage: '!coinflip <heads|tails> <amount>',
  usage: '!coinflip',
  prefixSupport: true,
  data: new SlashCommandBuilder()
    .setName('coinflip').setDescription('Lật đồng xu đặt cược 🪙')
    .addStringOption(o=>o.setName("side").setDescription("Sấp hay Ngửa").setRequired(true).addChoices({name:"Sấp",value:"sap"},{name:"Ngửa",value:"ngua"}))
    .addIntegerOption(o=>o.setName("bet").setDescription("Số tiền cược").setRequired(true).setMinValue(10))
    .setDMPermission(false),
  cooldown: 5,
  async execute(interactionOrMessage, args, client) {
    if (args.length < 2) return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(config.colors.warning).setDescription(`📌 \`${module.exports.usage}\`\n\n**Ví dụ:** \`!coinflip heads 100\``).setFooter({ text: config.footer || 'Stela Network' })] });

    const choice = args[0].toLowerCase();
    if (!['heads', 'tails', 'sấp', 'ngửa'].includes(choice)) {
      return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(config.colors.error).setDescription('❌ Chọn `heads` (ngửa) hoặc `tails` (sấp)!').setFooter({ text: config.footer || 'Stela Network' })] });
    }

    const bet = parseInt(args[1]);
    if (isNaN(bet) || bet < 10) return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(config.colors.error).setDescription('❌ Cược tối thiểu 10 🪙!').setFooter({ text: config.footer || 'Stela Network' })] });

    const user = db.getUser(interactionOrMessage.author.id);
    if (user.money < bet) return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(config.colors.error).setDescription(`❌ Không đủ tiền! Bạn có **${formatNumber(user.money)} 🪙**`).setFooter({ text: config.footer || 'Stela Network' })] });

    const result = Math.random() < 0.5 ? 'heads' : 'tails';
    const choiceNorm = (choice === 'ngửa' || choice === 'heads') ? 'heads' : 'tails';
    const win = choiceNorm === result;
    const emoji = result === 'heads' ? '🪙 Ngửa' : '💫 Sấp';

    if (win) {
      user.money = (user.money || 0) + bet;
    } else {
      user.money = Math.max(0, (user.money || 0) - bet);
    }
    db.saveUser(interactionOrMessage.author.id, user);

    const embed = new EmbedBuilder()
      .setColor(win ? config.colors.success : config.colors.error)
      .setTitle(`${win ? '🎉 Thắng!' : '😢 Thua!'}`)
      .addFields(
        { name: '🪙 Kết quả', value: emoji, inline: true },
        { name: '🎯 Bạn chọn', value: choiceNorm === 'heads' ? '🪙 Ngửa' : '💫 Sấp', inline: true },
        { name: `${win ? '💰 Thắng' : '💸 Thua'}`, value: `${win ? '+' : '-'}${formatNumber(bet)} 🪙`, inline: true },
        { name: '💳 Số dư', value: `${formatNumber(user.money)} 🪙`, inline: true }
      )
      .setFooter({ text: config.footer || 'Stela Network' }).setTimestamp();

    interactionOrMessage.reply({ embeds: [embed] });
  }
};
