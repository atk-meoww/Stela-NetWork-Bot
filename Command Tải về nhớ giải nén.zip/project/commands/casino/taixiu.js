const _0xed2457={0x4be6:0x4d74,_:!0};void(0x6e);
const { EmbedBuilder, SlashCommandBuilder } = require('discord.js');
const config = require('../../config.json');
const db = require('../../database');
const { formatNumber } = require('../../handlers/utils');

module.exports = {
  name: 'taixiu',
  enabled: true,
  description: 'Chơi tài xỉu',
  category: 'Casino',
  aliases: ['tx'],
  usage: '!taixiu <tài|xỉu> <amount>',
  usage: '!taixiu',
  prefixSupport: true,
  data: new SlashCommandBuilder()
    .setName('taixiu').setDescription('Cược Tài Xỉu 🎲')
    .addStringOption(o=>o.setName("choice").setDescription("Tài hay Xỉu").setRequired(true).addChoices({name:"Tài",value:"tai"},{name:"Xỉu",value:"xiu"}))
    .addIntegerOption(o=>o.setName("bet").setDescription("Số tiền cược").setRequired(true).setMinValue(10))
    .setDMPermission(false),
  cooldown: 5,
  async execute(interactionOrMessage, args, client) {
    if (args.length < 2) return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(config.colors.warning).setDescription(`📌 \`${module.exports.usage}\``).setFooter({ text: config.footer || 'Stela Network' })] });

    const choice = args[0].toLowerCase();
    if (!['tài', 'tai', 'xỉu', 'xiu'].includes(choice)) {
      return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(config.colors.error).setDescription('❌ Chọn `tài` hoặc `xỉu`!').setFooter({ text: config.footer || 'Stela Network' })] });
    }

    const bet = parseInt(args[1]);
    if (isNaN(bet) || bet < 10) return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(config.colors.error).setDescription('❌ Cược tối thiểu 10 🪙!').setFooter({ text: config.footer || 'Stela Network' })] });

    const user = db.getUser(interactionOrMessage.author.id);
    if (user.money < bet) return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(config.colors.error).setDescription(`❌ Không đủ tiền! Bạn có **${formatNumber(user.money)} 🪙**`).setFooter({ text: config.footer || 'Stela Network' })] });

    const dice = [
      Math.floor(Math.random() * 6) + 1,
      Math.floor(Math.random() * 6) + 1,
      Math.floor(Math.random() * 6) + 1
    ];
    const total = dice.reduce((a, b) => a + b, 0);
    const result = total >= 11 ? 'tài' : 'xỉu';
    const choiceNorm = ['tài', 'tai'].includes(choice) ? 'tài' : 'xỉu';
    const win = choiceNorm === result;

    const diceEmojis = { 1: '⚀', 2: '⚁', 3: '⚂', 4: '⚃', 5: '⚄', 6: '⚅' };
    const diceStr = dice.map(d => diceEmojis[d]).join(' ');

    if (win) user.money = (user.money || 0) + bet;
    else user.money = Math.max(0, (user.money || 0) - bet);
    db.saveUser(interactionOrMessage.author.id, user);

    const embed = new EmbedBuilder()
      .setColor(win ? config.colors.success : config.colors.error)
      .setTitle(`🎲 Tài Xỉu — ${win ? '🎉 THẮNG!' : '😢 THUA!'}`)
      .addFields(
        { name: '🎲 Xúc xắc', value: `${diceStr} = **${total}**`, inline: false },
        { name: '📊 Kết quả', value: `**${result.toUpperCase()}** (${total >= 11 ? '11-18' : '3-10'})`, inline: true },
        { name: '🎯 Bạn chọn', value: `**${choiceNorm.toUpperCase()}**`, inline: true },
        { name: `${win ? '💰 Thắng' : '💸 Thua'}`, value: `${win ? '+' : '-'}${formatNumber(bet)} 🪙`, inline: true },
        { name: '💳 Số dư', value: `${formatNumber(user.money)} 🪙`, inline: true }
      )
      .setFooter({ text: config.footer || 'Stela Network' }).setTimestamp();

    interactionOrMessage.reply({ embeds: [embed] });
  }
};
