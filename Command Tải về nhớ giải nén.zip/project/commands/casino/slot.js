const _0xcec480={0xe0b6:0x0c10,_:!0};void(0x63);
const { EmbedBuilder, SlashCommandBuilder } = require('discord.js');
const config = require('../../config.json');
const db = require('../../database');
const { formatNumber } = require('../../handlers/utils');

const SYMBOLS = ['🍒', '🍋', '🍊', '🍇', '⭐', '💎', '7️⃣'];
const WEIGHTS = [30, 25, 20, 15, 5, 3, 2];

function weightedRandom() {
  const total = WEIGHTS.reduce((a, b) => a + b, 0);
  let r = Math.random() * total;
  for (let i = 0; i < SYMBOLS.length; i++) {
    r -= WEIGHTS[i];
    if (r <= 0) return SYMBOLS[i];
  }
  return SYMBOLS[0];
}

const MULTIPLIERS = {
  '7️⃣': 10,
  '💎': 7,
  '⭐': 5,
  '🍇': 3,
  '🍊': 2,
  '🍋': 2,
  '🍒': 1.5
};

module.exports = {
  name: 'slot',
  enabled: true,
  description: 'Chơi máy đánh bạc',
  category: 'Casino',
  usage: '!slot <amount>',
  usage: '!slot',
  prefixSupport: true,
  data: new SlashCommandBuilder()
    .setName('slot').setDescription('Máy đánh bạc slot 🎰')
    .addIntegerOption(o=>o.setName("bet").setDescription("Số tiền cược").setRequired(true).setMinValue(10))
    .setDMPermission(false),
  cooldown: 5,
  async execute(interactionOrMessage, args, client) {
    if (!args[0]) return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(0xFF8C00).setDescription(`❌ Cách dùng: \`!${module.exports.name} <lượng cược>\``).setFooter({ text: config.footer || 'Stela Network' })] });
    const bet = parseInt(args[0]);
    if (isNaN(bet) || bet < 10) return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(config.colors.warning).setDescription('📌 `!slot <amount>` — Cược tối thiểu **10 🪙**').setFooter({ text: config.footer || 'Stela Network' })] });

    const user = db.getUser(interactionOrMessage.author.id);
    if (user.money < bet) return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(config.colors.error).setDescription(`❌ Không đủ tiền! Bạn có **${formatNumber(user.money)} 🪙**`).setFooter({ text: config.footer || 'Stela Network' })] });

    const reels = [weightedRandom(), weightedRandom(), weightedRandom()];
    const allSame = reels[0] === reels[1] && reels[1] === reels[2];
    const twoSame = reels[0] === reels[1] || reels[1] === reels[2] || reels[0] === reels[2];

    let win = 0;
    let resultText = '';
    if (allSame) {
      const mult = MULTIPLIERS[reels[0]] || 1.5;
      win = Math.floor(bet * mult);
      resultText = `🎰 **JACKPOT! x${mult}**`;
    } else if (twoSame) {
      win = Math.floor(bet * 0.5);
      resultText = '🎰 **2 trùng! x0.5**';
    } else {
      win = -bet;
      resultText = '❌ Không trùng';
    }

    user.money = Math.max(0, (user.money || 0) + win);
    db.saveUser(interactionOrMessage.author.id, user);

    const embed = new EmbedBuilder()
      .setColor(win > 0 ? config.colors.success : config.colors.error)
      .setTitle('🎰 Slot Machine')
      .setDescription(`┌─────────────┐\n│ ${reels.join('  ')} │\n└─────────────┘`)
      .addFields(
        { name: '📊 Kết quả', value: resultText, inline: false },
        { name: `${win > 0 ? '💰 Thắng' : '💸 Thua'}`, value: `${win > 0 ? '+' : ''}${formatNumber(win)} 🪙`, inline: true },
        { name: '💳 Số dư', value: `${formatNumber(user.money)} 🪙`, inline: true }
      )
      .setFooter({ text: config.footer || 'Stela Network' }).setTimestamp();

    interactionOrMessage.reply({ embeds: [embed] });
  }
};
