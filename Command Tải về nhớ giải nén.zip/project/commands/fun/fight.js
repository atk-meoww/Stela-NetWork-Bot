'use strict';
const { EmbedBuilder, SlashCommandBuilder } = require('discord.js');
const config = require('../../config.json');
const rand = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;

module.exports = {
  name: 'fight',
  enabled: true,
  description: 'Thách đấu 1v1',
  category: 'Fun',
  aliases: ['battle', 'dau'],
  usage: '!fight <@user>',
  cooldown: 5,
  prefixSupport: true,
  data: new SlashCommandBuilder()
    .setName('fight')
    .setDescription('Thách đấu 1v1 với người khác')
    .addUserOption(o => o.setName('opponent').setDescription('Người bị thách đấu').setRequired(true))
    .setDMPermission(false),
  async execute(interactionOrMessage, args) {
    const isSlash = !!interactionOrMessage.isChatInputCommand?.();
    const author = isSlash ? interactionOrMessage.user : interactionOrMessage.author;
    const opponent = isSlash
      ? interactionOrMessage.options.getUser('opponent')
      : interactionOrMessage.mentions.users.first();

    if (!opponent) {
      const msg = '❌ Tag người bạn muốn thách đấu!';
      return isSlash ? interactionOrMessage.reply({ content: msg, ephemeral: true }) : interactionOrMessage.reply(msg);
    }
    if (opponent.id === author.id || opponent.bot) {
      const msg = opponent.bot ? '❌ Không thách đấu bot được!' : '❌ Không tự đánh nhau được!';
      return isSlash ? interactionOrMessage.reply({ content: msg, ephemeral: true }) : interactionOrMessage.reply(msg);
    }
    if (isSlash) await interactionOrMessage.deferReply();

    const winner = rand(0, 1) === 0 ? author : opponent;
    const loser = winner.id === author.id ? opponent : author;
    const rounds = rand(3, 6);
    const actions = ['tung cú đấm', 'dùng kỹ năng đặc biệt', 'phản công cực mạnh', 'tấn công liên tiếp', 'né đòn và phản'];
    const log = [`⚔️ **${author.username}** thách đấu **${opponent.username}**! (${rounds} hiệp)\n`];
    for (let i = 1; i <= rounds; i++) {
      const atk = rand(0, 1) === 0 ? author : opponent;
      const def = atk.id === author.id ? opponent : author;
      log.push(`**Hiệp ${i}:** ${atk.username} ${actions[rand(0, actions.length-1)]} → ${def.username} **-${rand(10,50)} HP**`);
    }

    const embed = new EmbedBuilder()
      .setColor(config.colors?.primary || '#7B2FBE')
      .setTitle('⚔️ Kết quả đấu')
      .setDescription(log.join('\n').slice(0, 3900))
      .addFields({ name: '🏆 Người chiến thắng', value: `**${winner.username}** đánh bại ${loser.username}!` })
      .setFooter({ text: config.footer || 'Stela Network' }).setTimestamp();

    return isSlash ? interactionOrMessage.editReply({ embeds: [embed] }) : interactionOrMessage.reply({ embeds: [embed] });
  }
};
