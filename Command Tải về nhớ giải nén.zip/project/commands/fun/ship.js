'use strict';
const { EmbedBuilder, SlashCommandBuilder } = require('discord.js');
const config = require('../../config.json');
function hashStr(s) { let h=0; for(let i=0;i<s.length;i++){h=(h<<5)-h+s.charCodeAt(i);h|=0;} return Math.abs(h); }

module.exports = {
  name: 'ship',
  enabled: true,
  description: 'Tính độ tương hợp giữa 2 người',
  category: 'Fun',
  usage: '!ship <tên1> <tên2>',
  cooldown: 3,
  prefixSupport: true,
  data: new SlashCommandBuilder()
    .setName('ship').setDescription('Tính độ tương hợp giữa 2 người')
    .addStringOption(o => o.setName('name1').setDescription('Người 1').setRequired(true).setMaxLength(100))
    .addStringOption(o => o.setName('name2').setDescription('Người 2').setRequired(true).setMaxLength(100))
    .setDMPermission(false),
  async execute(interactionOrMessage, args) {
    const isSlash = !!interactionOrMessage.isChatInputCommand?.();
    let n1, n2;
    if (isSlash) { n1 = interactionOrMessage.options.getString('name1').trim(); n2 = interactionOrMessage.options.getString('name2').trim(); }
    else {
      if (!args || args.length < 2) return interactionOrMessage.reply('❌ Cú pháp: `!ship <tên1> <tên2>`');
      n1 = args[0]; n2 = args[1];
    }
    const score = hashStr([n1,n2].sort().join('-').toLowerCase()) % 101;
    const bar = '█'.repeat(Math.floor(score/10)) + '░'.repeat(10-Math.floor(score/10));
    const desc = score>=90?'💍 Định mệnh! Sinh ra dành cho nhau':score>=70?'💕 Cặp đôi hoàn hảo!':score>=50?'✨ Khá tốt, có chemistry':score>=30?'😅 Chỉ là bạn bè...':'💀 Hmm, không hợp nhau lắm';
    const embed = new EmbedBuilder()
      .setColor(config.colors?.secondary || '#4169E1')
      .setTitle(`💖 Ship: ${n1} & ${n2}`).setDescription(`**${score}%** tương hợp\n\`${bar}\`\n\n*${desc}*`)
      .setFooter({ text: config.footer || 'Stela Network' });
    return isSlash ? interactionOrMessage.reply({ embeds: [embed] }) : interactionOrMessage.reply({ embeds: [embed] });
  }
};
