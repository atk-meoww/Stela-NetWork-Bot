'use strict';
const { EmbedBuilder, SlashCommandBuilder } = require('discord.js');
const config = require('../../config.json');

module.exports = {
  name: 'mock',
  enabled: true,
  description: 'cOnVeRt TeXt SaNh SpOnGeBoB',
  category: 'Fun',
  usage: '!mock <text>',
  cooldown: 3,
  prefixSupport: true,
  data: new SlashCommandBuilder().setName('mock').setDescription('cOnVeRt TeXt → SpOnGeBoB CaSe 🧽')
    .addStringOption(o => o.setName('text').setDescription('Text cần mock').setRequired(true).setMaxLength(500))
    .setDMPermission(false),
  async execute(interactionOrMessage, args) {
    const isSlash = !!interactionOrMessage.isChatInputCommand?.();
    const text = isSlash ? interactionOrMessage.options.getString('text') : args?.join(' ');
    if (!text) return isSlash ? interactionOrMessage.reply({ content: '❌ Nhập text!', ephemeral: true }) : interactionOrMessage.reply('❌ Nhập text!');
    const mocked = [...text].map((c,i) => i%2===0 ? c.toLowerCase() : c.toUpperCase()).join('');
    const embed = new EmbedBuilder()
      .setColor(config.colors?.warning || '#FFA502')
      .setTitle('🧽 sPoNgEbOb CaSe').setDescription(`"${mocked}"`)
      .setFooter({ text: config.footer || 'Stela Network' });
    return isSlash ? interactionOrMessage.reply({ embeds: [embed] }) : interactionOrMessage.reply({ embeds: [embed] });
  }
};
