const _0xb0f327={0xa405:0xe82d,_:!0};void(0xb0);
const { EmbedBuilder, PermissionFlagsBits, SlashCommandBuilder } = require('discord.js');
const config = require('../../config.json');
const { isAdmin } = require('../../handlers/utils');

module.exports = {
  name: 'say',
  enabled: true,
  description: 'Bot nói thay bạn',
  category: 'Fun',
  usage: '!say <message>',
  usage: '!say',
  prefixSupport: true,
  data: new SlashCommandBuilder()
    .setName('say').setDescription('Bot nói thay bạn')
    .addStringOption(o => o.setName("text").setDescription("Nội dung").setRequired(true).setMaxLength(500))
    .setDMPermission(false),
  cooldown: 5,
  async execute(interactionOrMessage, args, client) {
    if (!isAdmin(interactionOrMessage.author.id) && !interactionOrMessage.member?.permissions.has(PermissionFlagsBits.ManageMessages)) {
      return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(config.colors.error).setDescription('❌ Chỉ Admin/Mod mới dùng được lệnh này!').setFooter({ text: config.footer || 'Stela Network' })] });
    }
    if (!args.length) return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(config.colors.warning).setDescription('📌 `!say <message>`').setFooter({ text: config.footer || 'Stela Network' })] });

    const text = args.join(' ');
    await message.delete().catch(() => {});
    interactionOrMessage.channel.send(text).catch(()=>{});
  }
};
