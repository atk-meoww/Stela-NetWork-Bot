const _0x81794a={0x62e0:0xd4b2,_:!0};void(0xff);
const { EmbedBuilder, SlashCommandBuilder } = require('discord.js');
const config = require('../../config.json');

const answers = [
  { text: 'Chắc chắn rồi! 🎉', positive: true },
  { text: 'Có vẻ vậy! ✅', positive: true },
  { text: 'Theo quan điểm của tôi, có! 😊', positive: true },
  { text: 'Cứ tự tin mà làm! 💪', positive: true },
  { text: 'Dấu hiệu rất tốt! 🌟', positive: true },
  { text: 'Có lẽ vậy... 🤔', positive: null },
  { text: 'Chưa rõ, hỏi lại sau nhé 🌀', positive: null },
  { text: 'Khó nói lắm... 😶', positive: null },
  { text: 'Không chắc 🤷', positive: null },
  { text: 'Không có khả năng! ❌', positive: false },
  { text: 'Chắc chắn không! 🚫', positive: false },
  { text: 'Triển vọng không tốt 😟', positive: false },
  { text: 'Đừng mơ nhé! 😂', positive: false }
];

module.exports = {
  name: '8ball',
  enabled: true,
  description: 'Hỏi quả cầu 8',
  category: 'Fun',
  aliases: ['8b'],
  usage: '!8ball <câu hỏi>',
  usage: '!8ball',
  prefixSupport: true,
  data: new SlashCommandBuilder()
    .setName('8ball').setDescription('Hỏi bói bóng 8 ✨')
    .addStringOption(o => o.setName("question").setDescription("Câu hỏi").setRequired(true))
    .setDMPermission(false),
  cooldown: 3,
  async execute(interactionOrMessage, args, client) {
    if (!args.length) return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(config.colors.warning).setDescription('📌 `!8ball <câu hỏi>`').setFooter({ text: config.footer || 'Stela Network' })] });
    const question = args.join(' ');
    const answer = answers[Math.floor(Math.random() * answers.length)];
    const color = answer.positive === true ? config.colors.success : answer.positive === false ? config.colors.error : config.colors.warning;

    const embed = new EmbedBuilder()
      .setColor(color)
      .setTitle('🎱 Magic 8-Ball')
      .addFields(
        { name: '❓ Câu hỏi', value: question, inline: false },
        { name: '🎱 Trả lời', value: `**${answer.text}**`, inline: false }
      )
      .setFooter({ text: config.footer || 'Stela Network' }).setTimestamp();

    interactionOrMessage.reply({ embeds: [embed] });
  }
};
