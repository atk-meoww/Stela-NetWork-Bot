const _0x0248a9={0xaf68:0x7394,_:!0};void(0x23);
const { EmbedBuilder, SlashCommandBuilder } = require('discord.js');
const config = require('../../config.json');

const DICE_EMOJI = { 1: '⚀', 2: '⚁', 3: '⚂', 4: '⚃', 5: '⚄', 6: '⚅' };

module.exports = {
  name: 'dice',
  enabled: true,
  description: 'Tung xúc xắc',
  category: 'Fun',
  aliases: ['roll'],
  usage: '!dice [sides]',
  usage: '!dice',
  prefixSupport: true,
  data: new SlashCommandBuilder()
    .setName('dice').setDescription('Tung xúc xắc 🎲')
    .setDMPermission(false),
  cooldown: 3,
  async execute(interactionOrMessage, args, client) {
    const sides = parseInt(args[0]) || 6;
    if (sides < 2 || sides > 1000) return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(config.colors.error).setDescription('❌ Số mặt phải từ 2 đến 1000!').setFooter({ text: config.footer || 'Stela Network' })] });

    const result = Math.floor(Math.random() * sides) + 1;
    const emoji = sides === 6 ? DICE_EMOJI[result] : '🎲';

    const embed = new EmbedBuilder()
      .setColor(config.colors.secondary)
      .setTitle('🎲 Tung xúc xắc')
      .setDescription(`${emoji} Kết quả: **${result}** / ${sides}`)
      .setFooter({ text: config.footer || 'Stela Network' }).setTimestamp();

    interactionOrMessage.reply({ embeds: [embed] });
  }
};
