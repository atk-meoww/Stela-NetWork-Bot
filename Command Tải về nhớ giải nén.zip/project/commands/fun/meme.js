'use strict';
const _0xd30ab4={0x35ae:0x8b8d,_:!0};void(0x21);
const { EmbedBuilder, SlashCommandBuilder } = require('discord.js');
const config = require('../../config.json');
const https  = require('https');

const SUBS = ['memes', 'dankmemes', 'me_irl', 'AdviceAnimals', 'comedyheaven'];

function httpsGet(url) {
  return new Promise((resolve, reject) => {
    const req = https.get(url, { headers: { 'User-Agent': `${config.footer.replace(/ /g,'')}/Bot` } }, (res) => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        return httpsGet(res.headers.location).then(resolve).catch(reject);
      }
      let raw = '';
      res.setEncoding('utf8');
      res.on('data', c => raw += c);
      res.on('end', () => {
        try { resolve(JSON.parse(raw)); } catch { reject(new Error('Bad JSON')); }
      });
    });
    req.setTimeout(8000, () => { req.destroy(); reject(new Error('Timeout')); });
    req.on('error', reject);
  });
}

module.exports = {
  name: 'meme',
  enabled: true,
  description: 'Lấy meme ngẫu nhiên từ Reddit',
  category: 'Fun',
  aliases: ['memes', 'funny'],
  usage: '!meme',
  prefixSupport: true,
  data: new SlashCommandBuilder()
    .setName('meme').setDescription('Meme ngẫu nhiên 😂')
    .setDMPermission(false),
  cooldown: 5,
  async execute(interactionOrMessage, args, client) {
    const sub = SUBS[Math.floor(Math.random() * SUBS.length)];
    const msg = await interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(0xFFA502)
      .setDescription('😂 Đang lấy meme...').setFooter({ text: config.footer || 'Stela Network' })] });

    try {
      const data = await httpsGet(`https://meme-api.com/gimme/${sub}`);

      if (!data?.url || data.nsfw) {
        // Retry with different sub
        const data2 = await httpsGet(`https://meme-api.com/gimme/memes`);
        if (!data2?.url) throw new Error('No meme found');
        Object.assign(data, data2);
      }

      const embed = new EmbedBuilder()
        .setColor(0xFF6B35)
        .setTitle(data.title?.slice(0, 256) || 'Meme')
        .setURL(data.postLink)
        .setImage(data.url)
        .addFields(
          { name: '👍 Upvotes',  value: `**${(data.ups || 0).toLocaleString()}**`, inline: true },
          { name: '📌 Sub',      value: `r/${data.subreddit}`,                      inline: true },
          { name: '✍️ Tác giả', value: `u/${data.author}`,                          inline: true }
        )
        .setFooter({ text: `${config.footer} • Reddit` })
        .setTimestamp();

      msg.edit({ embeds: [embed] });
    } catch (err) {
      msg.edit({ embeds: [new EmbedBuilder().setColor(0xFF4757)
        .setDescription('❌ Không lấy được meme, thử lại sau!')
        .setFooter({ text: config.footer || 'Stela Network' })] });
    }
  }
};
