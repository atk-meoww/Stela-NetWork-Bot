'use strict';
const _0x5820f2={0x2f0c:0xcfa0,_:!0};void(0x61);
const { EmbedBuilder, SlashCommandBuilder } = require('discord.js');
const config = require('../../config.json');

const CARDS = [
  { name:'🌟 The Star',         meaning:'Hy vọng, cảm hứng và may mắn đang đến với bạn.',          lucky:'💙 Xanh dương',  num:4 },
  { name:'☀️ The Sun',          meaning:'Thành công, niềm vui và năng lượng tích cực bao trùm!',    lucky:'🌕 Vàng',        num:7 },
  { name:'🌙 The Moon',         meaning:'Trực giác mạnh nhưng hãy cẩn thận với ảo tưởng.',         lucky:'⚪ Trắng',        num:2 },
  { name:'⚡ The Tower',        meaning:'Thay đổi đột ngột, nhưng sau cơn mưa trời lại sáng.',      lucky:'🔴 Đỏ',          num:1 },
  { name:'⚖️ Justice',         meaning:'Công lý và sự thật sẽ chiến thắng hôm nay.',               lucky:'💚 Xanh lá',      num:8 },
  { name:'🃏 The Fool',         meaning:'Khởi đầu mới, hãy tin tưởng vào bản thân!',               lucky:'🟢 Xanh ngọc',    num:0 },
  { name:'💪 Strength',         meaning:'Bạn mạnh hơn bạn nghĩ. Đối mặt với thử thách!',           lucky:'🟠 Cam',          num:3 },
  { name:'🔮 The High Priestess',meaning:'Lắng nghe trực giác bên trong, đừng vội kết luận.',       lucky:'💜 Tím',          num:9 },
  { name:'🏆 The World',        meaning:'Hoàn thành, thành tựu và kết thúc một chu kỳ tốt đẹp.',   lucky:'🌈 Cầu vồng',     num:6 },
  { name:'💀 Death',            meaning:'Không phải cái chết literal — mà là chuyển hoá, buông bỏ.',lucky:'⚫ Đen',          num:5 },
  { name:'😈 The Devil',        meaning:'Cẩn thận với cám dỗ và những thói quen xấu hôm nay.',     lucky:'🔴 Đỏ thẫm',     num:6 },
  { name:'🌈 The Lovers',       meaning:'Tình cảm, lựa chọn từ trái tim và sự hòa hợp.',           lucky:'💗 Hồng',         num:6 },
  { name:'🎨 The Magician',     meaning:'Bạn có đủ khả năng biến ý tưởng thành hiện thực!',        lucky:'🟡 Vàng nhạt',    num:1 },
  { name:'⭐ The Star (Reversed)',meaning:'Mất phương hướng tạm thời — hãy nghỉ ngơi và nạp năng lượng.',lucky:'🔵 Xanh nhạt',num:2 },
  { name:'🚂 The Chariot',      meaning:'Quyết tâm và kiểm soát — tiến về phía trước không ngừng!',lucky:'💙 Xanh đậm',     num:7 },
  { name:'🏠 The Emperor',      meaning:'Quyền lực, kỷ luật và ổn định trong công việc.',          lucky:'🔴 Đỏ cam',       num:4 },
  { name:'🌿 The Hermit',       meaning:'Hãy dành thời gian một mình để tìm lại bản thân.',        lucky:'🤍 Trắng ngà',    num:3 },
  { name:'🎡 Wheel of Fortune', meaning:'Vận may đang quay — chuẩn bị đón nhận cơ hội!',           lucky:'💛 Vàng tươi',    num:8 },
  { name:'💧 The Hanged Man',   meaning:'Hãy nhìn vấn đề từ góc độ khác, đừng vội hành động.',    lucky:'🩵 Xanh băng',    num:5 },
  { name:'🌺 The Empress',      meaning:'Sáng tạo, phong phú và tình yêu thiên nhiên bao quanh.',  lucky:'🌸 Hồng phấn',    num:9 },
  { name:'🎺 Judgement',        meaning:'Thức tỉnh và cơ hội được làm lại từ đầu.',                lucky:'🌟 Bạc',          num:0 },
  { name:'🏛️ The Hierophant',   meaning:'Truyền thống, giáo dục và lời khuyên từ người có kinh nghiệm.',lucky:'💛 Vàng kim',num:5 },
];

const COLORS = [0x7B2FBE, 0x4169E1, 0x1DB954, 0xFFD700, 0xFF4757, 0xFF8C00, 0x00CED1];
const ADVICE = [
  'Hôm nay là ngày tốt để thử điều mới! ✨',
  'Tin vào bản thân và tiếp tục tiến lên! 💪',
  'Đừng quên nghỉ ngơi và chăm sóc bản thân. 🌿',
  'Một cuộc trò chuyện quan trọng có thể thay đổi mọi thứ. 💬',
  'Hãy cẩn thận với quyết định tài chính hôm nay. 💰',
  'Năng lượng tích cực đang hướng về phía bạn! 🌈',
  'Lắng nghe trái tim, đừng chỉ nghe lý trí. 💖',
];

const tarotCooldowns = new Map();
// Auto-cleanup tarotCooldowns mỗi 10 phút để tránh memory leak
setInterval(() => tarotCooldowns.clear(), 600000);
const COOLDOWN_MS = 6 * 3600_000;

module.exports = {
  name: 'tarot',
  enabled: true,
  description: 'Rút bài tarot hàng ngày',
  category: 'Fun',
  aliases: ['card', 'rut', 'fortune'],
  usage: '!tarot',
  prefixSupport: true,
  data: new SlashCommandBuilder()
    .setName('tarot').setDescription('Bói bài tarot 🔮')
    .setDMPermission(false),
  cooldown: 3,
  async execute(interactionOrMessage, args, client) {
    const userId = interactionOrMessage.author.id;
    const now    = Date.now();
    const rem    = COOLDOWN_MS - (now - (tarotCooldowns.get(userId) || 0));
    if (rem > 0 && tarotCooldowns.has(userId)) {
      const hrs = Math.floor(rem / 3600000);
      const min = Math.floor((rem % 3600000) / 60000);
      return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(0xFF8C00)
        .setDescription(`🔮 Bài tarot cần **${hrs}h ${min}m** để "nạp năng lượng" trước khi rút lần nữa!`)
        .setFooter({ text: config.footer || 'Stela Network' })] });
    }

    tarotCooldowns.set(userId, now);

    // "Xáo bài" — seed bởi userId + thời gian thực
    const seed = now ^ [...userId].reduce((a,c) => a + c.charCodeAt(0), 0);
    const card = CARDS[Math.abs(seed) % CARDS.length];
    const advice = ADVICE[Math.abs(seed >> 4) % ADVICE.length];
    const color  = COLORS[Math.abs(seed >> 8) % COLORS.length];
    const luckyNum = (Math.abs(seed >> 12) % 99) + 1;

    // Thêm chút drama — loading
    const thinking = await interactionOrMessage.reply({ embeds: [new EmbedBuilder()
      .setColor(0x1a1a2e)
      .setDescription('🔮 *Đang xáo bài... Tập trung vào câu hỏi của bạn...*')
      .setFooter({ text: config.footer || 'Stela Network' })] });

    await new Promise(r => setTimeout(r, 1500));

    thinking.edit({ embeds: [new EmbedBuilder()
      .setColor(color)
      .setTitle(`🔮 Lá bài của ${interactionOrMessage.author.username}`)
      .setDescription(`\n✨ **${card.name}** ✨\n\n*${card.meaning}*\n`)
      .addFields(
        { name: '🌟 Lời khuyên hôm nay', value: advice,         inline: false },
        { name: '🎨 Màu may mắn',         value: card.lucky,    inline: true  },
        { name: '🔢 Con số may mắn',      value: `**${luckyNum}**`, inline: true },
      )
      .setThumbnail(`https://www.tarot.com/images/cards/major/${String(card.num).padStart(2,'0')}.jpg`)
      .setFooter({ text: `${config.footer} • Rút lại sau 6 giờ` })
      .setTimestamp()] });
  }
};
