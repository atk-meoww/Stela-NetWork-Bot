'use strict';
const { EmbedBuilder, SlashCommandBuilder } = require('discord.js');
const config = require('../../config.json');

module.exports = {
  name: 'reverse',
  enabled: true,
  description: 'Đảo ngược text',
  category: 'Fun',
  aliases: ['rev', 'daonguoc'],
  usage: '!reverse <text>',
  cooldown: 3,
  prefixSupport: true,
  data: new SlashCommandBuilder().setName('reverse').setDescription('Đảo ngược chuỗi text')
    .addStringOption(o => o.setName('text').setDescription('Text cần đảo').setRequired(true).setMaxLength(500))
    .setDMPermission(false),
  async execute(interactionOrMessage, args) {
    const isSlash = !!interactionOrMessage.isChatInputCommand?.();
    const text = isSlash ? interactionOrMessage.options.getString('text') : args?.join(' ');
    if (!text) return isSlash ? interactionOrMessage.reply({ content: '❌ Nhập text!', ephemeral: true }) : interactionOrMessage.reply('❌ Nhập text!');
    const reversed = [...text].reverse().join('');
    const embed = new EmbedBuilder().setColor(config.colors?.primary || '#7B2FBE').setTitle('🔄 Text đảo ngược')
      .addFields({ name: '📝 Gốc', value: text.slice(0,500) }, { name: '🔁 Đảo ngược', value: reversed.slice(0,500) })
      .setFooter({ text: config.footer || 'Stela Network' });
    return isSlash ? interactionOrMessage.reply({ embeds: [embed] }) : interactionOrMessage.reply({ embeds: [embed] });
  }
};
