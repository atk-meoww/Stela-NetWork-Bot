'use strict';
const { EmbedBuilder, SlashCommandBuilder } = require('discord.js');
const config = require('../../config.json');

module.exports = {
  name: 'flip',
  enabled: true,
  description: 'Tung đồng xu',
  category: 'Fun',
  aliases: ['coin', 'toss'],
  usage: '!flip',
  cooldown: 3,
  prefixSupport: true,
  data: new SlashCommandBuilder().setName('flip').setDescription('Tung đồng xu — Sấp hay Ngửa?').setDMPermission(false),
  async execute(interactionOrMessage) {
    const isSlash = !!interactionOrMessage.isChatInputCommand?.();
    const result = Math.random() < 0.5 ? '🪙 Ngửa' : '🔮 Sấp';
    const embed = new EmbedBuilder()
      .setColor(config.colors?.gold || '#FFD700')
      .setTitle('🪙 Tung đồng xu').setDescription(`Kết quả: **${result}**!`)
      .setFooter({ text: config.footer || 'Stela Network' });
    return isSlash ? interactionOrMessage.reply({ embeds: [embed] }) : interactionOrMessage.reply({ embeds: [embed] });
  }
};
