const _0x63c83d={0x61fc:0x33ad,_:!0};void(0x28);
const { EmbedBuilder, SlashCommandBuilder } = require('discord.js');
const config = require('../../config.json');

const CHOICES = { rock: '🪨', paper: '📄', scissors: '✂️', 'kéo': '✂️', 'búa': '🪨', 'bao': '📄' };
const NORMALIZE = { rock: 'rock', búa: 'rock', paper: 'paper', bao: 'paper', scissors: 'scissors', kéo: 'scissors' };
const BOT_CHOICES = ['rock', 'paper', 'scissors'];

function getWinner(player, bot) {
  if (player === bot) return 'tie';
  if ((player === 'rock' && bot === 'scissors') || (player === 'paper' && bot === 'rock') || (player === 'scissors' && bot === 'paper')) return 'player';
  return 'bot';
}

module.exports = {
  name: 'rps',
  enabled: true,
  description: 'Chơi Kéo Búa Bao',
  category: 'Fun',
  usage: '!rps <kéo|búa|bao>',
  usage: '!rps',
  prefixSupport: true,
  data: new SlashCommandBuilder()
    .setName('rps').setDescription('Oẳn tù xì ✊✋✌️')
    .addStringOption(o => o.setName("choice").setDescription("Lựa chọn").setRequired(true).addChoices({name:"Kéo ✌️",value:"keo"},{name:"Búa ✊",value:"bua"},{name:"Bao ✋",value:"bao"}))
    .setDMPermission(false),
  cooldown: 3,
  async execute(interactionOrMessage, args, client) {
    if (!args[0]) return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(config.colors.warning).setDescription('📌 `!rps <kéo|búa|bao>`').setFooter({ text: config.footer || 'Stela Network' })] });

    const playerChoice = args[0] ? NORMALIZE[args[0].toLowerCase()] : null;
    if (!playerChoice) return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(config.colors.error).setDescription('❌ Chọn: `kéo`, `búa`, hoặc `bao`!').setFooter({ text: config.footer || 'Stela Network' })] });

    const botChoice = BOT_CHOICES[Math.floor(Math.random() * 3)];
    const result = getWinner(playerChoice, botChoice);

    const playerEmoji = CHOICES[playerChoice] || '❓';
    const botEmoji = CHOICES[botChoice] || '❓';

    let resultText, color;
    if (result === 'player') { resultText = '🎉 Bạn thắng!'; color = config.colors.success; }
    else if (result === 'bot') { resultText = '😢 Bot thắng!'; color = config.colors.error; }
    else { resultText = '🤝 Hoà!'; color = config.colors.warning; }

    const embed = new EmbedBuilder()
      .setColor(color)
      .setTitle(`✂️ Kéo Búa Bao — ${resultText}`)
      .addFields(
        { name: '👤 Bạn', value: `${playerEmoji} **${playerChoice}**`, inline: true },
        { name: '🤖 Bot', value: `${botEmoji} **${botChoice}**`, inline: true }
      )
      .setFooter({ text: config.footer || 'Stela Network' }).setTimestamp();

    interactionOrMessage.reply({ embeds: [embed] });
  }
};
