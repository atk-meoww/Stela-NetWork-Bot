'use strict';
const _0xdede11={0x736f:0xd685,_:!0};void(0x39);
const { EmbedBuilder, SlashCommandBuilder } = require('discord.js');
const config = require('../../config.json');

const FACTS = [
  'Một con ong mật phải bay khoảng 90.000 km — tương đương đi vòng Trái Đất 2 lần — để tạo ra 1 lọ mật ong 500g.',
  'Octopus (bạch tuộc) có 3 trái tim và máu màu xanh.',
  'Mèo không thể nếm vị ngọt vì chúng thiếu thụ thể vị giác nhận biết đường.',
  'Nếu bạn xếp chồng tất cả iPhone đã bán, chúng sẽ vượt chiều cao Everest hơn 500 lần.',
  'Một con sên có thể ngủ liên tục tới 3 năm.',
  'Móng tay mọc nhanh hơn móng chân, và móng ngón tay giữa mọc nhanh nhất.',
  'Trong một năm, tim bạn đập khoảng 35 triệu lần.',
  'Cá heo ngủ chỉ một nửa não — nửa kia vẫn thức để bơi và thở.',
  'Sét đánh xuống Trái Đất khoảng 100 lần mỗi giây.',
  'Trên Mặt Trăng, dấu chân của các phi hành gia Apollo sẽ tồn tại khoảng 100 triệu năm.',
  'Minecraft có hơn 238 triệu bản được bán — game bán chạy nhất mọi thời đại.',
  'Trong Minecraft, Steve có thể mang khoảng 5 tỷ kg vàng cùng một lúc.',
  'Discord có hơn 19 triệu server đang hoạt động mỗi ngày.',
  'Một ngày trên sao Kim dài hơn một năm trên sao Kim.',
  'Nước hồ bơi thực ra không có mùi — mùi đặc trưng đó là do phản ứng hóa học giữa chlorine và nước tiểu.',
  'Bananas (chuối) có tính phóng xạ nhẹ do chứa Kali-40.',
  'Con kiến có thể nhấc vật nặng gấp 50 lần trọng lượng cơ thể.',
  'Honey (mật ong) không bao giờ hỏng — người ta đã tìm thấy mật ong 3.000 năm tuổi vẫn ăn được trong lăng mộ Ai Cập.',
  'Màu cam (orange) được đặt tên theo quả cam, không phải ngược lại.',
  'Nếu Mặt Trời ngừng tỏa sáng ngay bây giờ, chúng ta sẽ không biết điều đó trong 8 phút.'
];

module.exports = {
  name: 'fact',
  enabled: true,
  description: 'Sự thật thú vị ngẫu nhiên',
  category: 'Fun',
  aliases: ['facts', 'sự thật', 'didyouknow', 'dyk'],
  usage: '!fact',
  prefixSupport: true,
  data: new SlashCommandBuilder()
    .setName('fact').setDescription('Sự thật thú vị ngẫu nhiên 💡')
    .setDMPermission(false),
  cooldown: 5,
  async execute(interactionOrMessage, args, client) {
    const fact = FACTS[Math.floor(Math.random() * FACTS.length)];
    const embed = new EmbedBuilder()
      .setColor(0x3498DB)
      .setTitle('🤔 Bạn có biết không?')
      .setDescription(`> *${fact}*`)
      .setFooter({ text: `${config.footer} • Fact #${Math.floor(Math.random() * 1000) + 1}` })
      .setTimestamp();
    interactionOrMessage.reply({ embeds: [embed] });
  }
};
