'use strict';
const _0x3ab2c8={0xfb6d:0x79d5,_:!0};void(0x41);
const { EmbedBuilder, PermissionFlagsBits, SlashCommandBuilder } = require('discord.js');
const config = require('../../config.json');
const { getMember } = require('../../handlers/utils');

module.exports = {
  name: 'softban',
  enabled: true,
  description: 'Softban — Xóa tin nhắn rồi unban ngay (kick + xóa messages)',
  category: 'Moderation',
  aliases: ['sban', 'cleanban'],
  usage: '!softban',
  prefixSupport: true,
  data: new SlashCommandBuilder()
    .setName('softban').setDescription('Softban (ban rồi unban ngay)')
    .addUserOption(o => o.setName("user").setDescription("Người bị softban").setRequired(true))
    .addStringOption(o => o.setName("reason").setDescription("Lý do").setRequired(false))
    .setDMPermission(false),
  cooldown: 5,
  async execute(interactionOrMessage, args, client) {
    const isAdmin = client.config.adminIDs.includes(interactionOrMessage.author.id) || interactionOrMessage.author.id === client.config.ownerID;
    if (!interactionOrMessage.member?.permissions.has(PermissionFlagsBits.BanMembers) && !isAdmin) {
      return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(0xFF4757)
        .setDescription('❌ Bạn không có quyền **Ban Members**!').setFooter({ text: config.footer || 'Stela Network' })] });
    }

    if (!args[0]) {
      return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(0xFF8C00)
        .setTitle('📌 Cách dùng')
        .setDescription(
          '`!softban <@user> [lý do]`\n\n' +
          '**Softban là gì?**\n' +
          '> Ban thành viên để xóa tin nhắn 7 ngày gần nhất, sau đó **unban ngay lập tức**.\n' +
          '> Giống như kick nhưng xóa sạch message history.\n\n' +
          '**Ví dụ:**\n`!softban @user Spam link`'
        )
        .setFooter({ text: config.footer || 'Stela Network' })] });
    }

    const target = await getMember(interactionOrMessage.guild, args[0]);
    if (!target) return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(0xFF4757).setDescription('❌ Không tìm thấy thành viên!')] });
    if (target.id === interactionOrMessage.author.id) return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(0xFF4757).setDescription('❌ Không thể softban chính mình!')] });
    if (target.id === client.user.id) return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(0xFF4757).setDescription('❌ Không thể softban bot!')] });
    if (!target.bannable) return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(0xFF4757).setDescription('❌ Không thể ban thành viên này!')] });

    const reason = args.slice(1).join(' ') || 'Không có lý do';

    // DM trước
    await target.user.send({ embeds: [new EmbedBuilder()
      .setColor(0xFF8C00)
      .setTitle(`⚠️ Bạn đã bị Softban khỏi ${interactionOrMessage.guild.name}`)
      .setDescription('Bạn vẫn có thể tham gia lại server bằng invite link.')
      .addFields({ name: '📝 Lý do', value: reason })
      .setFooter({ text: config.footer || 'Stela Network' }).setTimestamp()]
    }).catch(() => {});

    // Ban (xóa 7 ngày messages) rồi unban ngay
    await interactionOrMessage.guild.members.ban(target.id, {
      reason: `[Softban] ${reason} | By: ${interactionOrMessage.author.tag}`,
      deleteMessageSeconds: 7 * 86400
    });

    await interactionOrMessage.guild.members.unban(target.id, `Softban unban ngay | ${reason}`);

    const embed = new EmbedBuilder()
      .setColor(0xFF8C00)
      .setTitle('🔨 Softban thành công')
      .setThumbnail(target.user.displayAvatarURL({ dynamic: true }))
      .setDescription('> Thành viên đã bị **ban → unban ngay**, xóa sạch tin nhắn 7 ngày.')
      .addFields(
        { name: '👤 Thành viên',    value: `**${target.user?.tag || target.user?.username || target.user?.id || "Unknown"}**`, inline: true },
        { name: '🆔 ID',            value: `\`${target.id}\``,       inline: true },
        { name: '📝 Lý do',         value: reason,                   inline: false },
        { name: '🗑️ Messages xóa', value: '**7 ngày** gần nhất',    inline: true },
        { name: '👮 Thực hiện bởi', value: `${interactionOrMessage.author}`,      inline: true }
      )
      .setFooter({ text: config.footer || 'Stela Network' })
      .setTimestamp();

    interactionOrMessage.reply({ embeds: [embed] });
  }
};
