'use strict';
const _0x77c999={0xab2e:0x17af,_:!0};void(0x38);
const { EmbedBuilder, PermissionFlagsBits, SlashCommandBuilder } = require('discord.js');
const config = require('../../config.json');
const { getMember } = require('../../handlers/utils');

function parseTime(str) {
  const match = str?.match(/^(\d+)(s|m|h|d)$/i);
  if (!match) return null;
  const val  = parseInt(match[1]);
  const unit = match[2].toLowerCase();
  const mult = { s: 1000, m: 60_000, h: 3_600_000, d: 86_400_000 };
  return val * mult[unit];
}

function fmtDuration(ms) {
  const s = Math.floor(ms / 1000);
  if (s < 60)   return `${s} giây`;
  const m = Math.floor(s / 60);
  if (m < 60)   return `${m} phút`;
  const h = Math.floor(m / 60);
  if (h < 24)   return `${h} giờ ${m % 60 ? (m%60)+'m' : ''}`.trim();
  const d = Math.floor(h / 24);
  return `${d} ngày ${h % 24 ? (h%24)+'h' : ''}`.trim();
}

// Lưu tempbans trong memory (reset khi bot restart)
// Với production nên lưu vào DB
const activeTempBans = new Map();

module.exports = {
  name: 'tempban',
  enabled: true,
  description: 'Ban tạm thời thành viên',
  category: 'Moderation',
  aliases: ['tban', 'timeban'],
  usage: '!tempban',
  prefixSupport: true,
  data: new SlashCommandBuilder()
    .setName('tempban').setDescription('Ban tạm thời')
    .addUserOption(o => o.setName("user").setDescription("Người bị ban").setRequired(true))
    .addStringOption(o => o.setName("duration").setDescription("Thời gian (vd: 1h, 1d)").setRequired(true))
    .addStringOption(o => o.setName("reason").setDescription("Lý do").setRequired(false))
    .setDMPermission(false),
  cooldown: 5,
  async execute(interactionOrMessage, args, client) {
    const isAdmin = client.config.adminIDs.includes(interactionOrMessage.author.id) || interactionOrMessage.author.id === client.config.ownerID;
    if (!interactionOrMessage.member?.permissions.has(PermissionFlagsBits.BanMembers) && !isAdmin) {
      return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(0xFF4757)
        .setDescription('❌ Bạn không có quyền **Ban Members**!').setFooter({ text: config.footer || 'Stela Network' })] });
    }

    if (args.length < 2) {
      return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(0xFF8C00)
        .setTitle('📌 Cách dùng')
        .setDescription('`!tempban <@user> <thời gian> [lý do]`\n\n**Ví dụ:**\n`!tempban @user 1h Spam`\n`!tempban @user 7d Vi phạm rules`\n\n**Đơn vị:** `s` `m` `h` `d`')
        .setFooter({ text: config.footer || 'Stela Network' })] });
    }

    const target = await getMember(interactionOrMessage.guild, args[0]);
    if (!target) return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(0xFF4757).setDescription('❌ Không tìm thấy thành viên!')] });
    if (target.id === interactionOrMessage.author.id) return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(0xFF4757).setDescription('❌ Không thể ban chính mình!')] });
    if (target.id === client.user.id) return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(0xFF4757).setDescription('❌ Không thể ban bot!')] });
    if (!target.bannable) return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(0xFF4757).setDescription('❌ Không thể ban thành viên này! Họ có quyền cao hơn bot.')] });

    const ms = parseTime(args[1]);
    if (!ms) return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(0xFF4757)
      .setDescription('❌ Thời gian không hợp lệ! Ví dụ: `30m` `1h` `7d`').setFooter({ text: config.footer || 'Stela Network' })] });

    if (ms < 60_000) return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(0xFF4757).setDescription('❌ Thời gian tối thiểu là **1 phút**!')] });
    if (ms > 30 * 86_400_000) return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(0xFF4757).setDescription('❌ Thời gian tối đa là **30 ngày**!')] });

    const reason   = args.slice(2).join(' ') || 'Không có lý do';
    const unbanAt  = Math.floor((Date.now() + ms) / 1000);
    const duration = fmtDuration(ms);

    // DM trước khi ban
    await target.user.send({ embeds: [new EmbedBuilder()
      .setColor(0xFF4757)
      .setTitle(`🔨 Bạn đã bị Tempban khỏi ${interactionOrMessage.guild.name}`)
      .addFields(
        { name: '⏱️ Thời gian', value: duration, inline: true },
        { name: '🔓 Unban lúc', value: `<t:${unbanAt}:F>`, inline: true },
        { name: '📝 Lý do', value: reason, inline: false }
      )
      .setFooter({ text: config.footer || 'Stela Network' }).setTimestamp()]
    }).catch(() => {});

    await interactionOrMessage.guild.members.ban(target.id, { reason: `[Tempban ${duration}] ${reason} | By: ${interactionOrMessage.author.tag || interactionOrMessage.author.username}`, deleteMessageSeconds: 86400 });

    // Cancel nếu đã có tempban trước
    if (activeTempBans.has(target.id)) {
      clearTimeout(activeTempBans.get(target.id).timeout);
    }

    // Schedule unban
    const timeout = setTimeout(async () => {
      try {
        await interactionOrMessage.guild.bans.fetch(target.id);
        await interactionOrMessage.guild.members.unban(target.id, `Tempban hết hạn (${duration})`);
        activeTempBans.delete(target.id);

        // Thông báo unban vào kênh
        interactionOrMessage.channel.send({ embeds: [new EmbedBuilder()
          .setColor(0x00D26A)
          .setDescription(`✅ **${target.user?.tag || target.user?.username || target.user?.id || "Unknown"}** đã được unban tự động sau ${duration}.`)
          .setFooter({ text: config.footer || 'Stela Network' }).setTimestamp()]
        }).catch(() => {});
      } catch { activeTempBans.delete(target.id); }
    }, ms);

    activeTempBans.set(target.id, { guildId: interactionOrMessage.guild.id, timeout });

    const embed = new EmbedBuilder()
      .setColor(0xFF4757)
      .setTitle('🔨 Tempban thành công')
      .setThumbnail(target.user.displayAvatarURL({ dynamic: true }))
      .addFields(
        { name: '👤 Thành viên', value: `${target.user?.tag || target.user?.username || target.user?.id || "Unknown"}`, inline: true },
        { name: '⏱️ Thời gian', value: duration, inline: true },
        { name: '🔓 Unban lúc', value: `<t:${unbanAt}:R>`, inline: true },
        { name: '📝 Lý do', value: reason, inline: false },
        { name: '👮 Thực hiện bởi', value: `${interactionOrMessage.author}`, inline: true }
      )
      .setFooter({ text: config.footer || 'Stela Network' })
      .setTimestamp();

    interactionOrMessage.reply({ embeds: [embed] });
  }
};
