'use strict';
const { EmbedBuilder, SlashCommandBuilder, PermissionFlagsBits, MessageFlags } = require('discord.js');
const config = require('../../config.json');
const { isAdmin } = require('../../handlers/utils');

module.exports = {
  name: 'clear',
  enabled: true,
  description: 'Xóa tin nhắn (1-500, hỗ trợ bulk nhiều lần)',
  category: 'Moderation',
  aliases: ['clean'],
  usage: '!clear <1-500>',
  cooldown: 5,
  prefixSupport: true,
  data: new SlashCommandBuilder()
    .setName('clear').setDescription('Xóa tin nhắn hàng loạt (1-100 mỗi lần)')
    .addIntegerOption(o => o.setName('amount').setDescription('Số tin nhắn cần xóa (1-100)').setRequired(true).setMinValue(1).setMaxValue(100))
    .addUserOption(o => o.setName('user').setDescription('Chỉ xóa tin nhắn của user này').setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
    .setDMPermission(false),

  async execute(interactionOrMessage, args, client) {
    const isSlash = !!interactionOrMessage.isChatInputCommand?.();
    const author  = isSlash ? interactionOrMessage.user : interactionOrMessage.author;
    const channel = interactionOrMessage.channel;

    const err = (txt) => {
      const e = new EmbedBuilder().setColor(config.colors?.error || '#FF4757').setDescription(txt).setFooter({ text: config.footer || 'Stela Network' });
      return isSlash ? interactionOrMessage.reply({ embeds: [e], flags: MessageFlags.Ephemeral }) : interactionOrMessage.reply({ embeds: [e] });
    };

    if (!isSlash && !isAdmin(author.id) && !interactionOrMessage.member?.permissions.has(PermissionFlagsBits.ManageMessages))
      return err('❌ Bạn không có quyền **Manage Messages**!');

    if (isSlash) await interactionOrMessage.deferReply({ flags: MessageFlags.Ephemeral });

    let amount, filterUser;
    if (isSlash) {
      amount     = interactionOrMessage.options.getInteger('amount');
      filterUser = interactionOrMessage.options.getUser('user');
    } else {
      amount = parseInt(args?.[0]);
      if (!amount || isNaN(amount) || amount < 1 || amount > 500)
        return err('❌ Số lượng phải từ 1-500! `!clear <số>`');
      filterUser = interactionOrMessage.mentions.users.first() || null;
      await interactionOrMessage.delete().catch(() => {});
    }

    try {
      let deleted = 0;
      let remaining = amount;
      while (remaining > 0) {
        const toDelete = Math.min(remaining, 100);
        let msgs = await channel.messages.fetch({ limit: toDelete + (filterUser ? 10 : 0) });
        const twoWeeks = Date.now() - 1_209_600_000;
        msgs = msgs.filter(m => m.createdTimestamp > twoWeeks);
        if (filterUser) msgs = msgs.filter(m => m.author.id === filterUser.id);
        const batch = [...msgs.values()].slice(0, toDelete);
        if (!batch.length) break;
        const result = await channel.bulkDelete(batch, true);
        deleted += result.size;
        remaining -= result.size;
        if (result.size < toDelete || result.size === 0) break;
        if (remaining > 0) await new Promise(r => setTimeout(r, 1200));
      }

      const embed = new EmbedBuilder().setColor(config.colors?.success || '#00D26A')
        .setDescription(`🗑️ Đã xóa **${deleted}** tin nhắn${filterUser ? ` của ${filterUser.tag || filterUser.username}` : ''}!`)
        .setFooter({ text: config.footer || 'Stela Network' });

      if (isSlash) {
        await interactionOrMessage.editReply({ embeds: [embed] });
      } else {
        const msg = await channel.send({ embeds: [embed] });
        setTimeout(() => msg.delete().catch(() => {}), 4000);
      }
    } catch (e) {
      const msg = `❌ Lỗi: ${e.message}`;
      if (isSlash) await interactionOrMessage.editReply({ content: msg });
      else await channel.send({ embeds: [new EmbedBuilder().setColor(config.colors?.error || '#FF4757').setDescription(msg)] });
    }
  }
};
