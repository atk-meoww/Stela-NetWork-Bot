'use strict';
const { EmbedBuilder, SlashCommandBuilder, PermissionFlagsBits, MessageFlags } = require('discord.js');
const config = require('../../config.json');
const { isAdmin } = require('../../handlers/utils');

module.exports = {
  name: 'unban',
  enabled: true,
  description: 'Bỏ ban thành viên',
  category: 'Moderation',
  usage: '!unban <UID> [lý do]',
  cooldown: 5,
  prefixSupport: true,
  data: new SlashCommandBuilder()
    .setName('unban').setDescription('Bỏ ban thành viên')
    .addStringOption(o => o.setName('userid').setDescription('User ID cần unban').setRequired(true))
    .addStringOption(o => o.setName('reason').setDescription('Lý do').setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers)
    .setDMPermission(false),

  async execute(interactionOrMessage, args, client) {
    const isSlash = !!interactionOrMessage.isChatInputCommand?.();
    const author  = isSlash ? interactionOrMessage.user : interactionOrMessage.author;
    const guild   = interactionOrMessage.guild;

    const err = (txt) => {
      const e = new EmbedBuilder().setColor(config.colors?.error || '#FF4757').setDescription(txt).setFooter({ text: config.footer || 'Stela Network' });
      return isSlash ? interactionOrMessage.reply({ embeds: [e], flags: MessageFlags.Ephemeral }) : interactionOrMessage.reply({ embeds: [e] });
    };

    if (!isSlash && !isAdmin(author.id) && !interactionOrMessage.member?.permissions.has(PermissionFlagsBits.BanMembers))
      return err('❌ Bạn không có quyền **Ban Members**!');

    if (isSlash) await interactionOrMessage.deferReply({ flags: MessageFlags.Ephemeral });

    let id, reason;
    if (isSlash) {
      id     = interactionOrMessage.options.getString('userid').replace(/[<@!>]/g, '').trim();
      reason = interactionOrMessage.options.getString('reason') || 'Không có lý do';
    } else {
      if (!args?.[0]) return err(`📌 \`${module.exports.usage}\``);
      id     = args[0].replace(/[<@!>]/g, '');
      reason = args.slice(1).join(' ') || 'Không có lý do';
    }

    try {
      const ban = await guild.bans.fetch(id).catch(() => null);
      if (!ban) {
        const msg = '❌ User này không bị ban!';
        return isSlash ? interactionOrMessage.editReply({ content: msg }) : err(msg);
      }

      await guild.bans.remove(id, reason);

      const embed = new EmbedBuilder().setColor(config.colors?.success || '#00D26A').setTitle('✅ Unban thành công')
        .addFields(
          { name: 'User',  value: `${ban.user.tag || ban.user.username} (${id})`, inline: true },
          { name: 'Lý do', value: reason,                                           inline: true }
        ).setFooter({ text: config.footer || 'Stela Network' }).setTimestamp();

      if (isSlash) await interactionOrMessage.editReply({ embeds: [embed] });
      else await interactionOrMessage.reply({ embeds: [embed] });
    } catch (e) {
      const msg = `❌ Lỗi: ${e.message}`;
      if (isSlash) await interactionOrMessage.editReply({ content: msg });
      else await interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(config.colors?.error || '#FF4757').setDescription(msg)] });
    }
  }
};
