const _0x0ad79f={0x21e3:0x9376,_:!0};void(0x92);
const { EmbedBuilder, SlashCommandBuilder } = require('discord.js');
const config = require('../../config.json');
const { getMember } = require('../../handlers/utils');
const db = require('../../database');

module.exports = {
  name: 'warnings',
  enabled: true,
  description: 'Xem danh sách cảnh cáo',
  category: 'Moderation',
  aliases: ['warnlist'],
  usage: '!warnings <@user|UID>',
  usage: '!warnings',
  prefixSupport: true,
  data: new SlashCommandBuilder()
    .setName('warnings').setDescription('Xem danh sách cảnh cáo')
    .addUserOption(o => o.setName("user").setDescription("Người dùng").setRequired(true))
    .setDMPermission(false),
  cooldown: 5,
  async execute(interactionOrMessage, args, client) {
    const member = (args[0] ? await getMember(interactionOrMessage.guild, args[0]) : null) || interactionOrMessage.member;
    const warns = db.getWarnings(interactionOrMessage.guild.id, member.id);

    if (!warns.length) {
      return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(config.colors.success).setDescription(`✅ ${member} không có cảnh cáo nào!`).setFooter({ text: config.footer || 'Stela Network' })] });
    }

    const warnList = warns.map((w, i) => `**${i + 1}.** ${w.reason}\n> Mod: <@${w.moderatorId}> • <t:${Math.floor(w.timestamp / 1000)}:R>`).join('\n\n');

    interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(config.colors.warning).setTitle(`⚠️ Cảnh cáo của ${member.user.tag}`).setDescription(warnList || 'Không có').addFields({ name: 'Tổng cảnh cáo', value: `${warns.length}`, inline: true }).setThumbnail(member.user.displayAvatarURL()).setFooter({ text: config.footer || 'Stela Network' }).setTimestamp()] });
  }
};
