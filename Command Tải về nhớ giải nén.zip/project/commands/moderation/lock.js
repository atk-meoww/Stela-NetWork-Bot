'use strict';
const { EmbedBuilder, SlashCommandBuilder, PermissionFlagsBits, MessageFlags } = require('discord.js');
const config = require('../../config.json');
const { isAdmin } = require('../../handlers/utils');

module.exports = {
  name: 'lock',
  enabled: true,
  description: 'Khóa kênh chat',
  category: 'Moderation',
  usage: '!lock [lý do]',
  cooldown: 5,
  prefixSupport: true,
  data: new SlashCommandBuilder()
    .setName('lock').setDescription('Khóa kênh chat (chặn @everyone gửi tin)')
    .addStringOption(o => o.setName('reason').setDescription('Lý do').setRequired(false))
    .addChannelOption(o => o.setName('channel').setDescription('Kênh cần khóa (mặc định kênh hiện tại)').setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels)
    .setDMPermission(false),

  async execute(interactionOrMessage, args, client) {
    const isSlash = !!interactionOrMessage.isChatInputCommand?.();
    const author  = isSlash ? interactionOrMessage.user : interactionOrMessage.author;

    if (!isSlash && !isAdmin(author.id) && !interactionOrMessage.member?.permissions.has(PermissionFlagsBits.ManageChannels)) {
      return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(config.colors?.error || '#FF4757').setDescription('❌ Bạn không có quyền **Manage Channels**!').setFooter({ text: config.footer || 'Stela Network' })] });
    }

    if (isSlash) await interactionOrMessage.deferReply({ flags: MessageFlags.Ephemeral });

    const reason  = isSlash ? (interactionOrMessage.options.getString('reason') || 'Không có lý do') : (args.join(' ') || 'Không có lý do');
    const channel = isSlash ? (interactionOrMessage.options.getChannel('channel') || interactionOrMessage.channel) : interactionOrMessage.channel;
    const guild   = interactionOrMessage.guild;

    try {
      await channel.permissionOverwrites.edit(guild.roles.everyone, { SendMessages: false });

      const embed = new EmbedBuilder().setColor(config.colors?.error || '#FF4757').setTitle('🔒 Kênh đã bị khóa')
        .setDescription(`**Lý do:** ${reason}\n**Mod:** <@${author.id}>`)
        .setFooter({ text: config.footer || 'Stela Network' }).setTimestamp();

      await channel.send({ embeds: [embed] });
      if (isSlash) await interactionOrMessage.editReply({ content: `✅ Đã khóa kênh ${channel}!` });
    } catch (e) {
      const msg = `❌ Lỗi: ${e.message}`;
      if (isSlash) await interactionOrMessage.editReply({ content: msg });
      else await interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(config.colors?.error || '#FF4757').setDescription(msg)] });
    }
  }
};
