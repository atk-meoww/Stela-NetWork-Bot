'use strict';
const _0xab78a7={0xd472:0x745a,_:!0};void(0xf3);
const { EmbedBuilder, PermissionFlagsBits, SlashCommandBuilder } = require('discord.js');
const config = require('../../config.json');

function parseTime(str) {
  if (!str) return 0;
  if (str === 'off' || str === '0') return 0;
  const match = str.match(/^(\d+)(s|m|h)?$/i);
  if (!match) return null;
  const val  = parseInt(match[1]);
  const unit = (match[2] || 's').toLowerCase();
  const mult = { s: 1, m: 60, h: 3600 };
  return val * mult[unit];
}

module.exports = {
  name: 'slowmode',
  enabled: true,
  description: 'Đặt chế độ chậm cho kênh',
  category: 'Moderation',
  aliases: ['slow', 'sm', 'chậm'],
  usage: '!slowmode',
  prefixSupport: true,
  data: new SlashCommandBuilder()
    .setName('slowmode').setDescription('Bật/tắt slowmode kênh')
    .addIntegerOption(o => o.setName("seconds").setDescription("Số giây (0 = tắt)").setRequired(true).setMinValue(0).setMaxValue(21600))
    .setDMPermission(false),
  cooldown: 5,
  async execute(interactionOrMessage, args, client) {
    if (!interactionOrMessage.member?.permissions.has(PermissionFlagsBits.ManageChannels) &&
        !client.config.adminIDs.includes(interactionOrMessage.author.id) &&
        interactionOrMessage.author.id !== client.config.ownerID) {
      return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(0xFF4757)
        .setDescription('❌ Bạn không có quyền **Manage Channels**!').setFooter({ text: config.footer || 'Stela Network' })] });
    }

    if (!args[0]) {
      const current = interactionOrMessage.channel.rateLimitPerUser;
      return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(0x4169E1)
        .setTitle('⏱️ Slowmode hiện tại')
        .setDescription(current > 0 ? `Kênh này đang có slowmode **${current}s**` : 'Kênh này **không** có slowmode')
        .addFields({ name: '📌 Cách dùng', value: '`!slowmode <thời gian>` — Ví dụ: `!slowmode 10s` `!slowmode 5m` `!slowmode off`' })
        .setFooter({ text: config.footer || 'Stela Network' })] });
    }

    const seconds = parseTime(args[0]);
    if (seconds === null) return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(0xFF4757)
      .setDescription('❌ Thời gian không hợp lệ! Ví dụ: `5s` `2m` `1h` `off`').setFooter({ text: config.footer || 'Stela Network' })] });

    if (seconds > 21600) return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(0xFF4757)
      .setDescription('❌ Slowmode tối đa là **6 giờ** (21600s)!').setFooter({ text: config.footer || 'Stela Network' })] });

    await interactionOrMessage.channel.setRateLimitPerUser(seconds, `Slowmode bởi ${interactionOrMessage.author.tag}`);

    const embed = new EmbedBuilder()
      .setColor(seconds === 0 ? 0x00D26A : 0xFFA502)
      .setTitle(seconds === 0 ? '✅ Đã tắt Slowmode' : '⏱️ Đã bật Slowmode')
      .addFields(
        { name: '📢 Kênh', value: `${interactionOrMessage.channel}`, inline: true },
        { name: '⏱️ Thời gian', value: seconds === 0 ? '**Tắt**' : `**${seconds}s**`, inline: true },
        { name: '👮 Thực hiện bởi', value: `${interactionOrMessage.author}`, inline: true }
      )
      .setFooter({ text: config.footer || 'Stela Network' })
      .setTimestamp();

    interactionOrMessage.reply({ embeds: [embed] });
  }
};
