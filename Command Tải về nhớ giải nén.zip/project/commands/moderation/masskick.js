'use strict';
const { EmbedBuilder, SlashCommandBuilder, PermissionFlagsBits, MessageFlags } = require('discord.js');
const config = require('../../config.json');
const { isAdmin } = require('../../handlers/utils');

module.exports = {
  name: 'masskick',
  enabled: true,
  description: 'Kick nhiều user cùng lúc',
  category: 'Moderation',
  usage: '!masskick <@user1> <@user2> ... [lý do]',
  cooldown: 10,
  prefixSupport: true,
  data: new SlashCommandBuilder()
    .setName('masskick').setDescription('Kick nhiều user cùng lúc (tối đa 10)')
    .addStringOption(o => o.setName('userids').setDescription('Danh sách User ID cách nhau bởi dấu cách').setRequired(true))
    .addStringOption(o => o.setName('reason').setDescription('Lý do').setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers)
    .setDMPermission(false),

  async execute(interactionOrMessage, args, client) {
    const isSlash = !!interactionOrMessage.isChatInputCommand?.();
    const author  = isSlash ? interactionOrMessage.user : interactionOrMessage.author;
    const guild   = interactionOrMessage.guild;

    if (!isSlash && !isAdmin(author.id) && !interactionOrMessage.member?.permissions.has(PermissionFlagsBits.KickMembers))
      return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(config.colors?.error || '#FF4757').setDescription('❌ Thiếu quyền **Kick Members**!').setFooter({ text: config.footer || 'Stela Network' })] });

    if (isSlash) await interactionOrMessage.deferReply({ flags: MessageFlags.Ephemeral });

    let ids, reason;
    if (isSlash) {
      const rawIds = interactionOrMessage.options.getString('userids');
      ids    = rawIds.split(/\s+/).map(s => s.replace(/[<@!>]/g, '')).filter(Boolean).slice(0, 10);
      reason = interactionOrMessage.options.getString('reason') || 'Masskick';
    } else {
      ids    = interactionOrMessage.mentions.users.map(u => u.id).slice(0, 10);
      reason = args.filter(a => !/^<@!?\d+>$/.test(a)).join(' ') || 'Masskick';
    }

    if (!ids.length) {
      const msg = '❌ Tag ít nhất 1 người!';
      return isSlash ? interactionOrMessage.editReply({ content: msg }) : interactionOrMessage.reply(msg);
    }

    const results = { success: [], failed: [] };
    for (const id of ids) {
      try {
        const member = await guild.members.fetch(id).catch(() => null);
        if (!member || !member.kickable) { results.failed.push(id); continue; }
        await member.kick(reason);
        results.success.push(id);
      } catch { results.failed.push(id); }
    }

    const embed = new EmbedBuilder()
      .setColor(results.success.length ? (config.colors?.success || '#00D26A') : (config.colors?.error || '#FF4757'))
      .setTitle('👢 Masskick kết quả')
      .addFields(
        { name: `✅ Thành công (${results.success.length})`, value: results.success.length ? results.success.map(id => `<@${id}>`).join(', ') : 'Không có', inline: false },
        { name: `❌ Thất bại (${results.failed.length})`,   value: results.failed.length  ? results.failed.map(id => `<@${id}>`).join(', ')  : 'Không có', inline: false },
        { name: 'Lý do', value: reason, inline: true }
      ).setFooter({ text: config.footer || 'Stela Network' }).setTimestamp();

    if (isSlash) await interactionOrMessage.editReply({ embeds: [embed] });
    else await interactionOrMessage.reply({ embeds: [embed] });
  }
};
