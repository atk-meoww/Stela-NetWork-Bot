'use strict';
const { EmbedBuilder, SlashCommandBuilder, PermissionFlagsBits, MessageFlags } = require('discord.js');
const config = require('../../config.json');
const { isAdmin } = require('../../handlers/utils');

module.exports = {
  name: 'unlock',
  enabled: true,
  description: 'Mở khóa kênh chat',
  category: 'Moderation',
  usage: '!unlock',
  cooldown: 5,
  prefixSupport: true,
  data: new SlashCommandBuilder()
    .setName('unlock').setDescription('Mở khóa kênh chat')
    .addChannelOption(o => o.setName('channel').setDescription('Kênh cần mở khóa (mặc định kênh hiện tại)').setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels)
    .setDMPermission(false),

  async execute(interactionOrMessage, args, client) {
    const isSlash = !!interactionOrMessage.isChatInputCommand?.();
    const author  = isSlash ? interactionOrMessage.user : interactionOrMessage.author;

    if (!isSlash && !isAdmin(author.id) && !interactionOrMessage.member?.permissions.has(PermissionFlagsBits.ManageChannels)) {
      return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(config.colors?.error || '#FF4757').setDescription('❌ Bạn không có quyền **Manage Channels**!').setFooter({ text: config.footer || 'Stela Network' })] });
    }

    if (isSlash) await interactionOrMessage.deferReply({ flags: MessageFlags.Ephemeral });

    const channel = isSlash ? (interactionOrMessage.options.getChannel('channel') || interactionOrMessage.channel) : interactionOrMessage.channel;
    const guild   = interactionOrMessage.guild;

    try {
      await channel.permissionOverwrites.edit(guild.roles.everyone, { SendMessages: null });

      const embed = new EmbedBuilder().setColor(config.colors?.success || '#00D26A').setTitle('🔓 Kênh đã được mở khóa')
        .setDescription(`Mở bởi: <@${author.id}>`)
        .setFooter({ text: config.footer || 'Stela Network' }).setTimestamp();

      await channel.send({ embeds: [embed] });
      if (isSlash) await interactionOrMessage.editReply({ content: `✅ Đã mở khóa kênh ${channel}!` });
    } catch (e) {
      const msg = `❌ Lỗi: ${e.message}`;
      if (isSlash) await interactionOrMessage.editReply({ content: msg });
      else await interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(config.colors?.error || '#FF4757').setDescription(msg)] });
    }
  }
};
