'use strict';
const { EmbedBuilder, SlashCommandBuilder, PermissionFlagsBits, MessageFlags } = require('discord.js');
const config = require('../../config.json');
const { isAdmin, getMember } = require('../../handlers/utils');

function parseTime(str) {
  const m = str?.match(/^(\d+)(s|m|h|d)$/i);
  if (!m) return null;
  const u = { s: 1000, m: 60_000, h: 3_600_000, d: 86_400_000 };
  return parseInt(m[1]) * u[m[2].toLowerCase()];
}
function fmtDur(ms) {
  if (ms < 60000) return `${ms/1000}s`;
  if (ms < 3600000) return `${Math.floor(ms/60000)}m`;
  if (ms < 86400000) return `${Math.floor(ms/3600000)}h`;
  return `${Math.floor(ms/86400000)}d`;
}

module.exports = {
  name: 'mute',
  enabled: true,
  description: 'Timeout (mute) thành viên',
  category: 'Moderation',
  aliases: ['timeout', 'tm'],
  usage: '!mute <@user|UID> <thời gian> [lý do]',
  cooldown: 5,
  prefixSupport: true,
  data: new SlashCommandBuilder()
    .setName('mute').setDescription('Timeout (mute) thành viên')
    .addUserOption(o => o.setName('user').setDescription('Người bị mute').setRequired(true))
    .addStringOption(o => o.setName('duration').setDescription('Thời gian (vd: 10m, 1h, 1d)').setRequired(true))
    .addStringOption(o => o.setName('reason').setDescription('Lý do').setRequired(false).setMaxLength(500))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .setDMPermission(false),

  async execute(interactionOrMessage, args, client) {
    const isSlash = !!interactionOrMessage.isChatInputCommand?.();
    const author  = isSlash ? interactionOrMessage.user : interactionOrMessage.author;
    const guild   = interactionOrMessage.guild;

    const err = (txt) => {
      const e = new EmbedBuilder().setColor(config.colors?.error || '#FF4757').setDescription(txt).setFooter({ text: config.footer || 'Stela Network' });
      return isSlash ? interactionOrMessage.reply({ embeds: [e], flags: MessageFlags.Ephemeral }) : interactionOrMessage.reply({ embeds: [e] });
    };

    if (!isSlash && !isAdmin(author.id) && !interactionOrMessage.member?.permissions.has(PermissionFlagsBits.ModerateMembers))
      return err('❌ Bạn không có quyền **Moderate Members**!');

    if (isSlash) await interactionOrMessage.deferReply({ flags: MessageFlags.Ephemeral });

    let member, durationStr, reason;
    if (isSlash) {
      member      = interactionOrMessage.options.getMember('user');
      durationStr = interactionOrMessage.options.getString('duration');
      reason      = interactionOrMessage.options.getString('reason') || 'Không có lý do';
    } else {
      if (!args?.[0] || !args?.[1]) return err(`📌 \`${module.exports.usage}\``);
      member      = await getMember(guild, args[0]);
      durationStr = args[1];
      reason      = args.slice(2).join(' ') || 'Không có lý do';
    }

    if (!member) return isSlash ? interactionOrMessage.editReply({ content: '❌ Không tìm thấy user!' }) : err('❌ Không tìm thấy user!');
    const duration = parseTime(durationStr);
    if (!duration || duration > 2419200000) {
      const msg = '❌ Thời gian không hợp lệ! Tối đa 28 ngày. VD: `10m` `2h` `1d`';
      return isSlash ? interactionOrMessage.editReply({ content: msg }) : err(msg);
    }
    if (member.roles?.highest?.position >= (guild.members.me?.roles?.highest?.position || 0)) {
      const msg = '❌ Role người này cao hơn bot!';
      return isSlash ? interactionOrMessage.editReply({ content: msg }) : err(msg);
    }
    if (member.id === author.id) {
      const msg = '❌ Không mute chính mình!';
      return isSlash ? interactionOrMessage.editReply({ content: msg }) : err(msg);
    }

    try {
      await member.timeout(duration, reason);
      const untilUnix = Math.floor((Date.now() + duration) / 1000);

      await member.send({ embeds: [new EmbedBuilder().setColor(config.colors?.warning || '#FFA502').setTitle('🔇 Bạn đã bị Mute')
        .setDescription(`**Server:** ${guild.name}\n**Thời gian:** ${fmtDur(duration)}\n**Lý do:** ${reason}\n**Gỡ lúc:** <t:${untilUnix}:F>`).setFooter({ text: config.footer || 'Stela Network' })] }).catch(() => {});

      const embed = new EmbedBuilder().setColor(config.colors?.warning || '#FFA502').setTitle('🔇 Mute thành công')
        .addFields(
          { name: 'User',     value: `${member.user?.tag || member.user?.username}`, inline: true },
          { name: 'Thời gian',value: `${fmtDur(duration)} (đến <t:${untilUnix}:R>)`,inline: false },
          { name: 'Lý do',    value: reason,                                          inline: true }
        ).setFooter({ text: config.footer || 'Stela Network' }).setTimestamp();

      if (isSlash) await interactionOrMessage.editReply({ embeds: [embed] });
      else await interactionOrMessage.reply({ embeds: [embed] });
    } catch (e) {
      const msg = `❌ Lỗi khi mute: ${e.message}`;
      if (isSlash) await interactionOrMessage.editReply({ content: msg });
      else await interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(config.colors?.error || '#FF4757').setDescription(msg)] });
    }
  }
};
