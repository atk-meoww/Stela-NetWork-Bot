'use strict';
const { EmbedBuilder, SlashCommandBuilder, PermissionFlagsBits, MessageFlags } = require('discord.js');
const config = require('../../config.json');
const { isAdmin, getMember } = require('../../handlers/utils');

module.exports = {
  name: 'kick',
  enabled: true,
  description: 'Kick thành viên',
  category: 'Moderation',
  usage: '!kick <@user|UID> [lý do]',
  cooldown: 5,
  prefixSupport: true,
  data: new SlashCommandBuilder()
    .setName('kick').setDescription('Kick thành viên khỏi server')
    .addUserOption(o => o.setName('user').setDescription('Người bị kick').setRequired(true))
    .addStringOption(o => o.setName('reason').setDescription('Lý do').setRequired(false).setMaxLength(500))
    .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers)
    .setDMPermission(false),

  async execute(interactionOrMessage, args, client) {
    const isSlash  = !!interactionOrMessage.isChatInputCommand?.();
    const author   = isSlash ? interactionOrMessage.user   : interactionOrMessage.author;
    const guild    = interactionOrMessage.guild;

    const err = (txt) => {
      const e = new EmbedBuilder().setColor(config.colors?.error || '#FF4757').setDescription(txt).setFooter({ text: config.footer || 'Stela Network' });
      return isSlash ? interactionOrMessage.reply({ embeds: [e], flags: MessageFlags.Ephemeral }) : interactionOrMessage.reply({ embeds: [e] });
    };

    // Permission check (prefix)
    if (!isSlash && !isAdmin(author.id) && !interactionOrMessage.member?.permissions.has(PermissionFlagsBits.KickMembers))
      return err('❌ Bạn không có quyền **Kick Members**!');

    if (isSlash) await interactionOrMessage.deferReply({ flags: MessageFlags.Ephemeral });

    let member, reason;
    if (isSlash) {
      member = interactionOrMessage.options.getMember('user');
      reason = interactionOrMessage.options.getString('reason') || 'Không có lý do';
    } else {
      if (!args?.[0]) return err(`📌 \`${module.exports.usage}\``);
      member = await getMember(guild, args[0]);
      reason = args.slice(1).join(' ') || 'Không có lý do';
    }

    if (!member) return isSlash ? interactionOrMessage.editReply({ content: '❌ Không tìm thấy user!' }) : err('❌ Không tìm thấy user!');
    if (!guild.members.me?.permissions.has(PermissionFlagsBits.KickMembers)) return isSlash ? interactionOrMessage.editReply({ content: '❌ Bot thiếu quyền!' }) : err('❌ Bot thiếu quyền!');
    if (member.roles?.highest?.position >= (guild.members.me?.roles?.highest?.position || 0)) return isSlash ? interactionOrMessage.editReply({ content: '❌ Role người này cao hơn bot!' }) : err('❌ Role cao hơn bot!');
    if (member.id === author.id) return isSlash ? interactionOrMessage.editReply({ content: '❌ Không kick chính mình!' }) : err('❌ Không kick chính mình!');
    if (!member.kickable) return isSlash ? interactionOrMessage.editReply({ content: '❌ Không thể kick người này!' }) : err('❌ Không thể kick!');

    await member.send({ embeds: [new EmbedBuilder().setColor(config.colors?.warning || '#FFA502').setTitle('👢 Bạn đã bị Kick')
      .setDescription(`**Server:** ${guild.name}\n**Lý do:** ${reason}`).setFooter({ text: config.footer || 'Stela Network' })] }).catch(() => {});
    await member.kick(reason);

    const embed = new EmbedBuilder().setColor(config.colors?.success || '#00D26A').setTitle('👢 Kick thành công')
      .addFields({ name: 'User', value: `${member.user?.tag || member.user?.username}`, inline: true }, { name: 'Lý do', value: reason, inline: true })
      .setFooter({ text: config.footer || 'Stela Network' }).setTimestamp();

    if (isSlash) await interactionOrMessage.editReply({ embeds: [embed] });
    else await interactionOrMessage.reply({ embeds: [embed] });
  }
};
