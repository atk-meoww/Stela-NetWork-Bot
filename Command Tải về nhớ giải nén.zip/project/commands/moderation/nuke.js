const _0x99ec91={0xac6c:0x13de,_:!0};void(0x83);
const { EmbedBuilder, PermissionFlagsBits, SlashCommandBuilder } = require('discord.js');
const config = require('../../config.json');
const { isAdmin } = require('../../handlers/utils');

module.exports = {
  name: 'nuke',
  enabled: true,
  description: 'Clone kênh và xóa toàn bộ tin nhắn',
  category: 'Moderation',
  usage: '!nuke',
  prefixSupport: true,
  data: new SlashCommandBuilder()
    .setName('nuke').setDescription('Xóa và tạo lại kênh chat')
    .addStringOption(o => o.setName("reason").setDescription("Lý do").setRequired(false))
    .setDMPermission(false),
  cooldown: 10,
  async execute(interactionOrMessage, args, client) {
    if (!isAdmin(interactionOrMessage.author.id) && !interactionOrMessage.member?.permissions.has(PermissionFlagsBits.ManageChannels)) {
      return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(config.colors.error).setDescription('❌ Không có quyền!').setFooter({ text: config.footer || 'Stela Network' })] });
    }

    const channel = interactionOrMessage.channel;
    try {
      const position = channel.position;
      const newChannel = await channel.clone({ reason: `Nuke by ${interactionOrMessage.author.tag || interactionOrMessage.author.username}` });
      await newChannel.setPosition(position);
      await channel.delete();

      newChannel.send({ embeds: [new EmbedBuilder().setColor(config.colors.error).setTitle('💣 NUKE!').setDescription(`Kênh đã được nuke bởi **${interactionOrMessage.author.tag || interactionOrMessage.author.username}**\n\n*Toàn bộ tin nhắn đã bị xóa sạch.*`).setFooter({ text: config.footer || 'Stela Network' }).setTimestamp()] });
    } catch (e) {
      interactionOrMessage.channel.send({ embeds: [new EmbedBuilder().setColor(config.colors.error).setDescription(`❌ Lỗi: ${e.message}`).setFooter({ text: config.footer || 'Stela Network' })] }).catch(() => {});
    }
  }
};
