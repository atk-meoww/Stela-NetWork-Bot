'use strict';
const { EmbedBuilder, SlashCommandBuilder, PermissionFlagsBits, MessageFlags } = require('discord.js');
const config = require('../../config.json');
const { isAdmin } = require('../../handlers/utils');

module.exports = {
  name: 'massban',
  enabled: true,
  description: 'Ban nhiều user cùng lúc',
  category: 'Moderation',
  usage: '!massban <uid1> <uid2> ... [lý do]',
  cooldown: 10,
  prefixSupport: true,
  data: new SlashCommandBuilder()
    .setName('massban').setDescription('Ban nhiều user cùng lúc (tối đa 10)')
    .addStringOption(o => o.setName('userids').setDescription('Danh sách User ID cách nhau bởi dấu cách').setRequired(true))
    .addStringOption(o => o.setName('reason').setDescription('Lý do').setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers)
    .setDMPermission(false),

  async execute(interactionOrMessage, args, client) {
    const isSlash = !!interactionOrMessage.isChatInputCommand?.();
    const author  = isSlash ? interactionOrMessage.user : interactionOrMessage.author;
    const guild   = interactionOrMessage.guild;

    if (!isSlash && !isAdmin(author.id) && !interactionOrMessage.member?.permissions.has(PermissionFlagsBits.BanMembers))
      return interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(config.colors?.error || '#FF4757').setDescription('❌ Thiếu quyền **Ban Members**!').setFooter({ text: config.footer || 'Stela Network' })] });

    if (isSlash) await interactionOrMessage.deferReply({ flags: MessageFlags.Ephemeral });

    let ids, reason;
    if (isSlash) {
      const rawIds = interactionOrMessage.options.getString('userids');
      ids    = rawIds.split(/\s+/).map(s => s.replace(/[<@!>]/g, '')).filter(Boolean).slice(0, 10);
      reason = interactionOrMessage.options.getString('reason') || 'Massban';
    } else {
      if (!args?.length) {
        const e = new EmbedBuilder().setColor(config.colors?.warning || '#FFA502').setDescription(`📌 \`${module.exports.usage}\``).setFooter({ text: config.footer || 'Stela Network' });
        return interactionOrMessage.reply({ embeds: [e] });
      }
      ids    = args.filter(a => /^\d{15,20}$/.test(a.replace(/[<@!>]/g, ''))).map(a => a.replace(/[<@!>]/g, '')).slice(0, 10);
      reason = args.filter(a => !/^\d{15,20}$/.test(a.replace(/[<@!>]/g, ''))).join(' ') || 'Massban';
    }

    if (!ids.length) {
      const msg = '❌ Không tìm thấy User ID hợp lệ!';
      return isSlash ? interactionOrMessage.editReply({ content: msg }) : interactionOrMessage.reply(msg);
    }

    const results = { success: [], failed: [] };
    for (const id of ids) {
      try {
        await guild.members.ban(id, { reason, deleteMessageSeconds: 0 });
        results.success.push(id);
      } catch { results.failed.push(id); }
    }

    const embed = new EmbedBuilder()
      .setColor(results.success.length ? (config.colors?.success || '#00D26A') : (config.colors?.error || '#FF4757'))
      .setTitle('🚫 Massban kết quả')
      .addFields(
        { name: `✅ Thành công (${results.success.length})`, value: results.success.length ? results.success.map(id => `<@${id}>`).join(', ') : 'Không có', inline: false },
        { name: `❌ Thất bại (${results.failed.length})`,   value: results.failed.length  ? results.failed.join(', ')                            : 'Không có', inline: false },
        { name: 'Lý do', value: reason, inline: true }
      ).setFooter({ text: config.footer || 'Stela Network' }).setTimestamp();

    if (isSlash) await interactionOrMessage.editReply({ embeds: [embed] });
    else await interactionOrMessage.reply({ embeds: [embed] });
  }
};
