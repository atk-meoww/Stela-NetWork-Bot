'use strict';
const { EmbedBuilder, SlashCommandBuilder, PermissionFlagsBits, MessageFlags } = require('discord.js');
const config = require('../../config.json');
const { isAdmin } = require('../../handlers/utils');

module.exports = {
  name: 'purge',
  enabled: true,
  description: 'Xóa hàng loạt tin nhắn',
  category: 'Moderation',
  aliases: ['prune', 'xoa'],
  usage: '!purge <số lượng> [@user]',
  cooldown: 5,
  prefixSupport: true,
  data: new SlashCommandBuilder()
    .setName('purge').setDescription('Xóa hàng loạt tin nhắn trong kênh')
    .addIntegerOption(o => o.setName('amount').setDescription('Số tin nhắn cần xóa (1-100)').setRequired(true).setMinValue(1).setMaxValue(100))
    .addUserOption(o => o.setName('user').setDescription('Chỉ xóa tin nhắn của user này (tùy chọn)').setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
    .setDMPermission(false),

  async execute(interactionOrMessage, args, client) {
    const isSlash   = !!interactionOrMessage.isChatInputCommand?.();
    const author    = isSlash ? interactionOrMessage.user : interactionOrMessage.author;
    const channel   = interactionOrMessage.channel;

    const err = (txt) => {
      const e = new EmbedBuilder().setColor(config.colors?.error || '#FF4757').setDescription(txt).setFooter({ text: config.footer || 'Stela Network' });
      return isSlash ? interactionOrMessage.reply({ embeds: [e], flags: MessageFlags.Ephemeral }) : interactionOrMessage.reply({ embeds: [e] });
    };

    if (!isSlash && !isAdmin(author.id) && !interactionOrMessage.member?.permissions.has(PermissionFlagsBits.ManageMessages))
      return err('❌ Bạn không có quyền **Manage Messages**!');

    if (isSlash) await interactionOrMessage.deferReply({ flags: MessageFlags.Ephemeral });

    let amount, filterUser;
    if (isSlash) {
      amount     = interactionOrMessage.options.getInteger('amount');
      filterUser = interactionOrMessage.options.getUser('user');
    } else {
      amount = parseInt(args?.[0]);
      if (isNaN(amount) || amount < 1 || amount > 100) return err('❌ Số lượng phải từ 1-100!');
      filterUser = interactionOrMessage.mentions.users.first() || null;
    }

    try {
      // Lấy tối đa 100 tin, lọc tin < 14 ngày (bulkDelete giới hạn)
      let messages = await channel.messages.fetch({ limit: Math.min(amount + 5, 100) });
      const twoWeeksAgo = Date.now() - 1_209_600_000;
      messages = messages.filter(m => m.createdTimestamp > twoWeeksAgo);
      if (filterUser) messages = messages.filter(m => m.author.id === filterUser.id);
      const toDelete = [...messages.values()].slice(0, amount);

      if (!toDelete.length) {
        const msg = '❌ Không tìm thấy tin nhắn nào có thể xóa! (Tin > 14 ngày không thể bulk delete)';
        return isSlash ? interactionOrMessage.editReply({ content: msg }) : err(msg);
      }

      // Xóa tin nhắn prefix trước
      if (!isSlash) await interactionOrMessage.delete().catch(() => {});

      const deleted = await channel.bulkDelete(toDelete, true);

      const embed = new EmbedBuilder()
        .setColor(config.colors?.success || '#00D26A')
        .setDescription(`🗑️ Đã xóa **${deleted.size}** tin nhắn${filterUser ? ` của ${filterUser.tag || filterUser.username}` : ''}!`)
        .setFooter({ text: config.footer || 'Stela Network' })
        .setTimestamp();

      if (isSlash) {
        await interactionOrMessage.editReply({ embeds: [embed] });
      } else {
        const reply = await channel.send({ embeds: [embed] });
        setTimeout(() => reply.delete().catch(() => {}), 5000);
      }
    } catch (e) {
      const msg = `❌ Lỗi khi xóa: ${e.message}`;
      if (isSlash) await interactionOrMessage.editReply({ content: msg });
      else await channel.send({ embeds: [new EmbedBuilder().setColor(config.colors?.error || '#FF4757').setDescription(msg)] });
    }
  }
};
