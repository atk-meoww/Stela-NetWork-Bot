'use strict';
const { EmbedBuilder, SlashCommandBuilder, PermissionFlagsBits, MessageFlags } = require('discord.js');
const config = require('../../config.json');
const { isAdmin, getMember } = require('../../handlers/utils');

module.exports = {
  name: 'ban',
  enabled: true,
  description: 'Ban thành viên',
  category: 'Moderation',
  usage: '!ban <@user|UID> [lý do]',
  cooldown: 5,
  prefixSupport: true,
  data: new SlashCommandBuilder()
    .setName('ban').setDescription('Ban thành viên khỏi server')
    .addUserOption(o => o.setName('user').setDescription('Người bị ban').setRequired(true))
    .addStringOption(o => o.setName('reason').setDescription('Lý do').setRequired(false).setMaxLength(500))
    .addIntegerOption(o => o.setName('days').setDescription('Xóa tin nhắn bao nhiêu ngày (0-7)').setMinValue(0).setMaxValue(7).setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers)
    .setDMPermission(false),

  async execute(interactionOrMessage, args, client) {
    const isSlash = !!interactionOrMessage.isChatInputCommand?.();
    const author  = isSlash ? interactionOrMessage.user : interactionOrMessage.author;
    const guild   = interactionOrMessage.guild;

    const err = (txt) => {
      const e = new EmbedBuilder().setColor(config.colors?.error || '#FF4757').setDescription(txt).setFooter({ text: config.footer || 'Stela Network' });
      return isSlash ? interactionOrMessage.reply({ embeds: [e], flags: MessageFlags.Ephemeral }) : interactionOrMessage.reply({ embeds: [e] });
    };

    if (!isSlash && !isAdmin(author.id) && !interactionOrMessage.member?.permissions.has(PermissionFlagsBits.BanMembers))
      return err('❌ Bạn không có quyền **Ban Members**!');

    if (isSlash) await interactionOrMessage.deferReply({ flags: MessageFlags.Ephemeral });

    let member, reason, delDays = 0;
    if (isSlash) {
      member  = interactionOrMessage.options.getMember('user');
      reason  = interactionOrMessage.options.getString('reason') || 'Không có lý do';
      delDays = interactionOrMessage.options.getInteger('days') ?? 0;
    } else {
      if (!args?.[0]) return err(`📌 \`${module.exports.usage}\``);
      member = await getMember(guild, args[0]);
      reason = args.slice(1).join(' ') || 'Không có lý do';
    }

    const user = member?.user || (isSlash ? interactionOrMessage.options.getUser('user') : null);
    if (!user) return isSlash ? interactionOrMessage.editReply({ content: '❌ Không tìm thấy user!' }) : err('❌ Không tìm thấy user!');
    if (user.id === author.id) return isSlash ? interactionOrMessage.editReply({ content: '❌ Không ban chính mình!' }) : err('❌ Không ban chính mình!');
    if (!guild.members.me?.permissions.has(PermissionFlagsBits.BanMembers)) return isSlash ? interactionOrMessage.editReply({ content: '❌ Bot thiếu quyền ban!' }) : err('❌ Bot thiếu quyền ban!');
    if (member && member.roles?.highest?.position >= (guild.members.me?.roles?.highest?.position || 0))
      return isSlash ? interactionOrMessage.editReply({ content: '❌ Role người này cao hơn hoặc bằng bot!' }) : err('❌ Role cao hơn bot!');

    try {
      if (member) await member.send({ embeds: [new EmbedBuilder().setColor(config.colors?.error || '#FF4757').setTitle('🚫 Bạn đã bị Ban')
        .setDescription(`**Server:** ${guild.name}\n**Lý do:** ${reason}`).setFooter({ text: config.footer || 'Stela Network' })] }).catch(() => {});

      await guild.members.ban(user.id, { reason, deleteMessageSeconds: delDays * 86400 });

      const embed = new EmbedBuilder().setColor(config.colors?.error || '#FF4757').setTitle('🚫 Ban thành công')
        .addFields(
          { name: 'User',  value: `${user.tag || user.username}`, inline: true },
          { name: 'Lý do', value: reason,                         inline: true },
          { name: 'Xóa tin nhắn', value: `${delDays} ngày`,       inline: true }
        ).setFooter({ text: config.footer || 'Stela Network' }).setTimestamp();

      if (isSlash) await interactionOrMessage.editReply({ embeds: [embed] });
      else await interactionOrMessage.reply({ embeds: [embed] });
    } catch (e) {
      const msg = `❌ Lỗi khi ban: ${e.message}`;
      if (isSlash) await interactionOrMessage.editReply({ content: msg });
      else await interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(config.colors?.error || '#FF4757').setDescription(msg)] });
    }
  }
};
