'use strict';
const { EmbedBuilder, SlashCommandBuilder, PermissionFlagsBits, MessageFlags } = require('discord.js');
const config = require('../../config.json');
const { isAdmin, getMember } = require('../../handlers/utils');
const db = require('../../database');

module.exports = {
  name: 'warn',
  enabled: true,
  description: 'Cảnh cáo thành viên',
  category: 'Moderation',
  usage: '!warn <@user|UID> <lý do>',
  cooldown: 5,
  prefixSupport: true,
  data: new SlashCommandBuilder()
    .setName('warn').setDescription('Cảnh cáo thành viên')
    .addUserOption(o => o.setName('user').setDescription('Người bị warn').setRequired(true))
    .addStringOption(o => o.setName('reason').setDescription('Lý do').setRequired(true).setMaxLength(500))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .setDMPermission(false),

  async execute(interactionOrMessage, args, client) {
    const isSlash = !!interactionOrMessage.isChatInputCommand?.();
    const author  = isSlash ? interactionOrMessage.user : interactionOrMessage.author;
    const guild   = interactionOrMessage.guild;

    const err = (txt) => {
      const e = new EmbedBuilder().setColor(config.colors?.error || '#FF4757').setDescription(txt).setFooter({ text: config.footer || 'Stela Network' });
      return isSlash ? interactionOrMessage.reply({ embeds: [e], flags: MessageFlags.Ephemeral }) : interactionOrMessage.reply({ embeds: [e] });
    };

    if (!isSlash && !isAdmin(author.id) && !interactionOrMessage.member?.permissions.has(PermissionFlagsBits.ModerateMembers))
      return err('❌ Bạn không có quyền **Moderate Members**!');

    if (isSlash) await interactionOrMessage.deferReply({ flags: MessageFlags.Ephemeral });

    let member, reason;
    if (isSlash) {
      member = interactionOrMessage.options.getMember('user');
      reason = interactionOrMessage.options.getString('reason');
    } else {
      if (args?.length < 2) return err(`📌 \`${module.exports.usage}\``);
      member = await getMember(guild, args[0]);
      reason = args.slice(1).join(' ');
    }

    if (!member) return isSlash ? interactionOrMessage.editReply({ content: '❌ Không tìm thấy user!' }) : err('❌ Không tìm thấy user!');

    const warnCount = db.addWarning(guild.id, member.id, reason, author.id);

    await member.send({ embeds: [new EmbedBuilder().setColor(config.colors?.warning || '#FFA502')
      .setTitle('⚠️ Bạn đã bị cảnh cáo')
      .setDescription(`**Server:** ${guild.name}\n**Lý do:** ${reason}\n**Lần thứ:** ${warnCount}`)
      .setFooter({ text: config.footer || 'Stela Network' })] }).catch(() => {});

    const embed = new EmbedBuilder().setColor(config.colors?.warning || '#FFA502').setTitle('⚠️ Đã cảnh cáo')
      .addFields(
        { name: 'User',       value: `${member}`,   inline: true },
        { name: 'Lý do',      value: reason,         inline: true },
        { name: 'Tổng warn',  value: `${warnCount}`, inline: true }
      ).setFooter({ text: config.footer || 'Stela Network' }).setTimestamp();

    if (isSlash) await interactionOrMessage.editReply({ embeds: [embed] });
    else await interactionOrMessage.reply({ embeds: [embed] });
  }
};
