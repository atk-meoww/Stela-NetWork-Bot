'use strict';
const { EmbedBuilder, SlashCommandBuilder, PermissionFlagsBits, MessageFlags } = require('discord.js');
const config = require('../../config.json');
const { isAdmin, getMember } = require('../../handlers/utils');

module.exports = {
  name: 'unmute',
  enabled: true,
  description: 'Gỡ timeout (unmute) thành viên',
  category: 'Moderation',
  aliases: ['untimeout', 'utm'],
  usage: '!unmute <@user|UID> [lý do]',
  cooldown: 5,
  prefixSupport: true,
  data: new SlashCommandBuilder()
    .setName('unmute').setDescription('Gỡ timeout (unmute) thành viên')
    .addUserOption(o => o.setName('user').setDescription('Người cần unmute').setRequired(true))
    .addStringOption(o => o.setName('reason').setDescription('Lý do').setRequired(false))
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .setDMPermission(false),

  async execute(interactionOrMessage, args, client) {
    const isSlash = !!interactionOrMessage.isChatInputCommand?.();
    const author  = isSlash ? interactionOrMessage.user : interactionOrMessage.author;
    const guild   = interactionOrMessage.guild;

    const err = (txt) => {
      const e = new EmbedBuilder().setColor(config.colors?.error || '#FF4757').setDescription(txt).setFooter({ text: config.footer || 'Stela Network' });
      return isSlash ? interactionOrMessage.reply({ embeds: [e], flags: MessageFlags.Ephemeral }) : interactionOrMessage.reply({ embeds: [e] });
    };

    if (!isSlash && !isAdmin(author.id) && !interactionOrMessage.member?.permissions.has(PermissionFlagsBits.ModerateMembers))
      return err('❌ Bạn không có quyền **Moderate Members**!');

    if (isSlash) await interactionOrMessage.deferReply({ flags: MessageFlags.Ephemeral });

    let member, reason;
    if (isSlash) {
      member = interactionOrMessage.options.getMember('user');
      reason = interactionOrMessage.options.getString('reason') || 'Không có lý do';
    } else {
      if (!args?.[0]) return err(`📌 \`${module.exports.usage}\``);
      member = await getMember(guild, args[0]);
      reason = args.slice(1).join(' ') || 'Không có lý do';
    }

    if (!member) return isSlash ? interactionOrMessage.editReply({ content: '❌ Không tìm thấy user!' }) : err('❌ Không tìm thấy user!');
    if (!member.isCommunicationDisabled()) {
      const msg = '❌ User này không đang bị mute!';
      return isSlash ? interactionOrMessage.editReply({ content: msg }) : err(msg);
    }

    try {
      await member.timeout(null, reason);

      await member.send({ embeds: [new EmbedBuilder().setColor(config.colors?.success || '#00D26A').setTitle('🔊 Bạn đã được Unmute')
        .setDescription(`**Server:** ${guild.name}\n**Lý do:** ${reason}`).setFooter({ text: config.footer || 'Stela Network' })] }).catch(() => {});

      const embed = new EmbedBuilder().setColor(config.colors?.success || '#00D26A').setTitle('🔊 Unmute thành công')
        .addFields(
          { name: 'User',  value: `${member.user?.tag || member.user?.username}`, inline: true },
          { name: 'Lý do', value: reason,                                          inline: true }
        ).setFooter({ text: config.footer || 'Stela Network' }).setTimestamp();

      if (isSlash) await interactionOrMessage.editReply({ embeds: [embed] });
      else await interactionOrMessage.reply({ embeds: [embed] });
    } catch (e) {
      const msg = `❌ Lỗi khi unmute: ${e.message}`;
      if (isSlash) await interactionOrMessage.editReply({ content: msg });
      else await interactionOrMessage.reply({ embeds: [new EmbedBuilder().setColor(config.colors?.error || '#FF4757').setDescription(msg)] });
    }
  }
};
