const { EmbedBuilder, SlashCommandBuilder } = require("discord.js");
const { loadConfig } = require("../../handlers/utils");
const https = require("https");

function fetchJSON(url) {
  return new Promise((resolve, reject) => {
    const get = (u) => {
      https.get(u, { headers: { "User-Agent": "Mozilla/5.0" } }, (res) => {
        if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) return get(res.headers.location);
        if (res.statusCode !== 200) return reject(new Error("HTTP " + res.statusCode));
        const chunks = [];
        res.on("data", c => chunks.push(c));
        res.on("end", () => { try { resolve(JSON.parse(Buffer.concat(chunks).toString())); } catch (e) { reject(e); } });
        res.on("error", reject);
      }).on("error", reject);
    };
    get(url);
  });
}

function formatTier(tier, pos, peakTier, peakPos, retired) {
  if (!tier) {
    if (peakTier) return "Unranked (Peak: " + (peakPos === 0 ? "HT" : "LT") + peakTier + ")";
    return "Unranked";
  }
  const prefix = retired ? "R" : (pos === 0 ? "H" : "L");
  const current = prefix + "T" + tier;
  if (peakTier) {
    const peakStr = (peakPos === 0 ? "HT" : "LT") + peakTier;
    const curClean = (pos === 0 ? "HT" : "LT") + tier;
    if (peakStr !== curClean) return current + " (Peak: " + peakStr + ")";
  }
  return current;
}

const GAMEMODE_EMOJI = {
  "sword": "🗡️", "axe": "🪓", "mace": "🔨", "uhc": "❤️",
  "pot": "🧪", "smp": "🌿", "vanilla": "💎", "nethpot": "⚫",
  "crystal": "💠", "elytra": "🦅", "bow": "🏹"
};

module.exports = {
  name: "pt",
  enabled: true,
  description: "Check tier Minecraft tren pvptiers.com",
  category: "Misc",
  aliases: ["pvptier", "pvptiers"],
  usage: '!pt',
  prefixSupport: true,
  data: new SlashCommandBuilder()
    .setName('pt').setDescription('Phán tiên ký 🔮')
    .setDMPermission(false),
  cooldown: 5,

  async execute(interactionOrMessage, args, client) {
    const cfg = loadConfig();

    if (!args[0]) {
      return interactionOrMessage.reply({ embeds: [new EmbedBuilder()
        .setColor(0xFF4757)
        .setDescription("**Cach dung:** `!pt [IGN]`\n**Vi du:** `!pt Steve`")
        .setFooter({ text: cfg.footer || "Stela Network" })]
      });
    }

    const ign = args[0];
    const loading = await interactionOrMessage.reply("🔍 **Đang tra cứu PvPTiers của " + ign + "...**");

    try {
      const mojang = await fetchJSON("https://api.mojang.com/users/profiles/minecraft/" + ign);
      const uuid = mojang.id;
      const username = mojang.name;
      const skinUrl = "https://mc-heads.net/avatar/" + uuid + "/64";

      // Thử các endpoint khác nhau
      let data = null;
      const endpoints = [
        "https://pvptiers.com/api/player/" + username,
        "https://pvptiers.com/api/players/" + username,
        "https://pvptiers.com/api/profile/" + username,
        "https://pvptiers.com/api/player/" + uuid,
      ];

      for (const ep of endpoints) {
        try {
          data = await fetchJSON(ep);
          if (data) break;
        } catch (e) {
          if (!e.message.includes("HTTP 5")) throw e;
        }
      }

      if (!data) throw new Error("Khong the ket noi den pvptiers.com!");

      let tiers = {};
      if (data.tiers && typeof data.tiers === "object") tiers = data.tiers;
      else if (data.gamemodes && typeof data.gamemodes === "object") tiers = data.gamemodes;

      const tierKeys = Object.keys(tiers).filter(k => tiers[k] && tiers[k].tier);

      if (tierKeys.length === 0) {
        return loading.edit({ content: null, embeds: [new EmbedBuilder()
          .setColor(0xFFA500)
          .setTitle(username + "'s PvPTiers")
          .setDescription("There are no tiers for this player.")
          .setThumbnail(skinUrl)
          .setURL("https://pvptiers.com/player/" + username)
          .setFooter({ text: (cfg.footer || "Stela Network") + " • pvptiers.com" })
          .setTimestamp()]
        });
      }

      const embed = new EmbedBuilder()
        .setColor(0x5865F2)
        .setTitle(username + "'s PvPTiers")
        .setURL("https://pvptiers.com/player/" + username)
        .setThumbnail(skinUrl)
        .setFooter({ text: (cfg.footer || "Stela Network") + " • pvptiers.com" })
        .setTimestamp();

      if (data.overall || data.rank) embed.addFields({ name: "🏆 Overall", value: "#" + (data.overall || data.rank), inline: true });
      if (data.points) embed.addFields({ name: "⭐ Points", value: String(data.points), inline: true });
      if (data.region) embed.addFields({ name: "🌍 Region", value: data.region, inline: true });

      const fields = tierKeys.map(k => {
        const v = tiers[k];
        const emoji = GAMEMODE_EMOJI[k.toLowerCase()] || "🏅";
        const label = k.charAt(0).toUpperCase() + k.slice(1);
        const tierStr = formatTier(v.tier, v.pos, v.peak_tier, v.peak_pos, v.retired);
        return { name: emoji + " " + label, value: "**" + tierStr + "**", inline: true };
      });

      embed.addFields(fields);
      return loading.edit({ content: null, embeds: [embed] });

    } catch (err) {
      if (err.message.includes("404") || err.message.includes("HTTP 4")) {
        return loading.edit({ content: null, embeds: [new EmbedBuilder()
          .setColor(0xFF4757)
          .setDescription("Khong tim thay nguoi choi **" + ign + "**!")
          .setFooter({ text: cfg.footer || "Stela Network" })]
        });
      }
      return loading.edit({ content: null, embeds: [new EmbedBuilder()
        .setColor(0xFF4757)
        .setDescription("Loi: " + err.message)
        .setFooter({ text: cfg.footer || "Stela Network" })]
      });
    }
  }
};
