const { EmbedBuilder, SlashCommandBuilder } = require("discord.js");
const { loadConfig } = require("../../handlers/utils");

module.exports = {
  name: "ss",
  enabled: true,
  description: "Tải phần mềm SS đã được Staff StelaMC duyệt",
  category: "Misc",
  aliases: ["download", "taifile"],
  usage: '!ss',
  prefixSupport: true,
  data: new SlashCommandBuilder()
    .setName('ss').setDescription('Tính độ tương hợp')
    .setDMPermission(false),
  cooldown: 5,

  async execute(interactionOrMessage, args, client) {
    const cfg = loadConfig();

    const embed = new EmbedBuilder()
      .setColor(0x7B2FBE)
      .setTitle("📥 Tải phần mềm SS đã được Staff StelaMC duyệt")
      .setDescription(
        "**Mystic Scanner**\n" +
        "[Tải xuống](https://www.mediafire.com/file/hjfao3krkxfk9zr/Mystic+Scanner.exe/file)\n" +
        "[Check bằng Ocean](https://anticheat.ac/)\n\n" +

        "**JournalTrace**\n" +
        "[Tải xuống](https://www.mediafire.com/file/wvzksp288b6ve15/JournalTrace.exe/file)\n" +
        "[Check bằng Ocean](https://anticheat.ac/)\n\n" +

        "**VissAC**\n" +
        "[Tải xuống](https://www.mediafire.com/file/ng9jnf1ifftq3v6/VissAC.exe/file)\n" +
        "[Check bằng Ocean](https://anticheat.ac/)"
      )
      .setFooter({ text: cfg.footer || "Stela Network" })
      .setTimestamp();

    interactionOrMessage.reply({ embeds: [embed] });
  }
};