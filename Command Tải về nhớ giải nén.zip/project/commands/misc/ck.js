const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ComponentType, SlashCommandBuilder } = require("discord.js");
const { loadConfig } = require("../../handlers/utils");

module.exports = {
  name: "ck",
  enabled: true,
  description: "Quet toan bo file log tim kiem tu cu the",
  category: "Misc",
  aliases: ["scan", "quetfile"],
  usage: '!ck',
  prefixSupport: true,
  data: new SlashCommandBuilder()
    .setName('ck').setDescription('Câu đố nhanh 🧩')
    .setDMPermission(false),
  cooldown: 5,

  async execute(interactionOrMessage, args, client) {
    const cfg = loadConfig();

    if (!args[0]) {
      return interactionOrMessage.reply({ embeds: [new EmbedBuilder()
        .setColor(0xFF4757)
        .setDescription("**Cach dung:** Dinh kem file + `!ck [tu can tim]`\n**Vi du:** `!ck Steve`")
        .setFooter({ text: cfg.footer || "Stela Network" })]
      });
    }

    const attachment = message.attachments.first();
    if (!attachment) {
      return interactionOrMessage.reply({ embeds: [new EmbedBuilder()
        .setColor(0xFF4757)
        .setDescription("Ban chua dinh kem file log!\nHay gui file kem theo lenh `!ck [tu can tim]`")
        .setFooter({ text: cfg.footer || "Stela Network" })]
      });
    }

    const keyword = args.join(" ").toLowerCase();
    const loading = await interactionOrMessage.reply("🔍 **Đang quét toàn bộ file...**");

    try {
      const res = await fetch(attachment.url);
      if (!res.ok) throw new Error("HTTP " + res.status);
      const text = await res.text();
      const lines = text.replace(/\r\n/g, "\n").replace(/\r/g, "\n").split("\n");

      const matched = lines
        .map((line, i) => ({ line: line.trim(), num: i + 1 }))
        .filter(({ line }) => line.toLowerCase().includes(keyword));

      if (matched.length === 0) {
        return loading.edit({ content: null, embeds: [new EmbedBuilder()
          .setColor(0xFFA500)
          .setTitle("🔍 Ket Qua Quet File")
          .setDescription("Khong tim thay **\"" + keyword + "\"** trong file `" + attachment.name + "`")
          .addFields({ name: "Tong dong quet", value: "`" + lines.length + " dong`", inline: true })
          .setFooter({ text: cfg.footer || "Stela Network" })
          .setTimestamp()]
        });
      }

      const allLines = matched.map(({ line, num }) => {
        const short = line.length > 80 ? line.slice(0, 80) + "..." : line;
        return "[" + num + "] " + short;
      });

      const chunks = [];
      let current = "";
      for (const l of allLines) {
        if ((current + "\n" + l).length > 900) {
          chunks.push(current);
          current = l;
        } else {
          current += (current ? "\n" : "") + l;
        }
      }
      if (current) chunks.push(current);

      let page = 0;

      const buildEmbed = (p) => new EmbedBuilder()
        .setColor(0x00D26A)
        .setTitle("🔍 Ket Qua Quet File")
        .setDescription(
          "**File:** `" + attachment.name + "`  **Tu tim:** `" + keyword + "`  **Ket qua:** `" + matched.length + "/" + lines.length + " dong`\n\n" +
          "```" + chunks[p] + "```"
        )
        .setFooter({ text: (cfg.footer || "Stela Network") + " • Trang " + (p+1) + "/" + chunks.length })
        .setTimestamp();

      const buildRow = (p) => new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId("ck_prev")
          .setLabel("◀ Trước")
          .setStyle(ButtonStyle.Secondary)
          .setDisabled(p === 0),
        new ButtonBuilder()
          .setCustomId("ck_next")
          .setLabel("Sau ▶")
          .setStyle(ButtonStyle.Secondary)
          .setDisabled(p === chunks.length - 1)
      );

      const reply = await loading.edit({
        content: null,
        embeds: [buildEmbed(0)],
        components: chunks.length > 1 ? [buildRow(0)] : []
      });

      if (chunks.length <= 1) return;

      const collector = reply.createMessageComponentCollector({
        componentType: ComponentType.Button,
        time: 120000,
        filter: (i) => i.user.id === interactionOrMessage.author.id
      });

      collector.on("collect", async (i) => {
        if (i.customId === "ck_prev") page = Math.max(0, page - 1);
        if (i.customId === "ck_next") page = Math.min(chunks.length - 1, page + 1);
        await i.update({ embeds: [buildEmbed(page)], components: [buildRow(page)] });
      });

      collector.on("end", () => {
        reply.edit({ components: [] }).catch(() => {});
      });

    } catch (err) {
      return loading.edit({ content: null, embeds: [new EmbedBuilder()
        .setColor(0xFF4757)
        .setDescription("Loi: " + err.message)
        .setFooter({ text: cfg.footer || "Stela Network" })]
      });
    }
  }
};
