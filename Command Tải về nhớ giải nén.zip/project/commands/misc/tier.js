const { EmbedBuilder, SlashCommandBuilder } = require("discord.js");
const { loadConfig } = require("../../handlers/utils");
const https = require("https");

function fetchJSON(url) {
  return new Promise((resolve, reject) => {
    const get = (u) => {
      https.get(u, { headers: { "User-Agent": "Mozilla/5.0" } }, (res) => {
        if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) return get(res.headers.location);
        if (res.statusCode !== 200) return reject(new Error("HTTP " + res.statusCode));
        const chunks = [];
        res.on("data", c => chunks.push(c));
        res.on("end", () => { try { resolve(JSON.parse(Buffer.concat(chunks).toString())); } catch (e) { reject(e); } });
        res.on("error", reject);
      }).on("error", reject);
    };
    get(url);
  });
}

function formatTier(tier, isHigh, peakTier, peakIsHigh) {
  if (!tier && tier !== 0) {
    if (peakTier) return "Unranked (Peak: " + (peakIsHigh ? "HT" : "LT") + peakTier + ")";
    return "Unranked";
  }
  const current = (isHigh ? "HT" : "LT") + tier;
  if (peakTier) {
    const peak = (peakIsHigh ? "HT" : "LT") + peakTier;
    if (peak !== current) return current + " (Peak: " + peak + ")";
  }
  return current;
}

const CATEGORY_EMOJI = {
  "Sword": "🗡️", "Axe": "🪓", "Mace": "🔨",
  "UHC": "❤️", "Pot": "🧪", "SMP": "🌿",
  "Vanilla": "💎", "Netherite OP": "⚫", "NethOP": "⚫"
};

module.exports = {
  name: "tier",
  enabled: true,
  description: "Check tier Minecraft tren mctiers.com",
  category: "Misc",
  aliases: ["checktier", "mctier"],
  usage: '!tier',
  prefixSupport: true,
  data: new SlashCommandBuilder()
    .setName('tier').setDescription('Xem tier list server')
    .setDMPermission(false),
  cooldown: 5,

  async execute(interactionOrMessage, args, client) {
    const cfg = loadConfig();

    if (!args[0]) {
      return interactionOrMessage.reply({ embeds: [new EmbedBuilder()
        .setColor(0xFF4757)
        .setDescription("**Cach dung:** `!tier [IGN]`\n**Vi du:** `!tier Steve`")
        .setFooter({ text: cfg.footer || "Stela Network" })]
      });
    }

    const ign = args[0];
    const loading = await interactionOrMessage.reply("🔍 **Đang tra cứu tier của " + ign + "...**");

    try {
      const mojang = await fetchJSON("https://api.mojang.com/users/profiles/minecraft/" + ign);
      const uuid = mojang.id;
      const username = mojang.name;
      const skinUrl = "https://mc-heads.net/avatar/" + uuid + "/64";

      const data = await fetchJSON("https://mctiers.com/api/profile/" + uuid);

      // Normalize rankings — có thể là array hoặc object
      let rankings = [];
      if (Array.isArray(data.rankings)) {
        rankings = data.rankings;
      } else if (data.rankings && typeof data.rankings === "object") {
        rankings = Object.entries(data.rankings).map(([cat, val]) => ({
          category: cat,
          tier: val.tier,
          is_high_tier: val.is_high_tier,
          peak_tier: val.peak_tier,
          peak_is_high_tier: val.peak_is_high_tier
        }));
      }

      if (rankings.length === 0) {
        return loading.edit({ content: null, embeds: [new EmbedBuilder()
          .setColor(0xFFA500)
          .setTitle(username + "'s Tiers")
          .setDescription("There are no tiers for this player.")
          .setThumbnail(skinUrl)
          .setFooter({ text: (cfg.footer || "Stela Network") + " • mctiers.com" })
          .setTimestamp()]
        });
      }

      const embed = new EmbedBuilder()
        .setColor(0x00D26A)
        .setTitle(username + "'s Tiers")
        .setURL("https://mctiers.com/player/" + username)
        .setThumbnail(skinUrl)
        .setFooter({ text: (cfg.footer || "Stela Network") + " • mctiers.com" })
        .setTimestamp();

      if (data.overall) {
        embed.addFields({ name: "🏆 Overall", value: "#" + data.overall, inline: false });
      }

      const fields = rankings.map(r => {
        const emoji = CATEGORY_EMOJI[r.category] || "🏅";
        const tierStr = formatTier(r.tier, r.is_high_tier, r.peak_tier, r.peak_is_high_tier);
        return { name: emoji + " " + r.category, value: "**" + tierStr + "**", inline: true };
      });

      embed.addFields(fields);
      return loading.edit({ content: null, embeds: [embed] });

    } catch (err) {
      if (err.message.includes("404") || err.message.includes("HTTP 4")) {
        return loading.edit({ content: null, embeds: [new EmbedBuilder()
          .setColor(0xFF4757)
          .setDescription("Khong tim thay nguoi choi **" + ign + "**!")
          .setFooter({ text: cfg.footer || "Stela Network" })]
        });
      }
      return loading.edit({ content: null, embeds: [new EmbedBuilder()
        .setColor(0xFF4757)
        .setDescription("Loi: " + err.message)
        .setFooter({ text: cfg.footer || "Stela Network" })]
      });
    }
  }
};
