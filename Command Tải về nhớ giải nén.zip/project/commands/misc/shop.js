// ═══════════════════════════════════════════════════════════════════════════════
//  Stela Studio v5.0.0 — commands/misc/shop.js
//  Shop mua đồ bằng tiền 🪙 trong bot
// ═══════════════════════════════════════════════════════════════════════════════

'use strict';
const _0x03e522={0x8582:0x7963,_:!0};void(0x69);

const {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  SlashCommandBuilder
} = require('discord.js');
const config = require('../../config.json');
const db     = require('../../database');
const { formatNumber } = require('../../handlers/utils');

// ─── DANH SÁCH SẢN PHẨM ───────────────────────────────────────────────────────
const SHOP_ITEMS = [
  // ── Vật phẩm cơ bản ──
  {
    id:       'xp_boost_s',
    name:     'XP Boost Nhỏ',
    emoji:    '⚡',
    price:    300,
    category: '📦 Vật phẩm',
    desc:     'Tăng thêm **+500 XP** ngay lập tức',
    action:   (user) => { user.xp += 500; user.totalXP = (user.totalXP || 0) + 500; }
  },
  {
    id:       'xp_boost_l',
    name:     'XP Boost Lớn',
    emoji:    '⚡⚡',
    price:    800,
    category: '📦 Vật phẩm',
    desc:     'Tăng thêm **+2,000 XP** ngay lập tức',
    action:   (user) => { user.xp += 2000; user.totalXP = (user.totalXP || 0) + 2000; }
  },
  {
    id:       'money_bag_s',
    name:     'Túi Tiền Nhỏ',
    emoji:    '💵',
    price:    200,
    category: '📦 Vật phẩm',
    desc:     'Nhận ngay **+400 🪙** (lời 200)',
    action:   (user) => { user.money += 400; }
  },
  {
    id:       'money_bag_l',
    name:     'Túi Tiền Lớn',
    emoji:    '💰',
    price:    1000,
    category: '📦 Vật phẩm',
    desc:     'Nhận ngay **+2,500 🪙** (lời 1,500)',
    action:   (user) => { user.money += 2500; }
  },

  // ── Lucky items ──
  {
    id:       'lucky_box',
    name:     'Hộp May Mắn',
    emoji:    '🎁',
    price:    500,
    category: '🎲 Lucky',
    desc:     'Ngẫu nhiên nhận **100 → 2,000 🪙** hoặc **XP**',
    action:   (user) => {
      const roll = Math.random();
      if (roll < 0.5)       { user.money += Math.floor(Math.random() * 500) + 100; }
      else if (roll < 0.85) { user.money += Math.floor(Math.random() * 1000) + 500; }
      else                  { user.money += 2000; }
    },
    luckLabel: 'Ngẫu nhiên'
  },
  {
    id:       'diamond_box',
    name:     'Hộp Kim Cương',
    emoji:    '💎',
    price:    2000,
    category: '🎲 Lucky',
    desc:     'Ngẫu nhiên nhận **1,000 → 10,000 🪙** hoặc **XP lớn**',
    action:   (user) => {
      const roll = Math.random();
      if (roll < 0.4)       { user.money += Math.floor(Math.random() * 2000) + 1000; }
      else if (roll < 0.8)  { user.money += Math.floor(Math.random() * 4000) + 2000; }
      else if (roll < 0.95) { user.money += 8000; }
      else                  { user.money += 10000; }
    },
    luckLabel: 'Jackpot có thể x5'
  },

  // ── Streak & Daily ──
  {
    id:       'streak_shield',
    name:     'Khiên Streak',
    emoji:    '🛡️',
    price:    1500,
    category: '🔥 Daily',
    desc:     'Bảo vệ streak daily nếu bạn quên **1 ngày**',
    action:   (user) => { user.streakShield = (user.streakShield || 0) + 1; }
  },
  {
    id:       'daily_reset',
    name:     'Reset Daily',
    emoji:    '🔄',
    price:    800,
    category: '🔥 Daily',
    desc:     'Cho phép nhận **!daily ngay lập tức** một lần',
    action:   (user) => { user.lastDaily = 0; }
  },

  // ── VIP ──
  {
    id:       'vip_tag',
    name:     'Tag VIP 7 ngày',
    emoji:    '👑',
    price:    5000,
    category: '💎 VIP',
    desc:     'Nhận tag **[VIP]** trong 7 ngày, x1.5 XP',
    action:   (user) => {
      user.vipExpiry = (Date.now()) + (7 * 24 * 60 * 60 * 1000);
    }
  }
];

// ─── CATEGORY ORDER ───────────────────────────────────────────────────────────
const CATEGORY_ORDER = ['📦 Vật phẩm', '🎲 Lucky', '🔥 Daily', '💎 VIP'];

// ─── HELPERS ──────────────────────────────────────────────────────────────────
function fmtMoney(n) { return formatNumber(n) + ' 🪙'; }

function buildShopEmbed(client, page) {
  const categories = CATEGORY_ORDER;
  const cat        = categories[page];
  const items      = SHOP_ITEMS.filter(i => i.category === cat);

  const desc = items.map(item =>
    `${item.emoji} **${item.name}** — \`${fmtMoney(item.price)}\`\n` +
    `┗ ${item.desc}\n`
  ).join('\n');

  return new EmbedBuilder()
    .setColor(0x7B2FBE)
    .setTitle(`🛒 Stela Shop — ${cat}`)
    .setDescription(
      '> Dùng `!buy <tên vật phẩm>` để mua\n' +
      '> Ví dụ: `!buy Hộp May Mắn` hoặc `!buy lucky_box`\n\n' +
      '━━━━━━━━━━━━━━━━━━━━━━\n\n' +
      desc
    )
    .setThumbnail(client.user.displayAvatarURL())
    .setFooter({
      text: `${config.footer} • Trang ${page + 1}/${categories.length} | Dùng nút để chuyển trang`,
      iconURL: client.user.displayAvatarURL()
    })
    .setTimestamp();
}

function buildShopRow(page) {
  const max = CATEGORY_ORDER.length - 1;
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('shop_prev')
      .setEmoji('◀️')
      .setLabel('Trước')
      .setStyle(ButtonStyle.Primary)
      .setDisabled(page === 0),
    new ButtonBuilder()
      .setCustomId('shop_page')
      .setLabel(`${page + 1} / ${CATEGORY_ORDER.length}`)
      .setStyle(ButtonStyle.Secondary)
      .setDisabled(true),
    new ButtonBuilder()
      .setCustomId('shop_next')
      .setEmoji('▶️')
      .setLabel('Tiếp')
      .setStyle(ButtonStyle.Primary)
      .setDisabled(page === max)
  );
}

// ─── COMMAND: !shop ───────────────────────────────────────────────────────────
module.exports = {
  name: 'shop',
  enabled: true,
  description: 'Mở cửa hàng bot',
  category: 'Misc',
  aliases: ['store', 'cửahàng'],
  usage: '!shop',
  prefixSupport: true,
  data: new SlashCommandBuilder()
    .setName('shop').setDescription('Xem cửa hàng vật phẩm 🏪')
    .setDMPermission(false),
  cooldown: 5,

  async execute(interactionOrMessage, args, client) {
    let page = 0;

    const msg = await interactionOrMessage.reply({
      embeds: [buildShopEmbed(client, page)],
      components: [buildShopRow(page)]
    });

    const collector = msg.createMessageComponentCollector({
      filter: i => i.user.id === interactionOrMessage.author.id &&
                   ['shop_prev', 'shop_next'].includes(i.customId),
      time: 90_000
    });

    collector.on('collect', async interaction => {
      if (interaction.customId === 'shop_next') page = Math.min(CATEGORY_ORDER.length - 1, page + 1);
      else                                       page = Math.max(0, page - 1);

      await interaction.update({
        embeds: [buildShopEmbed(client, page)],
        components: [buildShopRow(page)]
      });
    });

    collector.on('end', () => {
      const disabled = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('shop_prev').setEmoji('◀️').setLabel('Trước').setStyle(ButtonStyle.Primary).setDisabled(true),
        new ButtonBuilder().setCustomId('shop_page').setLabel(`${page + 1} / ${CATEGORY_ORDER.length}`).setStyle(ButtonStyle.Secondary).setDisabled(true),
        new ButtonBuilder().setCustomId('shop_next').setEmoji('▶️').setLabel('Tiếp').setStyle(ButtonStyle.Primary).setDisabled(true)
      );
      msg.edit({ components: [disabled] }).catch(() => {});
    });
  }
};
