const { EmbedBuilder, PermissionFlagsBits, SlashCommandBuilder } = require("discord.js");
const { loadConfig } = require("../../handlers/utils");
const path = require("path");
const fs = require("fs");

const DATA_FILE = path.join(__dirname, "..", "..", "data", "autoreply.json");

function loadTriggers() {
  try {
    if (!fs.existsSync(DATA_FILE)) return {};
    return JSON.parse(fs.readFileSync(DATA_FILE, "utf8"));
  } catch { return {}; }
}

function saveTriggers(data) {
  try {
    const dir = path.dirname(DATA_FILE);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
  } catch (e) { console.error("ar save error:", e); }
}

module.exports = {
  name: "ar",
  enabled: true,
  description: "Quan ly autoreply",
  category: "Admin",
  aliases: ["autoreply", "autoresponder"],
  usage: '!ar',
  prefixSupport: true,
  data: new SlashCommandBuilder()
    .setName('ar').setDescription('Admin: Quản lý auto reply')
    .addSubcommand(s=>s.setName("add").setDescription("Thêm auto reply").addStringOption(o=>o.setName("trigger").setDescription("Trigger").setRequired(true)).addStringOption(o=>o.setName("response").setDescription("Phản hồi").setRequired(true)))
    .addSubcommand(s=>s.setName("remove").setDescription("Xóa auto reply").addStringOption(o=>o.setName("trigger").setDescription("Trigger").setRequired(true)))
    .addSubcommand(s=>s.setName("list").setDescription("Danh sách auto reply"))
    .setDMPermission(false),
  cooldown: 3,

  async execute(interactionOrMessage, args, client) {
    const cfg = loadConfig();

    const isAdmin = interactionOrMessage.author.id === cfg.ownerID
      || (cfg.adminIDs || []).includes(interactionOrMessage.author.id)
      || interactionOrMessage.member?.permissions.has(PermissionFlagsBits.Administrator);

    if (!isAdmin) return interactionOrMessage.reply({ embeds: [new EmbedBuilder()
      .setColor(0xFF4757)
      .setDescription("Chi **Admin/Owner** moi dung duoc lenh nay!")
      .setFooter({ text: cfg.footer || "Stela Network" })]
    });

    const sub = args[0]?.toLowerCase();

    // !ar list
    if (!sub || sub === "list") {
      const triggers = loadTriggers();
      const keys = Object.keys(triggers);
      if (keys.length === 0) {
        return interactionOrMessage.reply({ embeds: [new EmbedBuilder()
          .setColor(0xFFA500)
          .setDescription("Chua co autoreply nao duoc set!")
          .setFooter({ text: cfg.footer || "Stela Network" })]
        });
      }
      const list = keys.map((k, i) => (i+1) + ". `" + k + "` → " + triggers[k].slice(0, 50) + (triggers[k].length > 50 ? "..." : "")).join("\n");
      return interactionOrMessage.reply({ embeds: [new EmbedBuilder()
        .setColor(cfg.colors?.primary || 0x7B2FBE)
        .setTitle("📋 Danh sach Autoreply (" + keys.length + ")")
        .setDescription(list)
        .setFooter({ text: cfg.footer || "Stela Network" })]
      });
    }

    // !ar add [trigger] | [response]
    if (sub === "add") {
      const rest = args.slice(1).join(" ");
      const sepIndex = rest.indexOf("|");
      if (sepIndex === -1) {
        return interactionOrMessage.reply({ embeds: [new EmbedBuilder()
          .setColor(0xFF4757)
          .setDescription("**Cach dung:** `!ar add [trigger] | [response]`\n**Vi du:** `!ar add ping staff | Vui long doi staff, khong ping!`")
          .setFooter({ text: cfg.footer || "Stela Network" })]
        });
      }
      const trigger = rest.slice(0, sepIndex).trim().toLowerCase();
      const response = rest.slice(sepIndex + 1).trim();
      if (!trigger || !response) {
        return interactionOrMessage.reply({ embeds: [new EmbedBuilder()
          .setColor(0xFF4757)
          .setDescription("Trigger va response khong duoc de trong!")
          .setFooter({ text: cfg.footer || "Stela Network" })]
        });
      }
      const triggers = loadTriggers();
      triggers[trigger] = response;
      saveTriggers(triggers);
      return interactionOrMessage.reply({ embeds: [new EmbedBuilder()
        .setColor(0x00D26A)
        .setTitle("✅ Da them Autoreply")
        .addFields(
          { name: "Trigger", value: "`" + trigger + "`", inline: true },
          { name: "Response", value: response.slice(0, 200), inline: true }
        )
        .setFooter({ text: cfg.footer || "Stela Network" })]
      });
    }

    // !ar remove [trigger]
    if (sub === "remove" || sub === "delete" || sub === "rm") {
      const trigger = args.slice(1).join(" ").toLowerCase().trim();
      if (!trigger) return interactionOrMessage.reply("Nhap trigger can xoa!");
      const triggers = loadTriggers();
      if (!triggers[trigger]) {
        return interactionOrMessage.reply({ embeds: [new EmbedBuilder()
          .setColor(0xFF4757)
          .setDescription("Khong tim thay trigger `" + trigger + "`!")
          .setFooter({ text: cfg.footer || "Stela Network" })]
        });
      }
      delete triggers[trigger];
      saveTriggers(triggers);
      return interactionOrMessage.reply({ embeds: [new EmbedBuilder()
        .setColor(0x00D26A)
        .setDescription("Da xoa trigger `" + trigger + "`!")
        .setFooter({ text: cfg.footer || "Stela Network" })]
      });
    }

    // !ar clear
    if (sub === "clear") {
      saveTriggers({});
      return interactionOrMessage.reply({ embeds: [new EmbedBuilder()
        .setColor(0x00D26A)
        .setDescription("Da xoa het autoreply!")
        .setFooter({ text: cfg.footer || "Stela Network" })]
      });
    }

    interactionOrMessage.reply({ embeds: [new EmbedBuilder()
      .setColor(0xFFA500)
      .setDescription(
        "`!ar list` — Xem danh sach\n" +
        "`!ar add [trigger] | [response]` — Them\n" +
        "`!ar remove [trigger]` — Xoa\n" +
        "`!ar clear` — Xoa het"
      )
      .setFooter({ text: cfg.footer || "Stela Network" })]
    });
  }
};
