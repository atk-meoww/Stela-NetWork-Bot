const { EmbedBuilder, SlashCommandBuilder } = require("discord.js");
const { isAdmin, loadConfig } = require("../../handlers/utils");

module.exports = {
  name: "nv",
  enabled: true,
  description: "Hien don ung tuyen nhan vien",
  category: "Admin",
  aliases: ["tuyennv", "apply"],
  usage: '!nv',
  prefixSupport: true,
  data: new SlashCommandBuilder()
    .setName('nv').setDescription('Admin: Quản lý nhiệm vụ')
    .setDMPermission(false),
  cooldown: 5,

  async execute(interactionOrMessage, args, client) {
    const cfg = loadConfig();

    if (!isAdmin(interactionOrMessage.author.id)) {
      return interactionOrMessage.reply({ embeds: [new EmbedBuilder()
        .setColor(0xFF4757)
        .setDescription("Chi **Admin/Owner** moi dung duoc lenh nay!")
        .setFooter({ text: cfg.footer || "Stela Network" })]
      });
    }

    const content = `# Đơn ứng tuyển police
**\`Yêu cầu: \`**
> - Online: 2-3h trong server
> - Tuổi: trên 13 tuổi 
> - Thiết bị: Pc-Laptop (không nhận đi net)
> - Biết check hack/client ghost
> - Biết check và support member
> - Nói không với abuse/lạm quyền
> - Nói không với sử dụng cheat
> - Nói chuyện đàng hoàng với member 
> Uy tín: 100% khi bạn đã và đang làm ở server nào đó
# Đơn ứng tuyển helper
**\`Yêu cầu: \`**
> - Online: 2-3h trong server
> - Tuổi: trên 13 tuổi  
> - Thiết bị: Pc-Laptop (không nhận đi net) 
> - Biết check hack/client ghost 
> - Biết check và support member
> - Nói không với abuse/lạm quyền 
> - Nói không với sử dụng cheat 
> - Nói có với member - lễ phép và trung thật với staff  
> - Nói chuyện đàng hoàng với member 
> Uy tín: 100% khi bạn đã và đang làm ở server nào đó 
# Hãy show cccd hoặc thẻ học sinh hoặc bật cam để thể hiện lòng trung thật với server (show mặt không che, cccd che 3 số) 🛡️`;

    await interactionOrMessage.channel.send({ content });
    await message.delete().catch(() => {});
  }
};
