const { EmbedBuilder, SlashCommandBuilder } = require("discord.js");
const { isAdmin, loadConfig } = require("../../handlers/utils");

const MEMBER_ROLE_ID = "1445792770286420110";
const ANNOUNCE_CHANNEL_ID = "1445794767547011152";

module.exports = {
  name: "tb",
  enabled: true,
  description: "Gui thong bao toan server",
  category: "Admin",
  aliases: ["thongbao", "announce"],
  usage: '!tb',
  prefixSupport: true,
  data: new SlashCommandBuilder()
    .setName('tb').setDescription('Bật/tắt lệnh bot cho kênh')
    .addStringOption(o=>o.setName("command").setDescription("Tên lệnh hoặc all").setRequired(true))
    .addBooleanOption(o=>o.setName("enabled").setDescription("Bật/tắt").setRequired(true))
    .setDMPermission(false),
  cooldown: 5,

  async execute(interactionOrMessage, args, client) {
    const cfg = loadConfig();

    if (!isAdmin(interactionOrMessage.author.id)) {
      return interactionOrMessage.reply({ embeds: [new EmbedBuilder()
        .setColor(0xFF4757)
        .setDescription("Chi **Admin/Owner** moi dung duoc lenh nay!")
        .setFooter({ text: cfg.footer || "Stela Network" })]
      });
    }

    if (!args[0]) {
      return interactionOrMessage.reply({ embeds: [new EmbedBuilder()
        .setColor(0xFF4757)
        .setDescription("Vui long nhap noi dung thong bao!\n**Dung:** `!tb [noi dung]`")
        .setFooter({ text: cfg.footer || "Stela Network" })]
      });
    }

    const announceChannel = interactionOrMessage.guild.channels.cache.get(ANNOUNCE_CHANNEL_ID);
    if (!announceChannel) {
      return interactionOrMessage.reply("Khong tim thay kenh thong bao!");
    }

    const content = args.join(" ");

    const embed = new EmbedBuilder()
      .setColor(cfg.colors?.primary || 0x7B2FBE)
      .setTitle("📢 Thông Báo")
      .setDescription(content)
      .setFooter({ text: interactionOrMessage.author.tag, iconURL: interactionOrMessage.author.displayAvatarURL() })
      .setTimestamp();

    await announceChannel.send({
      content: `<@&${MEMBER_ROLE_ID}>`,
      embeds: [embed]
    });

    await message.delete().catch(() => {});
    await interactionOrMessage.channel.send({ embeds: [new EmbedBuilder()
      .setColor(0x00D26A)
      .setDescription(`Da gui thong bao vao <#${ANNOUNCE_CHANNEL_ID}>!`)
      .setFooter({ text: cfg.footer || "Stela Network" })]
    }).then(m => setTimeout(() => m.delete().catch(() => {}), 5000));
  }
};
